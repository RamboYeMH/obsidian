// Package main – shared test infrastructure for the MCP Gateway integration
// tests (tasks 14.2 and 14.3).
//
// This file provides:
//   - newTestServer: an in-process httptest.Server that mirrors main.go assembly
//     but uses Stateless + JSONResponse mode for simpler per-request testing.
//   - mcpPost: a convenience wrapper that POSTs to the MCP endpoint with an
//     optional Bearer token and returns ([]byte, int).
//   - decodeJSONRPCResult: parses the "result" field of a JSON-RPC response.
//   - wrongToken constant used by auth-rejection tests.
//
// The tools/list tests (task 14.2) live in tools_list_test.go.
// The tools/call round-trip, protocol-error, and auth-rejection tests
// (task 14.3) live in tools_call_test.go.
//
// Requirements: 1.2, 1.3, 1.5, 1.6, 2.5, 11.5
package main

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/modelcontextprotocol/go-sdk/mcp"

	"game-mcp/internal/auth"
	"game-mcp/internal/config"
	"game-mcp/internal/mcptools"
	"game-mcp/internal/resolver"
)

// wrongToken is an invalid Bearer token value used in auth-rejection tests.
const wrongToken = "wrong-token-xyz-invalid"

// newTestServer assembles a test HTTP server identical to main.go assembly:
//
//  1. Minimal in-memory config with a single valid token (testToken from
//     tools_list_test.go) and no real backend addresses.
//  2. resolver.NewResolver backed by that config (connects lazily, so no real
//     etcd/mongo/redis is required for protocol-layer tests).
//  3. All 4 MCP tools registered on a Streamable HTTP handler.
//  4. Auth middleware wrapping the MCP handler at /mcp.
//
// Stateless + JSONResponse mode is used so individual HTTP requests do not
// require a session handshake, making tests independent of each other.
func newTestServer(t *testing.T) *httptest.Server {
	t.Helper()

	cfg := &config.Config{
		Server: config.ServerConfig{
			Listen:   "127.0.0.1:0",
			Endpoint: "/mcp",
		},
		Tokens: []config.TokenEntry{
			{Name: "integration-test", Token: testToken},
		},
		Mongo: config.MongoConfig{
			Readonly: config.Credential{User: "readonly", Pass: "testpass"},
			Autoops: config.AutoopsConfig{
				Host: "127.0.0.1",
				Port: 27017,
				DB:   "autoops",
			},
		},
		Redis: config.RedisConfig{
			Global: config.Credential{User: "", Pass: ""},
		},
		PprofPortBases: map[string]int{
			"game":  27000,
			"cross": 28000,
			"gate":  24000,
		},
	}

	res, err := resolver.NewResolver(cfg)
	if err != nil {
		t.Fatalf("resolver.NewResolver: %v", err)
	}

	srv := mcp.NewServer(&mcp.Implementation{
		Name:    "game-mcp-gateway-test",
		Version: "0.0.1-test",
	}, nil)

	mcptools.RegisterMongoQuery(srv, res, cfg)
	mcptools.RegisterRedisQuery(srv, res, cfg)
	mcptools.RegisterPprofCollect(srv, res, cfg)
	mcptools.RegisterListInstances(srv, res)

	mcpHandler := mcp.NewStreamableHTTPHandler(
		func(_ *http.Request) *mcp.Server { return srv },
		&mcp.StreamableHTTPOptions{
			Stateless:    true,
			JSONResponse: true,
		},
	)

	mux := http.NewServeMux()
	mux.Handle("/mcp", auth.Middleware(cfg.Tokens)(mcpHandler))

	return httptest.NewServer(mux)
}

// mcpPost sends a JSON-RPC 2.0 message to the test server's /mcp endpoint.
//
// serverURL is ts.URL (not ts.URL+"/mcp"; the path is added internally).
// authToken may be empty (omits the Authorization header entirely) or a bearer
// token value.
//
// Returns the raw response body bytes and the HTTP status code.
func mcpPost(t *testing.T, serverURL, authToken, body string) ([]byte, int) {
	t.Helper()

	req, err := http.NewRequest(http.MethodPost, serverURL+"/mcp",
		strings.NewReader(body))
	if err != nil {
		t.Fatalf("http.NewRequest: %v", err)
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json, text/event-stream")
	if authToken != "" {
		req.Header.Set("Authorization", "Bearer "+authToken)
	}

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("HTTP POST /mcp: %v", err)
	}
	defer resp.Body.Close()

	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("io.ReadAll: %v", err)
	}
	return raw, resp.StatusCode
}

// decodeJSONRPCResult unmarshals the "result" field of a JSON-RPC 2.0 response
// into target.  It fails the test if the body is not valid JSON, if an
// "error" field is present, or if there is no "result" field.
//
// The function handles both plain JSON and SSE-wrapped ("data: {...}") response
// bodies that the MCP SDK may emit.
func decodeJSONRPCResult(t *testing.T, raw []byte, target any) {
	t.Helper()

	// Unwrap SSE "data: ..." line if present.
	jsonData := raw
	if idx := bytes.Index(raw, []byte("data: ")); idx >= 0 {
		start := idx + len("data: ")
		end := bytes.IndexByte(raw[start:], '\n')
		if end < 0 {
			end = len(raw[start:])
		}
		jsonData = bytes.TrimSpace(raw[start : start+end])
	}

	var envelope struct {
		Error  *json.RawMessage `json:"error"`
		Result *json.RawMessage `json:"result"`
	}
	if err := json.Unmarshal(jsonData, &envelope); err != nil {
		t.Fatalf("decodeJSONRPCResult: unmarshal envelope: %v\nbody: %s", err, raw)
	}
	if envelope.Error != nil {
		t.Fatalf("decodeJSONRPCResult: JSON-RPC error in response: %s", *envelope.Error)
	}
	if envelope.Result == nil {
		t.Fatalf("decodeJSONRPCResult: no 'result' field in response: %s", raw)
	}
	if err := json.Unmarshal(*envelope.Result, target); err != nil {
		t.Fatalf("decodeJSONRPCResult: unmarshal result: %v\nresult: %s", err, *envelope.Result)
	}
}
