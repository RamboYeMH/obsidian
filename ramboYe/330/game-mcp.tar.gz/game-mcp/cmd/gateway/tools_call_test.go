// Package main – integration tests for the tools/call endpoint.
//
// These tests supplement gateway_integration_test.go with additional
// tools/call-specific scenarios:
//
//   - Valid tools/call with an invalid instance name returns an MCP tool error
//     (IsError=true), not a panic or 5xx.
//   - Invalid MCP JSON body returns a protocol error, and the server remains
//     available for subsequent requests.
//   - Missing / wrong Authorization header returns HTTP 401.
//   - The server is still usable (tools/list returns 4 tools) after a sequence
//     of auth failures, protocol errors, and tool errors.
//
// The test server is built via newTestServer (defined in
// gateway_integration_test.go) which uses Stateless + JSONResponse mode so
// that individual HTTP requests do not require a session handshake.
//
// Requirements: 1.2, 1.3, 1.6, 2.5, 11.5
package main

import (
	"encoding/json"
	"net/http"
	"testing"
)

// ─────────────────────────────────────────────────────────────────────────────
// Auth rejection for tools/call
// ─────────────────────────────────────────────────────────────────────────────

// TestToolsCall_AuthRejection verifies that auth failures are applied equally
// to tools/call requests (Requirements: 2.5).
func TestToolsCall_AuthRejection(t *testing.T) {
	ts := newTestServer(t)
	defer ts.Close()

	const callBody = `{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"mongo_query","arguments":{"workspace":"test","instance":"game1","query":"db.x.find({})"}}}`

	cases := []struct {
		name  string
		token string // empty means no Authorization header
	}{
		{"no_auth_header", ""},
		{"wrong_token", wrongToken},
		{"empty_bearer_value", " "}, // "Bearer " + " " → invalid
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			var raw []byte
			var code int
			if tc.token == "" {
				// no Authorization header: pass empty string → mcpPost omits it
				raw, code = mcpPost(t, ts.URL, "", callBody)
			} else {
				raw, code = mcpPost(t, ts.URL, tc.token, callBody)
			}
			if code != http.StatusUnauthorized {
				t.Errorf("%s: expected HTTP 401, got %d; body: %s", tc.name, code, raw)
			}
		})
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// tools/call round-trip: bad instance name → MCP tool error (IsError=true)
// ─────────────────────────────────────────────────────────────────────────────

// TestToolsCall_BadInstanceName_IsToolError verifies that a tools/call for
// mongo_query with an invalid instance name returns a well-formed MCP result
// with IsError=true rather than a protocol-level error or a 5xx
// (Requirements: 1.2, 11.5).
func TestToolsCall_BadInstanceName_IsToolError(t *testing.T) {
	ts := newTestServer(t)
	defer ts.Close()

	badInstances := []struct {
		name     string
		instance string
	}{
		{"special_char", "badname!"},
		{"no_digits", "game"},
		{"digits_only", "12345"},
		{"spaces", "game 1"},
		{"empty", ""},
	}

	for _, tc := range badInstances {
		t.Run(tc.name, func(t *testing.T) {
			bodyStr, err := json.Marshal(map[string]any{
				"jsonrpc": "2.0",
				"id":      1,
				"method":  "tools/call",
				"params": map[string]any{
					"name": "mongo_query",
					"arguments": map[string]any{
						"workspace": "testenv",
						"instance": tc.instance,
						"query":    "db.x.find({})",
					},
				},
			})
			if err != nil {
				t.Fatalf("json.Marshal: %v", err)
			}

			raw, code := mcpPost(t, ts.URL, testToken, string(bodyStr))
			// The HTTP status must be 200 — the MCP layer is healthy.
			if code != http.StatusOK {
				t.Fatalf("instance=%q: expected HTTP 200, got %d; body: %s",
					tc.instance, code, raw)
			}

			// Parse the JSON-RPC envelope.
			var envelope map[string]json.RawMessage
			if err := json.Unmarshal(raw, &envelope); err != nil {
				t.Fatalf("instance=%q: invalid JSON: %v\nbody: %s", tc.instance, err, raw)
			}

			// No protocol-level error expected.
			if _, hasErr := envelope["error"]; hasErr {
				t.Errorf("instance=%q: unexpected JSON-RPC protocol error: %s",
					tc.instance, raw)
				return
			}
			if _, hasResult := envelope["result"]; !hasResult {
				t.Fatalf("instance=%q: no 'result' field in response: %s", tc.instance, raw)
			}

			// The result must have isError:true.
			var result struct {
				IsError bool              `json:"isError"`
				Content []json.RawMessage `json:"content"`
			}
			if err := json.Unmarshal(envelope["result"], &result); err != nil {
				t.Fatalf("instance=%q: unmarshal result: %v", tc.instance, err)
			}
			if !result.IsError {
				t.Errorf("instance=%q: expected result.isError=true, got false; body: %s",
					tc.instance, raw)
			}
			if len(result.Content) == 0 {
				t.Errorf("instance=%q: expected non-empty content in error result", tc.instance)
			}
		})
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// Protocol error: invalid JSON body does not crash the server
// ─────────────────────────────────────────────────────────────────────────────

// TestToolsCall_InvalidJSONBody_ServerSurvives verifies that sending non-JSON
// or structurally invalid JSON bodies does not panic or crash the server, and
// that the server remains fully available for valid requests afterwards
// (Requirements: 1.6, 11.5).
func TestToolsCall_InvalidJSONBody_ServerSurvives(t *testing.T) {
	ts := newTestServer(t)
	defer ts.Close()

	invalidBodies := []struct {
		name string
		body string
	}{
		{"not_json", `this is not json`},
		{"truncated_json", `{"jsonrpc":"2.0","id":1,"method":`},
		{"json_array", `[1, 2, 3]`},
		{"empty_body", ``},
	}

	for _, tc := range invalidBodies {
		t.Run(tc.name, func(t *testing.T) {
			raw, code := mcpPost(t, ts.URL, testToken, tc.body)

			// The server must not return 5xx — any other response is acceptable.
			if code >= 500 {
				t.Errorf("body=%q: server returned 5xx (%d): %s", tc.name, code, raw)
			}
		})
	}

	// After all invalid payloads, the server must still serve valid requests.
	t.Run("server_available_after_invalid_bodies", func(t *testing.T) {
		const listBody = `{"jsonrpc":"2.0","id":99,"method":"tools/list","params":{}}`
		raw, code := mcpPost(t, ts.URL, testToken, listBody)
		if code != http.StatusOK {
			t.Fatalf("tools/list after invalid bodies: expected 200, got %d; body: %s",
				code, raw)
		}

		var result struct {
			Tools []struct{ Name string `json:"name"` } `json:"tools"`
		}
		decodeJSONRPCResult(t, raw, &result)
		if len(result.Tools) != 4 {
			t.Errorf("expected 4 tools after invalid bodies, got %d", len(result.Tools))
		}
	})
}

// ─────────────────────────────────────────────────────────────────────────────
// Resilience: server stays available through a full error sequence
// ─────────────────────────────────────────────────────────────────────────────

// TestToolsCall_Resilience_FullErrorSequence exercises the combined resilience
// guarantee (Requirement 11.5):
//
//  1. Auth failure (missing token) → 401.
//  2. Auth failure (wrong token)   → 401.
//  3. Protocol error (invalid JSON)  → non-5xx.
//  4. Tool error (bad instance name) → 200 with isError:true.
//  5. Server still lists 4 tools via tools/list.
func TestToolsCall_Resilience_FullErrorSequence(t *testing.T) {
	ts := newTestServer(t)
	defer ts.Close()

	const callBody = `{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"mongo_query","arguments":{"workspace":"e","instance":"game1","query":"db.x.find({})"}}}`

	// Step 1: no auth.
	if raw, code := mcpPost(t, ts.URL, "", callBody); code != http.StatusUnauthorized {
		t.Errorf("step1 no_auth: expected 401, got %d; body: %s", code, raw)
	}

	// Step 2: wrong token.
	if raw, code := mcpPost(t, ts.URL, wrongToken, callBody); code != http.StatusUnauthorized {
		t.Errorf("step2 wrong_token: expected 401, got %d; body: %s", code, raw)
	}

	// Step 3: malformed JSON.
	if raw, code := mcpPost(t, ts.URL, testToken, `{bad json`); code >= 500 {
		t.Errorf("step3 bad_json: server returned 5xx (%d): %s", code, raw)
	}

	// Step 4: bad instance name → tool error (isError:true).
	const badInstanceBody = `{"jsonrpc":"2.0","id":4,"method":"tools/call","params":{"name":"mongo_query","arguments":{"workspace":"t","instance":"badname!","query":"db.x.find({})"}}}`
	raw4, code4 := mcpPost(t, ts.URL, testToken, badInstanceBody)
	if code4 != http.StatusOK {
		t.Errorf("step4 bad_instance: expected 200, got %d; body: %s", code4, raw4)
	}

	// Step 5: server must still list all 4 tools.
	const listBody = `{"jsonrpc":"2.0","id":5,"method":"tools/list","params":{}}`
	raw5, code5 := mcpPost(t, ts.URL, testToken, listBody)
	if code5 != http.StatusOK {
		t.Fatalf("step5 tools/list: expected 200, got %d; body: %s", code5, raw5)
	}

	var result struct {
		Tools []struct{ Name string `json:"name"` } `json:"tools"`
	}
	decodeJSONRPCResult(t, raw5, &result)
	if got := len(result.Tools); got != 4 {
		t.Errorf("step5: expected 4 tools after error sequence, got %d", got)
	}
}
