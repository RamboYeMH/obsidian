// Package main is the entry point for the MCP Gateway service.
//
// Assembly flow (Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 2.6, 3.12, 11.5):
//
//  1. Parse -config flag (default: ./config.yaml).
//  2. Load configuration via config.Load; exit(1) on failure.
//  3. Validate configuration via config.Validate; exit(1) on failure.
//  4. Build Service Resolver via resolver.NewResolver; exit(1) on failure.
//  5. Create MCP server and register all 4 tools.
//  6. Wrap the Streamable HTTP handler with the Bearer auth middleware.
//  7. Start the HTTP server; log the listening address to stderr.
//
// Single-call failures are captured by the MCP handler layer and returned as
// MCP tool errors — the process never exits on individual tool errors (11.5).
package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"

	"github.com/modelcontextprotocol/go-sdk/mcp"

	"game-mcp/internal/accesslog"
	"game-mcp/internal/auth"
	"game-mcp/internal/config"
	"game-mcp/internal/filestore"
	"game-mcp/internal/mcptools"
	"game-mcp/internal/resolver"
)

func main() {
	// ── 1. Parse flags ──────────────────────────────────────────────────────
	configPath := flag.String("config", "./config.yaml", "path to YAML config file")
	flag.Parse()

	// ── 2. Load configuration ────────────────────────────────────────────────
	cfg, err := config.Load(*configPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "gateway: failed to load config: %v\n", err)
		os.Exit(1)
	}

	// ── 3. Validate configuration (fills defaults, enforces required fields) ─
	if err := config.Validate(cfg); err != nil {
		fmt.Fprintf(os.Stderr, "gateway: invalid config: %v\n", err)
		os.Exit(1)
	}

	// ── 4. Build Service Resolver ────────────────────────────────────────────
	res, err := resolver.NewResolver(cfg)
	if err != nil {
		fmt.Fprintf(os.Stderr, "gateway: failed to create resolver: %v\n", err)
		os.Exit(1)
	}

	// ── 5. Create file store for pprof_save ──────────────────────────────────
	fs := filestore.New()

	// ── 6. Create MCP server and register all tools ───────────────────────────
	srv := mcp.NewServer(&mcp.Implementation{
		Name:    "game-mcp-gateway",
		Version: "1.0.0",
	}, nil)

	mcptools.RegisterMongoQuery(srv, res, cfg)
	mcptools.RegisterRedisQuery(srv, res, cfg)
	mcptools.RegisterPprofCollect(srv, res, cfg)
	mcptools.RegisterPprofSave(srv, res, cfg, fs)
	mcptools.RegisterListInstances(srv, res)
	mcptools.RegisterListWorkspaces(srv, res)

	// ── 7. Build HTTP mux: Streamable HTTP handler wrapped with auth ──────────
	//
	// The Streamable HTTP handler returned by the SDK is a standard http.Handler;
	// we wrap it with the Bearer-token auth middleware before mounting it.
	// Any tool-call failure is captured inside the handler and returned as an
	// MCP tool error (IsError=true) — the process does NOT exit (requirement 11.5).
	mcpHandler := mcp.NewStreamableHTTPHandler(
		func(_ *http.Request) *mcp.Server { return srv },
		&mcp.StreamableHTTPOptions{
			Stateless: true,
		},
	)

	endpoint := cfg.Server.Endpoint
	if endpoint == "" {
		endpoint = "/mcp"
	}

	accessLogger := accesslog.New(cfg.Log.Dir)

	mux := http.NewServeMux()
	mux.Handle(endpoint, corsMiddleware(accessLogger.Middleware(auth.Middleware(cfg.Tokens)(mcpHandler))))
	// /files/ serves pprof_save downloads — no Bearer auth; the UUID path
	// segment acts as an unguessable capability credential.
	mux.Handle("/files/", corsMiddleware(fs))

	// ── 8. Start HTTP server ─────────────────────────────────────────────────
	fmt.Fprintf(os.Stderr, "gateway: MCP Gateway listening on %s, endpoint %s\n",
		cfg.Server.Listen, endpoint)

	httpSrv := &http.Server{
		Addr:    cfg.Server.Listen,
		Handler: mux,
	}

	if err := httpSrv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("gateway: server error: %v\n", err)
	}
}

// corsMiddleware adds permissive CORS headers so that browser-based clients
// (e.g. the local testui/index.html opened via file://) can reach the gateway.
// Preflight OPTIONS requests are answered immediately with 204.
func corsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}
