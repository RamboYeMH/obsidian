// Package main integration test: tools/list returns all 4 MCP tools.
//
// This file:
//   - Defines the testToken constant shared across gateway integration tests.
//   - Provides buildTestServer (alias for newTestServer from
//     gateway_integration_test.go) for tools_call_test.go.
//   - Contains the tools/list integration tests for task 14.2.
//
// Requirements: 1.5
package main

import (
"bytes"
"encoding/json"
"net/http"
"net/http/httptest"
"testing"

"game-mcp/internal/mcptools"
)

// testToken is the Bearer token shared across all gateway integration tests.
// newTestServer (in gateway_integration_test.go) uses this constant to
// configure the test server's allowed token list.
const testToken = "test-integration-token-abc123"

// buildTestServer is an alias for newTestServer used by tools_call_test.go.
// newTestServer is defined in gateway_integration_test.go.
func buildTestServer(t *testing.T) *httptest.Server {
t.Helper()
return newTestServer(t)
}

// ---------------------------------------------------------------------------
// 14.2  tools/list — verify all 4 tools with names, descriptions, schemas
// Requirements: 1.5
// ---------------------------------------------------------------------------

// TestToolsList_ReturnsFourToolNames verifies that tools/list returns exactly
// the four expected MCP tool names.
func TestToolsList_ReturnsFourToolNames(t *testing.T) {
ts := buildTestServer(t)
defer ts.Close()

const body = `{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}`
raw, code := mcpPost(t, ts.URL, testToken, body)
if code != http.StatusOK {
t.Fatalf("expected HTTP 200, got %d\nbody: %s", code, raw)
}

var result struct {
Tools []struct {
Name string `json:"name"`
} `json:"tools"`
}
decodeJSONRPCResult(t, raw, &result)

byName := make(map[string]bool, len(result.Tools))
for _, tool := range result.Tools {
byName[tool.Name] = true
}

expectedNames := []string{
mcptools.ToolMongoQuery,
mcptools.ToolRedisQuery,
mcptools.ToolPprofCollect,
mcptools.ToolListInstances,
}

for _, name := range expectedNames {
if !byName[name] {
t.Errorf("tool %q not found in tools/list response", name)
}
}

if len(result.Tools) != len(expectedNames) {
names := make([]string, len(result.Tools))
for i, tool := range result.Tools {
names[i] = tool.Name
}
t.Errorf("expected %d tools, got %d: %v", len(expectedNames), len(result.Tools), names)
}
}

// TestToolsList_EachToolHasDescription verifies that every tool has a
// non-empty description field.
func TestToolsList_EachToolHasDescription(t *testing.T) {
ts := buildTestServer(t)
defer ts.Close()

const body = `{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}`
raw, code := mcpPost(t, ts.URL, testToken, body)
if code != http.StatusOK {
t.Fatalf("expected HTTP 200, got %d\nbody: %s", code, raw)
}

var result struct {
Tools []struct {
Name        string `json:"name"`
Description string `json:"description"`
} `json:"tools"`
}
decodeJSONRPCResult(t, raw, &result)

for _, tool := range result.Tools {
if tool.Description == "" {
t.Errorf("tool %q has empty description", tool.Name)
}
}
}

// TestToolsList_EachToolHasInputSchema verifies that every tool exposes a
// non-empty JSON object inputSchema.
func TestToolsList_EachToolHasInputSchema(t *testing.T) {
ts := buildTestServer(t)
defer ts.Close()

const body = `{"jsonrpc":"2.0","id":3,"method":"tools/list","params":{}}`
raw, code := mcpPost(t, ts.URL, testToken, body)
if code != http.StatusOK {
t.Fatalf("expected HTTP 200, got %d\nbody: %s", code, raw)
}

var result struct {
Tools []struct {
Name        string          `json:"name"`
InputSchema json.RawMessage `json:"inputSchema"`
} `json:"tools"`
}
decodeJSONRPCResult(t, raw, &result)

for _, tool := range result.Tools {
schema := bytes.TrimSpace(tool.InputSchema)
if len(schema) == 0 || bytes.Equal(schema, []byte("null")) {
t.Errorf("tool %q has nil/empty inputSchema", tool.Name)
continue
}
if schema[0] != '{' {
t.Errorf("tool %q inputSchema is not a JSON object: %s", tool.Name, schema)
}
}
}

// TestToolsList_UnauthorizedIsRejected verifies that tools/list requests
// without a valid Bearer token are rejected with HTTP 401 by the auth
// middleware. Requirements: 2.5
func TestToolsList_UnauthorizedIsRejected(t *testing.T) {
ts := buildTestServer(t)
defer ts.Close()

const body = `{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}`

// No auth header (empty token → mcpPost omits the header).
raw, code := mcpPost(t, ts.URL, "", body)
if code != http.StatusUnauthorized {
t.Errorf("no auth: expected HTTP 401, got %d; body: %s", code, raw)
}

// Wrong token.
raw, code = mcpPost(t, ts.URL, wrongToken, body)
if code != http.StatusUnauthorized {
t.Errorf("wrong token: expected HTTP 401, got %d; body: %s", code, raw)
}
}
