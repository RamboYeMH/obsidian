// Package main is the entry point for the MCP Gateway service.
// See main.go for the full assembly implementation.
package main
