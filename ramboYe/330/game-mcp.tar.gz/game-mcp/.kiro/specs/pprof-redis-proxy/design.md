# Design Document

## Overview

本设计将现有的只读 MongoDB CLI 代理（`main.go` 中的 `mgq`）演进为一个 **统一的游戏运维查询
网关（MCP Gateway）**。网关是 **单一的 Go 服务进程**，部署在 **内网（LAN）之内**，通过 MCP
**Streamable HTTP** 传输向 **远程 LLM 客户端** 暴露 4 个只读工具：`mongo_query`、`redis_query`、
`pprof_collect`、`list_instances`。

核心设计目标是 **对调用方隐藏全部内网拓扑**：客户端只需持有一个有效 Bearer Token，以及逻辑
选择器 `project` / `env`（必要时加 `instance`），网关在内部完成 **集群选取 → 实例解析 → 路由 →
只读执行 → 结果回传**。所有主机 IP、端口、连接串、etcd endpoints、Redis 地址与数据库凭据均不
对调用方暴露。

设计的两个支柱：

1. **复用 `mgq` 的安全模型**：MongoDB 的只读方法白名单、游标链白名单、对 server-side JS 与
   aggregate 写阶段的结构化拒绝、shell 风格输入归一化等逻辑，从 CLI 重构为可复用的库函数。
   关键重构点是把 `die()/os.Exit()` 的“出错即退出”改为“返回 error”，使服务不会因单次查询失败
   而退出。

2. **etcd 优先的双后端 Service Resolver**：若配置文件为某 `(project, env)` 配置了 etcd 集群，则
   **仅用 etcd** 解析；否则回退到既有的 mongo `autoops`（`processes` 集合）解析。无论走哪条路径，
   连接 **始终注入配置文件中的只读账号**，etcd `DBURL` / `vars.dburl` 内嵌的凭据 **绝不使用、
   绝不暴露**，任何内部呈现都对密码做掩码。

本设计映射到需求 1–11 的全部验收标准，详见每节末尾的「Requirements 映射」与文末「安全姿态映射表」。

### 技术选型决策

- **MCP SDK：推荐官方 `github.com/modelcontextprotocol/go-sdk`**（与 Google 合作维护）。理由：
  原生提供 Streamable HTTP 的 `http.Handler`（可直接被标准 `net/http` 中间件包裹，便于实现
  Bearer 鉴权），与 MCP 2025 版传输规范一致，工具 schema 通过 Go 结构体 + 反射生成，便于满足
  需求 10 的自描述要求。
  - **备选**：`github.com/mark3labs/mcp-go`（社区活跃，亦支持 stdio / SSE / streamable-HTTP，
    提供 `server.NewStreamableHTTPServer` 与 handler 中间件）。
  - 该选型为 **可调整的设计决策**（见文末「Decisions & Open Items」）；二者均以 `http.Handler`
    形态接入，故下游架构（鉴权中间件、工具分发）不随选型变化。
- **MongoDB 驱动**：沿用 `main.go` 已使用的 `go.mongodb.org/mongo-driver`。
- **Redis 客户端**：推荐 `github.com/redis/go-redis/v9`（原 `go-redis`，社区主流、维护活跃，
  支持连接池与 `Do()` 通用命令执行，便于按白名单转发任意只读命令）。
- **etcd 客户端**：`go.etcd.io/etcd/client/v3`，仅使用只读 `Get`（含 `WithPrefix`）。
- **配置解析**：`gopkg.in/yaml.v3`。

## Architecture

### 组件总览

网关采用分层结构：传输层接收请求，鉴权中间件校验 Token，工具分发层路由到具体工具处理器，
所有工具共享同一个 Service Resolver 完成实例解析与路由，再由各后端适配器执行只读操作。

```mermaid
flowchart TD
    subgraph Remote["远程（公网/办公网）"]
        LLM["LLM 客户端"]
    end

    subgraph LAN["内网 (LAN) — MCP Gateway 进程"]
        direction TB
        HTTP["Streamable HTTP 传输层<br/>(单一 MCP Endpoint)"]
        AUTH["Auth 中间件<br/>Bearer Token 白名单校验"]
        DISP["Tool Dispatch<br/>tools/list · tools/call"]
        subgraph TOOLS["工具处理器"]
            MQ["mongo_query"]
            RQ["redis_query"]
            PC["pprof_collect"]
            LI["list_instances"]
        end
        RES["Service Resolver<br/>(etcd 优先双后端)"]
        CFG["Config Loader<br/>(启动时加载+校验)"]
    end

    subgraph Backends["内网后端"]
        ETCD[("etcd 集群<br/>只读 get/prefix")]
        AUTOOPS[("mongo autoops<br/>processes/hosts")]
        TMONGO[("目标 MongoDB<br/>只读账号")]
        REDIS[("Redis<br/>只读命令")]
        PPROF["pprof HTTP 端点<br/>/debug/pprof/*"]
    end

    LLM -- "HTTP POST/GET + Bearer" --> HTTP
    HTTP --> AUTH --> DISP
    DISP --> MQ & RQ & PC & LI
    MQ & RQ & PC & LI --> RES
    CFG -. 启动注入 .-> AUTH
    CFG -. 启动注入 .-> RES
    RES -->|"已配置 etcd"| ETCD
    RES -->|"未配置 etcd:回退"| AUTOOPS
    MQ --> TMONGO
    RQ --> REDIS
    PC --> PPROF
    LI --> ETCD & AUTOOPS
```

### 部署上下文

- 网关进程运行在内网内，可直达各主机内网 IP（lanip）与内部服务端口（mongo、redis、pprof）。
- 远程 LLM 客户端经 Streamable HTTP 连接网关单一 Endpoint，所有请求必须携带 Bearer Token。
- 配置文件随进程部署在网关主机，不通过任何工具暴露。
- 凭 LAN 边界 + Bearer Token 构成访问控制；网关本身不监听公网（监听地址由配置文件指定，建议
  绑定内网网卡或经反向代理收口）。

### 请求处理时序

```mermaid
sequenceDiagram
    participant C as LLM 客户端
    participant H as HTTP 传输层
    participant A as Auth 中间件
    participant T as 工具处理器
    participant R as Service Resolver
    participant B as 后端

    C->>H: POST /mcp (Bearer Token, tools/call)
    H->>A: 转交请求
    A->>A: 提取 Authorization: Bearer，比对白名单 token 值
    alt Token 无效/缺失
        A-->>C: 鉴权失败错误（不触达任何后端）
    else Token 有效
        A->>T: 进入工具处理器
        T->>T: 输入校验（实例名/方法/命令/profile/seconds）
        alt 校验失败
            T-->>C: MCP 工具错误（不访问内网资源）
        else 校验通过
            T->>R: Resolve(project, env, instance)
            R->>B: etcd get 或 mongo autoops 查询
            B-->>R: ResolvedTarget
            T->>B: 只读执行（注入只读账号 / 白名单命令 / GET）
            B-->>T: 结果
            T-->>C: 结构化结果（掩码后）
        end
    end
```

## Components and Interfaces

### 包结构（Project Layout）

```
cmd/
  gateway/
    main.go              // 入口：加载配置→构建 Resolver/工具→启动 Streamable HTTP
internal/
  config/
    config.go            // 配置结构体 + 加载 + 启动校验
  auth/
    auth.go              // Bearer 提取 + 白名单匹配中间件
  resolver/
    resolver.go          // Service Resolver：实例名解析 + etcd/mongo 双后端路由
    instance.go          // 实例名解析（复用 parseArg 风格正则）
    dbname.go            // buildDBName + {env}_ 前缀逻辑
  mongoq/                // 由 main.go 重构而来的可复用只读查询库
    parse.go             // parseQuery/parseCursorChain/normalizeMongoJSON...
    guard.go             // assertNoServerSideJS/assertNoWriteStage
    run.go               // RunQuery：返回 (result, error)，不再 die/os.Exit
  redisq/
    redisq.go            // 只读命令白名单 + 命令分词 + 执行
  pprofx/
    pprofx.go            // URL 构建 + HTTP GET + cmdline 脱敏 + base64
    redact.go            // 密钥脱敏（连接串/flag/URL 参数）
  secret/
    mask.go              // 统一的 DBURL 密码掩码 + cmdline 脱敏原语（被多处复用）
  mcptools/
    mongo_query.go       // 4 个 MCP 工具的 schema + handler
    redis_query.go
    pprof_collect.go
    list_instances.go
    meta.go              // 工具描述/参数 schema 文案（满足需求 10）
  gwerr/
    gwerr.go             // 网关错误类型 → MCP 工具错误映射
```

设计原则：`internal/mongoq`、`internal/redisq`、`internal/pprofx` 为 **纯逻辑 / IO 适配** 库，
不依赖 MCP；`internal/mcptools` 仅做 schema 暴露与 handler 编排，调用上述库与 `resolver`。这样
既复用 `mgq` 安全模型，又满足需求 9.x 的关注点分离与可测试性。

### 关键接口签名（伪代码）

```go
// internal/resolver
type Resolver struct {
    cfg        *config.Config
    etcdPool   *etcdClientPool   // 按 (project,env) 复用 etcd 客户端
    autoops    *mongo.Client     // autoops 管理库连接（只读账号）
}

// Resolve 解析实例名并按 etcd 优先/mongo 回退路由，返回统一目标。
func (r *Resolver) Resolve(ctx context.Context, project, env, instance string) (*ResolvedTarget, error)

// ListInstances 按 etcd 前缀或 processes 集合列举实例（不含任何凭据）。
func (r *Resolver) ListInstances(ctx context.Context, project, env string) ([]InstanceInfo, error)

// internal/mongoq —— 由 main.go 重构（die→error）
func ParseQuery(query string) (*ParsedQuery, error)
func ParseCursorChain(chain string) (CursorMods, error)
func AssertNoServerSideJS(v any) error          // 原 die → 返回 error
func AssertNoWriteStage(pipeline []bson.M) error
func NormalizeMongoJSON(s string) string
func RunQuery(ctx context.Context, cli *mongo.Client, dbName, query string, maxLimit int64) (any, error)

// internal/redisq
func ExecCommand(ctx context.Context, cli redis.UniversalClient, command string) (any, error)

// internal/pprofx
func Collect(ctx context.Context, hostIP string, port int, profile string, seconds *int) ([]byte, error)
func RedactCmdline(raw []byte) ([]byte, error)   // 脱敏失败返回 error

// internal/secret
func MaskDBURL(dburl string) string              // user:pass@host → user:****@host
```

### Streamable HTTP 接入与鉴权（需求 1、2）

入口将官方 SDK 生成的 `http.Handler` 用 `auth.Middleware` 包裹，再交给标准 `http.Server`：

```go
mcpHandler := mcp.NewStreamableHTTPHandler(func(*http.Request) *mcp.Server { return srv }, nil)
mux := http.NewServeMux()
mux.Handle(cfg.Server.Endpoint, auth.Middleware(cfg.Tokens)(mcpHandler))
http.ListenAndServe(cfg.Server.Listen, mux)
```

- 传输层负责需求 1.2/1.3/1.4：POST 消息、单条 JSON 或 SSE 响应、GET 打开服务端→客户端 SSE 流，
  均由 SDK 的 Streamable HTTP handler 实现。
- 非法 MCP 消息（需求 1.6）由 SDK 返回协议错误且不影响后续请求；鉴权中间件仅在传输层之上拦截。

**Requirements 映射**：需求 1（全部）、需求 2（全部）、需求 10（工具 schema 由 SDK 暴露）。

## Data Models

### 配置文件（YAML 完整示例）

```yaml
server:
  listen: "0.0.0.0:8080"        # MCP 监听地址:端口（需求 3.11）
  endpoint: "/mcp"              # 单一 MCP Endpoint 路径（需求 1.1）

# Token 白名单：结构化条目 [{name, token}]（需求 2.1、3.1）
# name 仅作备注/审计标签，不参与鉴权；token 为实际 Bearer 凭据值。
tokens:
  - name: "alice@dev"
    token: "s3cr3t-token-alice"
  - name: "ops-bot"
    token: "s3cr3t-token-bot"

# 所有 mongo 连接（autoops + 目标库）统一使用的只读账号（需求 3.5、9.1）
mongo:
  readonly:
    user: "readonly"
    pass: "ro-pass#"
  # mongo 回退模型使用的管理库（autoops_v2）接入信息（需求 4.11）
  autoops:
    host: "192.168.50.118"
    port: 20015
    db: "autoops_v2"
    # 可选：覆盖访问 autoops 管理库所用账号（仅回退路径；缺省用 mongo.readonly）
    account:
      user: "dev"
      pass: "111#"

# etcd 集群：按 project → env 组织（需求 3.2、4.3）
# 某 (project,env) 在此出现 → 仅用 etcd；否则回退 mongo autoops。
etcd:
  h5:                            # project
    h5dev2:                      # env（版本级别）
      endpoints: ["192.168.50.11:2379"]
      db_name_group: false       # 缺省 false（需求 3.4）
      namespace: true            # 缺省 true（需求 3.3）
    h5gold:
      endpoints: ["192.168.50.21:2379", "192.168.50.22:2379"]
      db_name_group: true
      namespace: true
  ice:                           # 历史项目：生产无 namespace 前缀
    iceprod:
      endpoints: ["192.168.60.11:2379"]
      namespace: false

# Redis：全局默认凭据 + 按 env 覆盖（需求 3.6、3.7、6.x）
redis:
  global:                        # 全局默认凭据
    user: ""                     # 可空（无 ACL 用户时）
    pass: "redis-global-pass"
  envs:
    h5dev2:
      addr: "192.168.50.30:6379" # etcd 模型下 Redis 地址来自配置（需求 6.2）
      # 可选：覆盖该 env 的 Redis 凭据（优先于 global）（需求 3.8）
      user: ""
      pass: "redis-dev2-pass"
      # 可选：按 service 覆盖地址/凭据（最高优先级）
      services:
        cross:
          addr: "192.168.50.31:6379"
          pass: "redis-cross-pass"
    h5gold:
      addr: "192.168.50.40:6379"
      # 未配置 user/pass → 使用 redis.global（需求 3.9）

# pprof 端口基准：覆盖内置默认 game=27000/cross=28000/gate=24000（需求 3.10、7.18）
pprof_port_bases:
  game: 27000
  cross: 28000
  gate: 24000
  actv: 26000                    # 覆盖/新增示例
```

### 凭据优先级规则（明确定义）

| 资源 | 优先级（高 → 低） | 来源 | 约束 |
|------|------------------|------|------|
| Redis 凭据/地址 | service 覆盖 `redis.envs.<env>.services.<svc>` > 按 env `redis.envs.<env>` > 全局 `redis.global` | 配置文件 | 需求 3.8/3.9、6.4 |
| Redis 地址（etcd 模型） | service 覆盖 > 按 env `redis.envs.<env>.addr` | 配置文件 | etcd 不携带 Redis 信息（需求 6.2） |
| Redis 地址（mongo 回退） | `processes.vars.redis` | 管理库 | 缺失/空白 → 报错（需求 6.3/6.5） |
| autoops 管理库账号 | `mongo.autoops.account` 覆盖（仅回退路径） > `mongo.readonly` | 配置文件 | 需求 4.11 |
| 目标库账号 | **始终** `mongo.readonly` | 配置文件 | 不可被覆盖（需求 4.14、5.3、9.1） |
| etcd `DBURL` / `vars.dburl` 内嵌凭据 | **永不使用** | — | 仅取 host:port + 库名；密码掩码（需求 4.8/4.15、9.7） |

> 说明：`mongo.autoops.account` 仅用于读取管理库（`processes`/`hosts`），属于内部解析所需的只读
> 访问；目标业务库 **始终** 使用 `mongo.readonly`，且不受任何覆盖影响。

### 配置校验（启动时，需求 2.6、3.12）

启动时执行校验，任一失败 → 写错误到 stderr 并 **拒绝启动**（非 panic 的受控退出）：

1. **Token 白名单为空或缺失** → 拒绝启动（需求 2.6）。
2. **缺少必填项**：`mongo.readonly`（user/pass）、`tokens`、`server.listen` 缺失 → 拒绝启动
   （需求 3.12）。
3. **配置文件缺失或无法解析（YAML 语法错误）** → 拒绝启动（需求 3.12）。
4. **pprof 端口基准非法**：基准值非 1..65535 整数、或键非合法 service-type → 拒绝启动。
5. 内置默认端口基准（game/cross/gate）在未被覆盖时自动注入；`namespace` 缺省 `true`、
   `db_name_group` 缺省 `false`（需求 3.3/3.4）。

### Go 配置结构体

```go
type Config struct {
    Server  ServerConfig                       `yaml:"server"`
    Tokens  []TokenEntry                       `yaml:"tokens"`
    Mongo   MongoConfig                        `yaml:"mongo"`
    Etcd    map[string]map[string]EtcdCluster  `yaml:"etcd"`   // project -> env -> cluster
    Redis   RedisConfig                        `yaml:"redis"`
    PprofPortBases map[string]int              `yaml:"pprof_port_bases"`
}

type ServerConfig struct {
    Listen   string `yaml:"listen"`
    Endpoint string `yaml:"endpoint"`
}

type TokenEntry struct {
    Name  string `yaml:"name"`   // 备注/审计，不参与鉴权
    Token string `yaml:"token"`  // 实际 Bearer 凭据值
}

type MongoConfig struct {
    Readonly Credential   `yaml:"readonly"`
    Autoops  AutoopsConfig `yaml:"autoops"`
}
type Credential struct {
    User string `yaml:"user"`
    Pass string `yaml:"pass"`
}
type AutoopsConfig struct {
    Host    string      `yaml:"host"`
    Port    int         `yaml:"port"`
    DB      string      `yaml:"db"`
    Account *Credential `yaml:"account"` // 可空：覆盖管理库账号（仅回退路径）
}

type EtcdCluster struct {
    Endpoints   []string `yaml:"endpoints"`
    DBNameGroup *bool    `yaml:"db_name_group"` // 指针区分“未设置(默认 false)”
    Namespace   *bool    `yaml:"namespace"`     // 指针区分“未设置(默认 true)”
}

type RedisConfig struct {
    Global Credential               `yaml:"global"`
    Envs   map[string]RedisEnv      `yaml:"envs"`
}
type RedisEnv struct {
    Addr     string                    `yaml:"addr"`
    User     *string                   `yaml:"user"`
    Pass     *string                   `yaml:"pass"`
    Services map[string]RedisService   `yaml:"services"`
}
type RedisService struct {
    Addr string  `yaml:"addr"`
    User *string `yaml:"user"`
    Pass *string `yaml:"pass"`
}
```

### ResolvedTarget（解析器统一输出）

```go
type Backend int
const (
    BackendEtcd Backend = iota
    BackendMongoFallback
)

type ResolvedTarget struct {
    Project     string
    Env         string
    Service     string  // service-type（保留原大小写）
    ServerID    string  // serverid（十进制字符串）
    ServerIDNum int     // serverid 数值（用于端口推导）
    Backend     Backend

    // mongo 路由（凭据不在此结构中；连接时统一注入 mongo.readonly）
    MongoHostPort string // host:port（来自 DBURL/vars.dburl，已剥离凭据）
    MongoDBName   string // 已按 db_name_group 应用 {env}_ 前缀

    // pprof
    PprofHostIP string // etcd: Addr 的 IP 部分；mongo: hosts.lanip（待确认）

    // redis（地址来源；凭据按优先级在 redis_query 内解析）
    RedisAddr string // etcd 模型: 配置；mongo 回退: vars.redis
}

type InstanceInfo struct {
    Instance string // service-type + serverid，可直接用于其它工具
    Label    string // 可选展示信息（不含任何凭据）
}
```

### etcd Value 数据模型

```go
type EtcdValue struct {
    Name   string `json:"Name"`
    Addr   string `json:"Addr"`   // <ip>:<port>，pprof IP 取其 IP 部分
    Label  string `json:"Label"`
    Weight int    `json:"Weight"`
    DBURL  string `json:"DBURL"`  // user:pass@host:port/db?... 仅取 host:port+db
}
```

## Service Resolver Design（核心）

Service Resolver 是网关的路由中枢，所有 4 个工具都通过它把 `(project, env, instance)` 翻译为
具体的后端目标。它本身 **不是** MCP 工具，不对外暴露。

### 实例名解析（复用 main.go 的 parseArg 风格）

沿用 `main.go` 中 `parseArg` 的 `^([a-zA-Z]+)(\d+)$` 正则，但改为返回 error 而非 `die`：

```go
var instanceRe = regexp.MustCompile(`^([a-zA-Z]+)(\d+)$`)

func ParseInstance(name string) (service string, serverID string, num int, err error) {
    m := instanceRe.FindStringSubmatch(name)
    if m == nil {
        return "", "", 0, gwerr.Validation(
            "实例名格式错误：应为 <service><id>（前导字母为 service-type，结尾数字为 serverid），例如 game1")
    }
    service = m[1]                 // 保留原大小写（需求 4.1）
    serverID = m[2]
    num, _ = strconv.Atoi(serverID)
    return
}
```

- service-type 大小写原样保留（需求 4.1）。
- 空串、无前导字母、无结尾数字、含 `[A-Za-z0-9]` 以外字符 → 校验错误，不解析任何目标（需求 4.2）。

### etcd 优先决策流

```mermaid
flowchart TD
    A["Resolve(project, env, instance)"] --> B["ParseInstance → service, serverid"]
    B -->|格式非法| ERR1["返回校验错误<br/>(需求 4.2)"]
    B --> C{"config.etcd[project][env]<br/>存在?"}
    C -->|是| D["etcd 路径（仅 etcd，不回退）"]
    C -->|否| E["mongo autoops 回退路径"]

    D --> D1{"namespace flag"}
    D1 -->|true| D2["key = {env}/{project}/gs/{service}/{serverid}"]
    D1 -->|false| D3["key = {project}/gs/{service}/{serverid}"]
    D2 --> D4["etcd Get(key)"]
    D3 --> D4
    D4 -->|未找到| ERR2["实例不存在(含实例名)<br/>(需求 4.10)"]
    D4 --> D5["解析 EtcdValue JSON"]
    D5 --> D6["DBURL→host:port+db（剥离凭据）"]
    D6 --> D7{"db_name_group?"}
    D7 -->|true| D8["dbName = {env}_ + db"]
    D7 -->|false| D9["dbName = db"]
    D8 --> D10["pprofIP = IP(Addr)（待确认）"]
    D9 --> D10
    D10 --> OUT["ResolvedTarget"]

    E --> E1["processes.findOne<br/>{project, serverName:service, vars.id:serverid}"]
    E1 -->|0 条| ERR3["实例不存在(含实例名)<br/>(需求 4.12)"]
    E1 -->|>1 条| ERR4["实例不唯一(含实例名+数量)<br/>(需求 4.13)"]
    E1 --> E2["parseHostPort(vars.dburl)<br/>buildDBName(service,id,csv)"]
    E2 --> E3["host_id→hosts.lanip 作 pprofIP（待确认）"]
    E3 --> E4["redisAddr = vars.redis"]
    E4 --> OUT
```

判定准则：配置文件 `etcd[project][env]` 存在即 **仅用 etcd**（需求 4.4，绝不回退 mongo）；
否则进入 mongo `autoops` 回退路径（需求 4.11）。

### etcd 路径细节

- **key 模板**（需求 4.5/4.6）：
  - `namespace=true` → `{env}/{project}/gs/{service}/{serverid}`（如 `h5dev2/h5/gs/actv/1`）。
  - `namespace=false` → `{project}/gs/{service}/{serverid}`（如 `ice` 生产）。
- **value 解析**（需求 4.7）：JSON 反序列化为 `EtcdValue{Name, Addr, Label, Weight, DBURL}`。
- **DBURL → 路由**（需求 4.8）：复用 `mgq` 的 `parseHostPort` 思路从 `DBURL` 取 `host:port` 与
  库名；**仅** 用于路由，内嵌凭据丢弃。
- **库名前缀**（需求 4.9）：`db_name_group=true` → `dbName = "{env}_" + db`；否则不加前缀。
- **pprof 主机 IP**（需求 4 / 7.7，**待确认**）：取 `Addr` 的 IP 部分
  （`192.168.5.29:22032` → `192.168.5.29`）。
- **未找到**（需求 4.10）：返回含实例名的「实例不存在」错误。

### mongo 回退路径细节（复用 main.go）

直接复用既有逻辑（重构为返回 error）：

- **过滤**（需求 4.11）：`processes.findOne({project, serverName: service, "vars.id": serverid})`，
  投影 `vars.dburl`、`vars.csv`、`host_id`、`vars.redis`。
- **host:port**：`parseHostPort(vars.dburl, autoops.host)`（保留旧/新两种格式分支）。
- **库名**：`buildDBName(service, id, csv)`（gdconfig / global·webserver·door / 默认三类规则）。
- **唯一性**：用 `Find` + 计数检测；0 条→「实例不存在」（需求 4.12），>1 条→「实例不唯一」含
  数量（需求 4.13）。
- **pprof IP**（需求 7.8，**待确认**）：`processes.host_id` →
  `hosts.findOne({_id: host_id})` → `lanip`。
- **redis 地址**（需求 6.3）：`vars.redis`。

### 凭据注入与掩码（在 Resolver 统一强制）

- 任何 mongo 连接（autoops 与目标库）在构建 URI 时 **只** 注入 `mongo.readonly`
  （autoops 可选 `mongo.autoops.account` 覆盖）——`ResolvedTarget` 中 **不** 携带任何凭据
  （需求 4.14、5.3、9.1）。
- 任何对 `DBURL` / `vars.dburl` 的日志或错误呈现，先经 `secret.MaskDBURL` 把
  `user:pass@host` → `user:****@host`（需求 4.15、9.9、11.4）。
- 连接超时统一 10s，超时/失败 → 连接错误（需求 4.16）。

**Requirements 映射**：需求 4（全部）、需求 9.1/9.7/9.8、需求 11.4。

## Tool Designs

四个工具共享：先经 Auth 中间件鉴权；handler 内先做输入校验（失败即返回，不触达内网，需求 11.3），
再经 Resolver 解析，最后只读执行。结果与错误统一经掩码层处理。

### mongo_query

**MCP 输入 schema**（字段描述需足够 LLM 自动路由，需求 10）：

```go
type MongoQueryInput struct {
    Project  string `json:"project"  jsonschema:"游戏项目标识，如 h5/ice"`
    Env      string `json:"env"      jsonschema:"环境/版本级别(version level)，如 h5dev2/h5gold/h5prod"`
    Instance string `json:"instance" jsonschema:"实例名 <service><id>，如 game1/gate5/cross1008"`
    Query    string `json:"query"    jsonschema:"mongo shell 风格只读查询，仅允许 find/findOne/count/countDocuments/estimatedDocumentCount/aggregate/distinct，链式仅 .sort/.skip/.limit；亦支持 'show tables'"`
}
```

**执行流**：

1. 校验 instance 格式（`ParseInstance`）。
2. `Resolver.Resolve` → `MongoHostPort` + `MongoDBName`。
3. 用 `mongo.readonly` 拼 URI 连接目标库（需求 5.3、9.1）。
4. 调用重构后的 `mongoq.RunQuery(ctx, cli, dbName, query, maxLimit)`，其内部沿用 `mgq` 的
   `parseQuery` / `parseCursorChain` / `assertNoServerSideJS` / `assertNoWriteStage` /
   `normalizeMongoJSON` / `runQuery` 安全模型。
5. 成功 → 结果序列化为 JSON 返回（需求 5.9、11.1）。

**复用与必做重构**：`main.go` 当前的 `parseQuery`、`parseCursorChain`、`assertNoServerSideJS`、
`assertNoWriteStage`、`normalizeMongoJSON`、`runQuery` 等包级函数基本 **逐字复用其安全逻辑**，
但有一处 **必须重构**：当前实现用 `die()`（内部 `os.Exit(1)`）处理错误，在长驻服务中会导致
进程退出。重构要求：

- 把 `die(...)` 改为 `return ..., fmt.Errorf(...)` / 返回 `gwerr` 错误；
- `assertNoServerSideJS` / `assertNoWriteStage` 由 `die` 改为返回 error 并逐层向上传播；
- `runQuery` 由直接 `fmt.Println` 输出改为收集结果并 `return (any, error)`，由工具层序列化；
- `printResults` 改为返回 `[]bson.M` 而非打印。

**错误映射**（需求 5.6/5.7/5.8/5.10 → MCP 工具错误）：

| 情况 | MCP 工具错误消息 |
|------|-----------------|
| 非白名单方法 | 「不支持的方法: X（仅允许 ...）」 |
| server-side JS（$where/$function/$accumulator） | 「禁止使用 server-side JS 操作符: X」 |
| aggregate 写阶段（$out/$merge） | 「aggregate 中禁止使用写阶段: X」 |
| 格式无法识别 / 执行失败 | 「<原因>」（如适用，掩码 DBURL） |

**结果形状**：`mongo_query` 返回 JSON（数组/对象/标量，取决于方法）。

**Requirements 映射**：需求 5（全部）、9.2、10.5、11.1/11.2。

### redis_query

**MCP 输入 schema**：

```go
type RedisQueryInput struct {
    Project  string `json:"project"`
    Env      string `json:"env"`
    Instance string `json:"instance"`
    Command  string `json:"command"  jsonschema:"只读 Redis 命令，如 'GET key'、'HGETALL h'、'SCAN 0 MATCH p:* COUNT 100'；仅允许只读命令白名单"`
}
```

**执行流**：

1. 校验 instance 格式。
2. `Resolver.Resolve` → `RedisAddr`（etcd 模型来自配置 `redis.envs.<env>`，含 service 覆盖；
   mongo 回退来自 `vars.redis`）。回退模型下 `vars.redis` 缺失/空白 → 报错（需求 6.5）。
3. 按优先级解析凭据：service 覆盖 > 按 env > 全局（需求 6.4，见凭据优先级表）。
4. 命令分词：复用 `main.go` 的 `splitTopLevel` 风格做安全分词（尊重引号），取首 token 作命令名。
5. 命令名（不区分大小写）查只读命令白名单：命中 → `go-redis` 的 `Do(ctx, args...)` 执行
   （需求 6.7）；否则按类别返回错误（见下）。
6. 成功 → 结果返回（需求 11.1）。

**只读命令白名单**（需求 6.6，可配置扩展）：
`GET, MGET, HGET, HGETALL, HMGET, HKEYS, HVALS, HLEN, LRANGE, LLEN, LINDEX, SMEMBERS,
SISMEMBER, SCARD, ZRANGE, ZRANGEBYSCORE, ZSCORE, ZCARD, TYPE, TTL, PTTL, EXISTS, STRLEN,
SCAN, HSCAN, SSCAN, ZSCAN, GETRANGE, DBSIZE, INFO`。

**拒绝分类**（默认拒绝；非白名单一律拒绝）：

| 类别 | 示例 | 错误消息（需求） |
|------|------|------|
| 写命令 | SET/DEL/EXPIRE/`FLUSH*`/LPUSH/HSET... | 「仅允许只读命令」（6.8） |
| 危险命令 | CONFIG/EVAL/FLUSHALL/FLUSHDB/SHUTDOWN/SCRIPT/DEBUG | 「命令被拒绝」（6.9） |
| 其它未列入白名单 | 任意未知命令 | 「不支持的命令」（6.10） |

> 实现注意：先判危险命令集合（6.9），再判写命令集合（6.8），最后白名单兜底（6.10），保证消息
> 分类稳定。`SCAN`/`HSCAN` 等游标命令允许携带 `MATCH`/`COUNT` 只读子参数。

**错误映射**：连接失败 / 执行失败 → 含原因的 MCP 工具错误（需求 6.11、11.2）。
**结果形状**：按命令返回（字符串、数组、map for HGETALL、整型 for TTL/EXISTS 等）。

**Requirements 映射**：需求 6（全部）、3.8/3.9、9.3、11.1/11.2。

### pprof_collect

**MCP 输入 schema**（需求 10.4）：

```go
type PprofCollectInput struct {
    Project  string `json:"project"`
    Env      string `json:"env"`
    Instance string `json:"instance"`
    Profile  string `json:"profile" jsonschema:"profile 名称，取值 allocs|block|cmdline|goroutine|heap|mutex|profile|threadcreate|trace"`
    Seconds  *int   `json:"seconds,omitempty" jsonschema:"采集时长(秒)，1..3600，仅 profile(CPU) 与 trace 接受；注意：基于时间的采集需客户端配置足够长的超时"`
}
```

**执行流**：

1. **profile 校验**（需求 7.2）：不在 9 种集合内 → 「profile 名称不受支持」，不发请求。
2. **seconds 校验**：
   - 提供了 seconds 但非 1..3600 整数 → 时长校验错误（需求 7.3），不发请求。
   - 为 `profile`/`trace` 以外的 profile 提供 seconds → 「该 profile 不接受 seconds 参数」错误
     （需求 7.5），**不静默忽略**，不发请求。
3. `Resolver.Resolve` → `PprofHostIP`；端口推导（见下）。无法解析 IP → 「无法解析目标主机」
   （需求 7.9）。
4. 构建 URL（需求 7.10）：`http://<host_ip>:<port>/debug/pprof/<profile>`；仅 `profile`/`trace`
   且有 seconds 时追加 `?seconds=<seconds>`（需求 7.4/7.10）。
5. HTTP **GET**（需求 9.4，仅 GET），客户端超时设为 `seconds + 余量`（如 seconds+30s，无 seconds
   时用默认如 60s），保证采集在超时前完成（需求 7.15）。
6. 状态非 2xx / 连接失败 / 超时 → 含详情的错误（需求 7.17）。
7. **cmdline 特例**（需求 7.11/7.12/7.13）：profile 为 `cmdline` 时，对响应文本先脱敏再返回；
   脱敏失败 → 返回「脱敏失败」错误，绝不返回原文。
8. 成功 → 响应体（cmdline 已脱敏）以 **base64** blob 返回（需求 7.14、11.1）。

**端口推导**（需求 7.18/7.19/7.20/7.21）：

```
base = pprof_port_bases[service]   // 配置覆盖 > 内置 game/cross/gate
若无 base → 「未知 service-type: X」错误（7.20）
port = base + serverid             // 如 game421→27421, cross1008→29008, gate5→24005
若 port ∉ [1,65535] → 「端口超出范围」错误（7.21）
```

**cmdline 脱敏策略**（需求 7.12，复用 `secret` 包，与 DBURL 掩码同一原则）：

- **连接串内嵌凭据**：`user:password@host` → `user:****@host`（复用 `MaskDBURL` 正则）。
- **敏感 flag 取值**：`--pass`、`--password`、`--token`、`--secret`、`--key` 及短形式
  （`-p` 等需谨慎匹配），无论 `--flag=value` 还是 `--flag value` 形式，value 掩码为 `****`。
- **敏感 URL 查询参数**：`password=`、`token=`、`secret=`、`key=` 的值掩码为 `****`。
- 脱敏在字节层完成；若解析/脱敏过程出现异常无法保证完整覆盖 → 返回错误而非原文（需求 7.13）。

**工具描述补充**（需求 7.16）：描述中显式提示「profile/trace 为基于时间的采集，客户端须为该调用
配置足够长的超时」。

**Requirements 映射**：需求 7（全部）、9.4/9.5/9.9、10.4、11.1/11.2/11.4。

### list_instances

**MCP 输入 schema**：

```go
type ListInstancesInput struct {
    Project string `json:"project"`
    Env     string `json:"env"`
}
```

**执行流**：

1. 判定 (project, env) 后端：
   - etcd 模型：按 namespace 决定前缀（需求 8.2/8.3）：
     - `namespace=true` → 前缀 `{env}/{project}/gs/`
     - `namespace=false` → 前缀 `{project}/gs/`
     - `etcd Get(prefix, WithPrefix())`，从 key 末段还原 `{service}/{serverid}` → 实例名。
   - mongo 回退：`processes.find({project})`，由 `serverName`+`vars.id` 组合实例名（需求 8.4）。
2. 返回实例列表，每项至少含可直接用于其它工具的实例名 + 基本信息（需求 8.5）。
3. **绝不** 返回任何凭据或 DBURL 密码（需求 8.6）——`InstanceInfo` 结构中根本不含凭据字段。
4. 连接/列举失败 → 含原因错误（需求 8.7）。

**结果形状**：`[]InstanceInfo`（JSON 数组）。

**Requirements 映射**：需求 8（全部）、9.8、11.1。

## Cross-cutting Concerns

### Auth 中间件（需求 2）

```go
func Middleware(tokens []config.TokenEntry) func(http.Handler) http.Handler {
    allow := make(map[string]struct{}, len(tokens))
    for _, t := range tokens {
        allow[t.Token] = struct{}{} // 仅按 token 值建索引；name 不参与（需求 2.3）
    }
    return func(next http.Handler) http.Handler {
        return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
            tok := extractBearer(r.Header.Get("Authorization")) // "Bearer <token>"（需求 2.2）
            if _, ok := allow[tok]; tok == "" || !ok {
                writeAuthError(w) // 401，不进入工具分发（需求 2.5）
                return
            }
            next.ServeHTTP(w, r)
        })
    }
}
```

- 仅比对 `token` 值，`name` 不影响结果（需求 2.3/2.4）。
- 缺失或不匹配 → 拒绝且不执行任何工具、不访问内网（需求 2.5）。
- 白名单为空在启动校验阶段已拒绝启动（需求 2.6）。

### 错误模型（需求 11）

统一网关错误类型，集中映射为 MCP 工具错误并强制掩码：

```go
type Kind int
const (
    KindValidation Kind = iota // 输入校验失败（不触达内网）
    KindNotFound               // 实例不存在
    KindAmbiguous              // 实例不唯一
    KindConnection             // 连接/超时失败
    KindRejected               // 安全拒绝（方法/命令/HTTP方法）
    KindUpstream               // 后端执行失败
    KindRedaction              // 脱敏失败
)
type GatewayError struct {
    Kind Kind
    Msg  string // 已掩码的安全消息
    err  error  // 原始错误（仅内部日志，输出前掩码）
}
func (e *GatewayError) ToMCPToolError() *mcp.CallToolResult // IsError=true + 文本消息
```

- 所有进入工具结果或日志的文本，统一经 `secret.MaskDBURL` 与 cmdline 脱敏过滤，确保不含明文
  内部凭据（需求 9.9、11.4）。
- 校验类错误在解析/连接 **之前** 返回，保证「不访问内网资源」（需求 11.3）。
- 单次调用失败不影响服务持续可用（需求 1.6、11.5）——错误经 handler 捕获返回，不 panic/exit。

### 并发与超时

- **每次调用** 使用独立 `context.WithTimeout`：mongo/redis/etcd 解析阶段 10s（需求 4.16）；
  pprof 采集阶段 `seconds + 余量`（需求 7.15）。
- **连接复用 / 池化**：
  - autoops mongo 客户端：进程级单例（driver 自带连接池）。
  - 目标 mongo：按 `host:port` 缓存 `*mongo.Client`（LRU/map + 锁），避免每次新建。
  - etcd：按 `(project, env)` 缓存 `*clientv3.Client`。
  - redis：按 `addr`（+凭据指纹）缓存 `redis.UniversalClient`（自带池）。
- **pprof 长调用**：HTTP client 的 `Timeout` 必须大于 `seconds`，否则会在采集完成前断开；同步
  实现（需求 7.15），异步任务+轮询为未来项，不在本期（见 Decisions）。
- MCP 服务并发处理多请求互不阻塞；后端客户端线程安全且共享池。

### 安全姿态映射表（需求 9）

| 需求 | 安全约束 | 强制机制 |
|------|---------|---------|
| 9.1 | 所有 mongo 用只读账号 | Resolver/工具连接时固定注入 `mongo.readonly`，`ResolvedTarget` 不带凭据 |
| 9.2 | mongo 只读 | `mongoq` 方法白名单 + `assertNoServerSideJS` + `assertNoWriteStage` |
| 9.3 | redis 只读 | `redisq` 只读命令白名单（默认拒绝） |
| 9.4 | pprof 仅 GET | `pprofx` 固定 `http.MethodGet` + 仅 `/debug/pprof/` 路径 |
| 9.5 | 非 GET 拒绝 | pprof 不暴露任何非 GET 路径；任何需要非 GET 的动作直接拒绝 |
| 9.6 | etcd 仅只读且内部 | Resolver 仅用 `Get`/`WithPrefix`；不注册任何通用 etcd 工具 |
| 9.7 | 不用内嵌凭据连接 | 仅从 DBURL/vars.dburl 取 host:port+db，凭据丢弃 |
| 9.8 | 不暴露内部连接细节 | 工具结果只含业务数据/实例名；`InstanceInfo` 无凭据字段 |
| 9.9 | 不暴露明文凭据 | `secret.MaskDBURL` + cmdline 脱敏，输出前统一过滤 |

## Correctness Properties

*属性（property）是系统在所有合法执行下都应成立的特征或行为——本质上是对「系统应做什么」的形式化
陈述。属性是人类可读规约与机器可验证正确性保证之间的桥梁。*

本网关的核心安全与路由逻辑被设计为 **纯函数**（实例名解析、key 模板、端口推导、库名前缀、凭据
优先级、掩码/脱敏、白名单分类），这些是属性化测试（PBT）的理想对象。以下属性经去重后保留，每条
覆盖唯一的验证价值；传输层（需求 1）、工具元数据文案（需求 10）不适用 PBT，分别用集成测试与
smoke 测试覆盖（见 Testing Strategy）。

### Property 1: 实例名解析往返与拒绝

*For any* 由一段 ASCII 字母 `s` 与一段十进制数字 `d` 拼成的实例名 `s+d`，`ParseInstance` 都应
成功返回 service==`s`（大小写原样）与 serverid==`d`；*For any* 不匹配 `^[A-Za-z]+\d+$` 的字符串
（空串、无前导字母、无结尾数字、含其它字符），`ParseInstance` 都应返回校验错误且不产出任何目标。

**Validates: Requirements 4.1, 4.2**

### Property 2: etcd key 模板与实例名往返

*For any* (project, env, service, serverid) 与 namespace 标志，`buildEtcdKey` 生成的 key 在
namespace=true 时等于 `{env}/{project}/gs/{service}/{serverid}`、在 false 时等于
`{project}/gs/{service}/{serverid}`；且从对应前缀下的 key 末段还原出的实例名应等于
`service+serverid`。

**Validates: Requirements 4.5, 4.6, 8.2, 8.3**

### Property 3: DBURL 路由解析仅取 host:port 与库名

*For any* 由随机 user/pass/host/port/db 构造的合法 DBURL，路由解析得到的 `host:port` 与库名应
与构造值一致，且解析结果中不包含内嵌凭据。

**Validates: Requirements 4.8**

### Property 4: 库名前缀规则

*For any* env 与库名 db，当 `db_name_group=true` 时结果应为 `{env}_`+db、当为 false 时结果应原样
为 db。

**Validates: Requirements 4.9**

### Property 5: DBURL 密码掩码绝不泄露明文

*For any* 含 `user:password@host` 的 DBURL，`MaskDBURL` 的输出都不包含原始 password 明文子串，
同时保留 user、host、port、库名等非敏感部分。

**Validates: Requirements 4.15, 9.7, 9.9, 11.4**

### Property 6: 鉴权仅取决于 token 值且与 name 无关

*For any* Token 白名单（含随机 name）与任意待校验 token，鉴权通过当且仅当该 token 等于白名单中
某条目的 `token` 值；对任意条目的 `name` 做任意改动都不改变鉴权结果。

**Validates: Requirements 2.3, 2.4**

### Property 7: Redis 凭据优先级 service > env > global

*For any* 各层（service 覆盖 / 按 env / 全局）可选存在的 Redis 配置与任意 (env, service)，所选
凭据应严格等于实际存在的最高优先级层的凭据。

**Validates: Requirements 3.8, 3.9, 6.4**

### Property 8: mongo 只读方法白名单

*For any* 方法名，`ParseQuery` 在解析阶段接受当且仅当该方法名（小写规整后）属于只读方法白名单
（find/findOne/count/countDocuments/estimatedDocumentCount/aggregate/distinct）；其余方法一律
拒绝且不执行。

**Validates: Requirements 5.4, 5.6, 9.2**

### Property 9: server-side JS 操作符在任意嵌套层被拒绝

*For any* filter / pipeline 文档，若其任意嵌套层包含 `$where`、`$function` 或 `$accumulator`，
`AssertNoServerSideJS` 都应返回错误；若不含，则应通过。

**Validates: Requirements 5.7**

### Property 10: aggregate 写阶段被拒绝

*For any* aggregate pipeline，若其任一阶段包含 `$out` 或 `$merge`，`AssertNoWriteStage` 都应
返回错误；否则通过。

**Validates: Requirements 5.8**

### Property 11: Redis 命令分类大小写无关且默认拒绝

*For any* 命令名（任意大小写变体），其分类结果（allow / write / dangerous / unknown）与大小写
无关；且仅当命令名属于只读命令白名单时才归为 allow 并被执行，其余一律拒绝。

**Validates: Requirements 6.6, 6.7, 6.8, 6.9, 6.10, 9.3**

### Property 12: pprof 输入校验判定

*For any* (profile, seconds) 组合：当 profile 不在 9 个具名集合内时一律拒绝；当 seconds 非
1..3600 整数时拒绝；当为 `profile`/`trace` 以外的 profile 提供 seconds 时拒绝；仅当 profile 合法
且 (无 seconds 或 (profile∈{profile,trace} 且 seconds∈1..3600)) 时通过；任何拒绝都不发起请求。

**Validates: Requirements 7.2, 7.3, 7.4, 7.5, 9.5**

### Property 13: pprof 端口推导

*For any* 已知基准端口 base 的 service-type 与 serverid n，推导端口应等于 `base + n`；当
service-type 无对应基准时返回「未知 service-type」错误；当推导端口落在 1..65535 之外时返回
「端口超出范围」错误。

**Validates: Requirements 7.18, 7.19, 7.20, 7.21**

### Property 14: pprof 主机 IP 提取

*For any* 形如 `<ip>:<port>` 的 Addr，提取的主机 IP 应等于其 IP 部分；当 Addr 缺失或 IP 部分为空
时返回无法解析目标主机错误。

**Validates: Requirements 7.7, 7.9**

### Property 15: cmdline 脱敏绝不泄露密钥

*For any* cmdline 文本，在连接串凭据位（`user:pass@host`）、敏感 flag 值（`--pass`/`--password`/
`--token`/`--secret`/`--key` 及短形式）、敏感 URL 查询参数值（`password=`/`token=` 等）中注入
任意随机密钥后，脱敏输出都不包含任一原始密钥明文；若无法可靠完成脱敏则返回错误而非原文。

**Validates: Requirements 7.11, 7.12, 7.13, 9.9, 11.4**

### Property 16: base64 采集结果往返

*For any* 字节序列（代表已脱敏的响应体），base64 编码再解码应还原为原始字节。

**Validates: Requirements 7.14**

### Property 17: 对外输出绝不含凭据

*For any* 含内嵌凭据（DBURL/vars.dburl）的后端记录集合，`list_instances` 与 Resolver 面向调用方
的输出都不包含任何凭据明文，且 `InstanceInfo` 结构不含凭据字段。

**Validates: Requirements 8.6, 9.8**

### Property 18: mongo shell 输入归一化往返

*For any* 合法的 mongo shell 风格文档（含无引号 key、ObjectId()/ISODate()/NumberLong() 包装），
`NormalizeMongoJSON` 的输出都应能被 Extended JSON 解析器成功解析为语义等价的文档。

**Validates: Requirements 5.4**

## Error Handling

错误处理统一收口到 `internal/gwerr` 的 `GatewayError`（见 Cross-cutting），核心约束：

- **分层返回，不退出**：从 `mgq` 重构而来的所有函数把 `die()/os.Exit()` 改为返回 error；工具
  handler 捕获并转为 MCP 工具错误（`IsError=true` + 文本），进程不退出（需求 1.6、11.5）。
- **校验先行**：实例名/方法/命令/profile/seconds 等输入校验在解析与连接之前完成，失败即返回，
  绝不访问内网资源（需求 11.3）。
- **统一掩码**：任何流向工具结果或日志的文本，先经 `secret.MaskDBURL` 与 cmdline 脱敏过滤；
  脱敏失败（`KindRedaction`）时返回错误而非可能含密钥的原文（需求 7.13、9.9、11.4）。
- **错误分类与消息**：见各工具「错误映射」表；连接/超时统一 `KindConnection`（需求 4.16、6.11、
  7.17、8.7）。
- **结果可预测**（需求 11.1）：`mongo_query`/`list_instances`→JSON；`redis_query`→命令结果；
  `pprof_collect`→base64 blob。

## Testing Strategy

采用 **双层测试**：属性测试覆盖普遍正确性，单元/集成/smoke 测试覆盖具体场景与框架行为。

### 属性测试（Property-based）

- **库**：采用成熟 PBT 库，推荐 `pgregory.net/rapid`（Go 原生、shrink 能力好）；不自行实现 PBT。
- **配置**：每个属性测试至少运行 **100** 次迭代（随机化）。
- **标注**：每个属性测试以注释标注其对应设计属性，格式：
  `// Feature: pprof-redis-proxy, Property {number}: {property_text}`。
- **覆盖**：Property 1–18 各由 **单个** 属性测试实现。重点高价值项：
  - 实例名解析往返（P1）、etcd key↔实例名往返（P2）、归一化往返（P18）——解析/序列化必测往返。
  - 端口推导（P13）、库名前缀（P4）、凭据优先级（P7）——纯路由逻辑。
  - **安全不变量**：DBURL 掩码（P5）、cmdline 脱敏绝不泄露（P15）、对外输出无凭据（P17）、
    方法白名单（P8）、JS/写阶段拒绝（P9/P10）、redis 分类（P11）——这些是「绝不泄露 / 默认拒绝」
    家族，价值最高。

### 单元测试（Example / Edge）

- 配置默认值填充（namespace=true、db_name_group=false）（需求 3.3/3.4）。
- 启动校验：空 token、缺必填项、malformed pprof base、YAML 解析失败 → 拒绝启动（需求 2.6、3.12）。
- `vars.redis` 缺失/空白 → 报错（需求 6.5，edge）。
- mongo `show tables`、findOne 命中/未命中（null）等具体行为。

### 集成测试（Integration，1–3 例）

- MCP 传输：`tools/list` 返回 4 个工具；POST 一条 `tools/call` 得到响应；非法消息得到协议错误且
  服务仍可用（需求 1.2–1.6）。
- 端到端：对一个测试 mongo/redis/pprof（或 mock）走通解析→执行→返回链路。
- etcd 解析：对一个测试 etcd 写入已知 key/value，验证解析与 list 前缀列举。

### Smoke 测试

- 工具元数据自描述（需求 10）：断言每个工具 schema 含 project/env/instance 描述、profile 取值
  列举、seconds 范围、只读性质说明等关键字。

## Decisions & Open Items

### 设计决策

1. **MCP 库选型（可调整）**：推荐官方 `github.com/modelcontextprotocol/go-sdk`（Streamable HTTP
   handler 可被标准中间件包裹，schema 由结构体生成）；备选 `github.com/mark3labs/mcp-go`。二者
   均以 `http.Handler` 形态接入，下游架构不受影响。最终以实现期实测可用性为准。
2. **Redis 客户端**：`github.com/redis/go-redis/v9`（`Do()` 通用命令 + 连接池）。
3. **PBT 库**：`pgregory.net/rapid`。
4. **mgq 复用与必做重构**：`parseQuery/parseCursorChain/assertNoServerSideJS/assertNoWriteStage/
   normalizeMongoJSON/runQuery/parseHostPort/buildDBName/parseArg` 等逐字复用安全逻辑，但 **必须**
   把 `die()/os.Exit()` 改为返回 error，并把 `runQuery` 的直接打印改为返回结果，供服务层序列化。

### 待确认（To-confirm）

1. **pprof 主机 IP 来源（待确认）**：
   - etcd 模型：取 etcd value `Addr` 字段的 IP 部分（`192.168.5.29:22032` → `192.168.5.29`）。
   - mongo 回退模型：`processes.host_id` → `hosts.lanip`。
   - 该决策后续可能调整（例如改用其它字段或加可配置覆盖），实现时以 `Resolver` 内单点函数封装，
     便于变更。
2. **MCP 库最终选型**：见设计决策 1，待实现期确认。

## Requirements Coverage Map

| 需求 | 覆盖位置 |
|------|---------|
| 需求 1（MCP/Streamable HTTP/发现） | Architecture、Streamable HTTP 接入；集成测试 |
| 需求 2（鉴权/白名单） | Auth 中间件；Property 6；启动校验 |
| 需求 3（配置模型） | Data Models（YAML + 结构体 + 校验）；Property 7 |
| 需求 4（服务解析双后端） | Service Resolver Design；Property 1–5 |
| 需求 5（mongo_query） | Tool Designs / mongo_query；Property 8/9/10/18 |
| 需求 6（redis_query） | Tool Designs / redis_query；Property 7/11 |
| 需求 7（pprof_collect） | Tool Designs / pprof_collect；Property 12/13/14/15/16 |
| 需求 8（list_instances） | Tool Designs / list_instances；Property 2/17 |
| 需求 9（只读安全姿态） | 安全姿态映射表；Property 5/8/11/15/17 |
| 需求 10（工具自描述） | 各工具 schema；meta.go；Smoke 测试 |
| 需求 11（错误模型） | Error Handling；GatewayError；Property 5/15/17 |
