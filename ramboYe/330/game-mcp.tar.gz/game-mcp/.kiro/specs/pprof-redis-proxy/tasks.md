# Implementation Plan: pprof-redis-proxy（统一游戏运维查询网关 MCP Gateway）

## Overview

本计划将现有的只读 MongoDB CLI 代理（`main.go` 中的 `mgq`）增量重构为单一的 MCP Gateway 服务。
实现语言为 **Go**（设计文档已采用具体语言，无需另行选择）。

总体策略：先搭脚手架与底层不变量库（`gwerr`、`secret`），再把 `mgq` 的安全模型重构为可复用的
`internal/mongoq`（核心重构点：`die()/os.Exit()` → 返回 error；`runQuery` 不再 `fmt.Println`
而是返回结果），随后实现 `config`、`resolver` 等纯逻辑路由层，再叠加 `pprofx`、`redisq`、`auth`
后端适配器，最后用 `mcptools` 暴露 4 个工具并由 `cmd/gateway` 装配为 Streamable HTTP 服务。

属性测试采用 `pgregory.net/rapid`，每个属性 ≥100 次迭代，并以注释
`// Feature: pprof-redis-proxy, Property N: ...` 标注。设计的 Correctness Properties 1–18
分别映射到对应实现任务的属性测试子任务。

> 说明：相对建议序列，`internal/gwerr` 被提前到脚手架之后实现，因为 `resolver`/`mongoq` 等多个
> 包都依赖 `gwerr` 的校验错误构造器；这样可获得更干净的依赖关系。

## Tasks

- [x] 1. 项目脚手架与依赖
  - [x] 1.1 初始化 Go module、目录骨架与第三方依赖
    - 在仓库根创建 `go.mod`（module 名沿用现有仓库路径，Go 版本就高不就低）
    - 创建设计的包目录骨架：`cmd/gateway`、`internal/{config,auth,resolver,mongoq,redisq,pprofx,secret,mcptools,gwerr}`，每个包先放一个 `doc.go` 占位以保证可编译
    - 添加依赖：`go.mongodb.org/mongo-driver`、`github.com/redis/go-redis/v9`、`go.etcd.io/etcd/client/v3`、`gopkg.in/yaml.v3`、MCP SDK（`github.com/modelcontextprotocol/go-sdk`，如实现期不可用则改用备选 `github.com/mark3labs/mcp-go`）、测试用 `pgregory.net/rapid`
    - 保留现有 `main.go` 暂不删除，待 `cmd/gateway` 装配完成后再行处理（避免编译中断）
    - _Requirements: 1.1_

  - [x] 1.2 定义 internal/config 配置结构体（仅类型）
    - 在 `internal/config/config.go` 定义 `Config`、`ServerConfig`、`TokenEntry`、`MongoConfig`、`Credential`、`AutoopsConfig`、`EtcdCluster`、`RedisConfig`、`RedisEnv`、`RedisService`，字段 `yaml` 标签按设计 YAML 模型
    - `EtcdCluster.Namespace` / `EtcdCluster.DBNameGroup` 使用 `*bool` 以区分「未设置」与显式 false
    - _Requirements: 3.1, 3.2, 3.5, 3.6, 3.7, 3.10, 3.11_

- [x] 2. internal/gwerr 错误模型
  - [x] 2.1 实现 GatewayError 与分类构造器
    - 在 `internal/gwerr/gwerr.go` 定义 `Kind`（`KindValidation/KindNotFound/KindAmbiguous/KindConnection/KindRejected/KindUpstream/KindRedaction`）与 `GatewayError{Kind, Msg, err}`
    - 提供构造器 `Validation/NotFound/Ambiguous/Connection/Rejected/Upstream/Redaction(format, args...)`
    - 实现 `ToMCPToolError()`：转为 MCP 工具错误结果（`IsError=true` + 文本消息）；实现 `Error()` 与 `Unwrap()`
    - _Requirements: 11.2, 11.3, 11.5_

  - [x] 2.2 编写 gwerr 单元测试
    - 验证各 Kind 构造器、`ToMCPToolError()` 输出 `IsError=true` 且携带消息
    - _Requirements: 11.2_

- [x] 3. internal/secret 凭据掩码与脱敏原语
  - [x] 3.1 实现 MaskDBURL
    - 在 `internal/secret/mask.go` 实现 `MaskDBURL(dburl string) string`：将 `user:pass@host` → `user:****@host`，保留 user、host、port、库名
    - _Requirements: 4.15, 9.7, 9.9, 11.4_

  - [x] 3.2 编写 MaskDBURL 属性测试
    - **Property 5: DBURL 密码掩码绝不泄露明文**
    - **Validates: Requirements 4.15, 9.7, 9.9, 11.4**
    - 注释标注 `// Feature: pprof-redis-proxy, Property 5: DBURL 密码掩码绝不泄露明文`
    - 随机生成 user/pass/host/port/db 构造 DBURL，断言输出不含原始 password 子串、保留非敏感部分；≥100 次迭代（rapid）

  - [x] 3.3 实现 cmdline 脱敏原语
    - 在 `internal/secret/redact.go` 实现可复用的字节级脱敏原语：连接串内嵌凭据（`user:pass@host`，复用 `MaskDBURL` 正则）、敏感 flag 取值（`--pass`/`--password`/`--token`/`--secret`/`--key` 及短形式，支持 `--flag=value` 与 `--flag value`）、敏感 URL 查询参数值（`password=`/`token=`/`secret=`/`key=`）
    - 脱敏失败/无法可靠覆盖时返回 error（供上层决定不返回原文）
    - _Requirements: 7.12, 9.9, 11.4_

  - [x] 3.4 编写 cmdline 脱敏原语单元测试
    - 覆盖三类密钥（连接串/flag/URL 参数）的典型与边界输入
    - _Requirements: 7.12_

- [x] 4. internal/mongoq 重构（die→error，runQuery→返回结果）
  - [x] 4.1 迁移查询解析逻辑到 parse.go
    - 从 `main.go` 迁移 `parseQuery`、`parseCursorChain`、`normalizeMongoJSON`、`preprocessShell`、`quoteBareKeys`、`extractParen`、`splitTopLevel`、`parseDoc`、`safeGet` 等，逐字复用安全逻辑
    - **核心重构**：去除所有 `die()`，改为返回 `error`（校验类错误用 `gwerr.Validation/Rejected`）
    - 导出 `ParseQuery`、`ParseCursorChain`、`NormalizeMongoJSON`
    - _Requirements: 5.4, 5.5, 5.6_

  - [x] 4.2 编写 mongo 方法白名单属性测试
    - **Property 8: mongo 只读方法白名单**
    - **Validates: Requirements 5.4, 5.6, 9.2**
    - 注释 `// Feature: pprof-redis-proxy, Property 8: mongo 只读方法白名单`
    - 随机方法名：当且仅当（小写规整后）属于白名单时 `ParseQuery` 接受，其余拒绝；≥100 次迭代

  - [x] 4.3 编写 mongo shell 输入归一化往返属性测试
    - **Property 18: mongo shell 输入归一化往返**
    - **Validates: Requirements 5.4**
    - 注释 `// Feature: pprof-redis-proxy, Property 18: mongo shell 输入归一化往返`
    - 随机生成含无引号 key、`ObjectId()/ISODate()/NumberLong()` 包装的合法文档，断言 `NormalizeMongoJSON` 输出可被 Extended JSON 解析为语义等价文档；≥100 次迭代

  - [x] 4.4 迁移安全守卫逻辑到 guard.go
    - 迁移 `assertNoServerSideJS`、`assertNoWriteStage`、`serverSideJSOps`，**由 `die` 改为返回 error 并逐层向上传播**
    - 导出 `AssertNoServerSideJS(v any) error`、`AssertNoWriteStage(pipeline []bson.M) error`
    - _Requirements: 5.7, 5.8_

  - [x] 4.5 编写 server-side JS 拒绝属性测试
    - **Property 9: server-side JS 操作符在任意嵌套层被拒绝**
    - **Validates: Requirements 5.7**
    - 注释 `// Feature: pprof-redis-proxy, Property 9: server-side JS 操作符在任意嵌套层被拒绝`
    - 随机构造嵌套文档，在随机层注入/不注入 `$where`/`$function`/`$accumulator`，断言含则报错、不含则通过；≥100 次迭代

  - [x] 4.6 编写 aggregate 写阶段拒绝属性测试
    - **Property 10: aggregate 写阶段被拒绝**
    - **Validates: Requirements 5.8**
    - 注释 `// Feature: pprof-redis-proxy, Property 10: aggregate 写阶段被拒绝`
    - 随机 pipeline，含 `$out`/`$merge` 任一阶段则报错、否则通过；≥100 次迭代

  - [x] 4.7 实现 RunQuery（返回结果，不打印）
    - 在 `internal/mongoq/run.go` 实现 `RunQuery(ctx, cli *mongo.Client, dbName, query string, maxLimit int64) (any, error)`
    - **核心重构**：`printResults` 改为返回 `[]bson.M`；所有分支（find/findOne/count/aggregate/distinct/`show tables`）的 `fmt.Println`/`die` 改为收集结果并 `return (any, error)`
    - 保留 `maxLimit` 上限收敛逻辑（作为参数传入，不再用包级全局）
    - _Requirements: 5.4, 5.5, 5.9, 5.10, 9.2_

  - [x] 4.8 编写 RunQuery 单元测试
    - 覆盖 `show tables`/`show collections`、findOne 命中与未命中（返回 null）、count/distinct、limit 收敛等行为（可用 mock/集成 mongo）
    - _Requirements: 5.9, 5.10_

- [x] 5. 检查点 — 基础库（gwerr/secret/mongoq）测试通过
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. internal/config 加载与启动校验
  - [x] 6.1 实现配置加载 loader.go
    - 在 `internal/config/loader.go` 实现 `Load(path string) (*Config, error)`：读取 YAML（`gopkg.in/yaml.v3`）；文件缺失/YAML 语法错误 → 返回错误
    - _Requirements: 3.1, 3.12_

  - [x] 6.2 实现启动校验与默认值 validate.go
    - 在 `internal/config/validate.go` 实现 `Validate()`：Token 白名单为空/缺失、缺必填项（`mongo.readonly` user/pass、`tokens`、`server.listen`）、pprof 端口基准非法（非 1..65535 或键非合法 service-type）→ 返回错误（受控拒绝启动，写 stderr，非 panic）
    - 填充默认值：`namespace` 缺省 `true`、`db_name_group` 缺省 `false`；注入内置 pprof 端口基准 `game=27000/cross=28000/gate=24000`（未被覆盖时）
    - _Requirements: 2.6, 3.3, 3.4, 3.10, 3.12_

  - [x] 6.3 实现 Redis 凭据/地址优先级解析 redis_creds.go
    - 在 `internal/config/redis_creds.go` 实现按 (env, service) 解析 Redis 凭据与地址：优先级 service 覆盖 > 按 env > 全局 `redis.global`；地址优先级 service 覆盖 > 按 env `addr`
    - _Requirements: 3.8, 3.9_

  - [x] 6.4 编写 Redis 凭据优先级属性测试
    - **Property 7: Redis 凭据优先级 service > env > global**
    - **Validates: Requirements 3.8, 3.9, 6.4**
    - 注释 `// Feature: pprof-redis-proxy, Property 7: Redis 凭据优先级 service > env > global`
    - 随机让各层可选存在，断言所选凭据严格等于实际存在的最高优先级层；≥100 次迭代

  - [x] 6.5 编写配置默认值与启动校验单元测试
    - 覆盖：默认值填充（namespace=true/db_name_group=false）、空 token 拒绝、缺必填项拒绝、malformed pprof base 拒绝、YAML 解析失败拒绝
    - _Requirements: 2.6, 3.3, 3.4, 3.12_

- [x] 7. internal/resolver 服务解析（etcd 优先双后端）
  - [x] 7.1 实现实例名解析 instance.go
    - 实现 `ParseInstance(name) (service, serverID string, num int, err error)`：复用 `^([a-zA-Z]+)(\d+)$`，保留 service 大小写，非法格式返回 `gwerr.Validation`
    - _Requirements: 4.1, 4.2_

  - [x] 7.2 编写实例名解析往返与拒绝属性测试
    - **Property 1: 实例名解析往返与拒绝**
    - **Validates: Requirements 4.1, 4.2**
    - 注释 `// Feature: pprof-redis-proxy, Property 1: 实例名解析往返与拒绝`
    - 合法 `s+d` 往返成功（service==s 原样大小写、serverid==d）；不匹配字符串一律拒绝且不产出目标；≥100 次迭代

  - [x] 7.3 实现 etcd key 模板与实例名还原 etcdkey.go
    - 实现 `BuildEtcdKey(project, env, service, serverid, namespace)`：namespace=true → `{env}/{project}/gs/{service}/{serverid}`，false → `{project}/gs/{service}/{serverid}`
    - 实现从前缀下 key 末段还原 `{service}/{serverid}` → 实例名
    - _Requirements: 4.5, 4.6, 8.2, 8.3_

  - [x] 7.4 编写 etcd key 模板往返属性测试
    - **Property 2: etcd key 模板与实例名往返**
    - **Validates: Requirements 4.5, 4.6, 8.2, 8.3**
    - 注释 `// Feature: pprof-redis-proxy, Property 2: etcd key 模板与实例名往返`
    - 随机 (project, env, service, serverid, namespace)，断言 key 形如模板且从 key 还原的实例名等于 `service+serverid`；≥100 次迭代

  - [x] 7.5 实现 DBURL 路由解析 dburl.go
    - 复用 `main.go` 的 `parseHostPort` 思路实现从 `DBURL` 取 `host:port` 与库名（保留旧/新两种格式分支），改为返回 error；**内嵌凭据丢弃，不进入返回值**
    - _Requirements: 4.8_

  - [x] 7.6 编写 DBURL 路由解析属性测试
    - **Property 3: DBURL 路由解析仅取 host:port 与库名**
    - **Validates: Requirements 4.8**
    - 注释 `// Feature: pprof-redis-proxy, Property 3: DBURL 路由解析仅取 host:port 与库名`
    - 随机 user/pass/host/port/db 构造合法 DBURL，断言解析得到的 host:port 与库名一致且结果不含内嵌凭据；≥100 次迭代

  - [x] 7.7 实现库名前缀与 buildDBName dbname.go
    - 复用 `main.go` 的 `buildDBName`（gdconfig / global·webserver·door / 默认三类规则）
    - 实现 `ApplyDBNameGroup(env, db, dbNameGroup bool)`：true → `{env}_`+db，false → 原样
    - _Requirements: 4.9, 4.11_

  - [x] 7.8 编写库名前缀属性测试
    - **Property 4: 库名前缀规则**
    - **Validates: Requirements 4.9**
    - 注释 `// Feature: pprof-redis-proxy, Property 4: 库名前缀规则`
    - 随机 env 与 db，断言 db_name_group=true 时为 `{env}_`+db、false 时原样；≥100 次迭代

  - [x] 7.9 实现 pprof 主机 IP 提取 hostip.go
    - 实现 `ExtractHostIP(addr string) (string, error)`：从 `<ip>:<port>` 取 IP 部分；Addr 缺失或 IP 为空 → 返回无法解析目标主机错误（单点封装，便于「待确认」决策变更）
    - _Requirements: 7.7, 7.9_

  - [x] 7.10 编写 pprof 主机 IP 提取属性测试
    - **Property 14: pprof 主机 IP 提取**
    - **Validates: Requirements 7.7, 7.9**
    - 注释 `// Feature: pprof-redis-proxy, Property 14: pprof 主机 IP 提取`
    - 随机 `<ip>:<port>` 断言提取等于 IP 部分；缺失/空 IP 返回错误；≥100 次迭代

  - [x] 7.11 实现 Resolver 与 ListInstances（etcd 优先双后端 + 凭据注入）resolver.go
    - 实现 `Resolve(ctx, project, env, instance) (*ResolvedTarget, error)`：判定 `config.etcd[project][env]` 存在 → 仅 etcd（`Get` + JSON 解析 `EtcdValue` + DBURL 路由 + db_name_group 前缀 + Addr→pprofIP）；否则 mongo 回退（`processes.find` 过滤、唯一性 0条/>1条判定、`parseHostPort`+`buildDBName`、`host_id`→`hosts.lanip`、`vars.redis`）
    - 实现 `ListInstances(ctx, project, env) ([]InstanceInfo, error)`（etcd 前缀列举 / `processes` 列举）
    - **统一强制**：连接 mongo 始终注入 `mongo.readonly`（autoops 可选 `mongo.autoops.account`），`ResolvedTarget`/`InstanceInfo` 不含任何凭据字段；任何 DBURL 呈现先经 `secret.MaskDBURL`；解析/连接超时 10s
    - 定义 `ResolvedTarget`、`InstanceInfo`、`EtcdValue`、`Backend` 类型；实现 etcd/mongo 客户端池化
    - _Requirements: 4.3, 4.4, 4.7, 4.10, 4.11, 4.12, 4.13, 4.14, 4.15, 4.16, 6.3, 6.5, 9.1, 9.6, 9.7_

  - [x] 7.12 编写 Resolver 单元/集成测试
    - etcd 优先（已配置则不回退）、mongo 回退路径、实例不存在/不唯一错误、凭据不出现在输出中（可用测试 etcd 与 mongo 或接口 mock）
    - _Requirements: 4.4, 4.10, 4.12, 4.13_

- [x] 8. 检查点 — 配置与解析层测试通过
  - Ensure all tests pass, ask the user if questions arise.

- [x] 9. internal/pprofx（采集与脱敏）
  - [x] 9.1 实现 pprof 输入校验 validate.go
    - 实现 profile 名校验（9 种具名集合）与 seconds 校验（1..3600 整数；仅 `profile`/`trace` 接受 seconds，其余提供 seconds 即拒绝且不静默忽略）；任何拒绝不发起请求
    - _Requirements: 7.2, 7.3, 7.4, 7.5, 9.5_

  - [x] 9.2 编写 pprof 输入校验属性测试
    - **Property 12: pprof 输入校验判定**
    - **Validates: Requirements 7.2, 7.3, 7.4, 7.5, 9.5**
    - 注释 `// Feature: pprof-redis-proxy, Property 12: pprof 输入校验判定`
    - 随机 (profile, seconds) 组合，断言判定准则一致且任何拒绝不发起请求；≥100 次迭代

  - [x] 9.3 实现端口推导 port.go
    - 实现 `DerivePort(bases map[string]int, service string, serverid int) (int, error)`：`base + serverid`；无对应基准 → 「未知 service-type」；端口 ∉ [1,65535] → 「端口超出范围」
    - _Requirements: 7.18, 7.19, 7.20, 7.21_

  - [x] 9.4 编写端口推导属性测试
    - **Property 13: pprof 端口推导**
    - **Validates: Requirements 7.18, 7.19, 7.20, 7.21**
    - 注释 `// Feature: pprof-redis-proxy, Property 13: pprof 端口推导`
    - 随机 service-type/serverid，断言已知基准 → base+n、未知 → 报错、越界 → 报错；≥100 次迭代

  - [x] 9.5 实现 Collect（URL 构建 + GET + 超时）pprofx.go
    - 实现 `Collect(ctx, hostIP, port, profile, seconds *int) ([]byte, error)`：构建 `http://<ip>:<port>/debug/pprof/<profile>`，仅 `profile`/`trace` 且有 seconds 时追加 `?seconds=`；**仅 HTTP GET**；HTTP client 超时设为 `seconds + 余量`（无 seconds 用默认如 60s）；非 2xx/连接失败/超时 → 含详情错误
    - _Requirements: 7.10, 7.15, 7.17, 9.4, 9.5_

  - [x] 9.6 实现 cmdline 脱敏与 base64 编码 redact.go
    - 实现 `RedactCmdline(raw []byte) ([]byte, error)`：复用 `secret` 脱敏原语；脱敏失败返回 error（绝不返回原文）
    - 实现成功响应体 base64 编码封装（cmdline 先脱敏再编码）
    - _Requirements: 7.11, 7.12, 7.13, 7.14_

  - [x] 9.7 编写 cmdline 脱敏属性测试
    - **Property 15: cmdline 脱敏绝不泄露密钥**
    - **Validates: Requirements 7.11, 7.12, 7.13, 9.9, 11.4**
    - 注释 `// Feature: pprof-redis-proxy, Property 15: cmdline 脱敏绝不泄露密钥`
    - 在连接串凭据位/敏感 flag 值/敏感 URL 参数值注入随机密钥，断言脱敏输出不含任一原始密钥明文；无法可靠脱敏则返回错误；≥100 次迭代

  - [x] 9.8 编写 base64 往返属性测试
    - **Property 16: base64 采集结果往返**
    - **Validates: Requirements 7.14**
    - 注释 `// Feature: pprof-redis-proxy, Property 16: base64 采集结果往返`
    - 随机字节序列编码再解码应还原原始字节；≥100 次迭代

  - [x] 9.9 编写 Collect 单元测试
    - 用 `httptest` 模拟 pprof 端点：2xx 成功、非 2xx、连接失败/超时；断言 URL 构建与 seconds 追加正确、仅 GET
    - _Requirements: 7.10, 7.17_

- [x] 10. internal/redisq（只读命令白名单）
  - [x] 10.1 实现命令分类与分词 classify.go
    - 复用 `splitTopLevel` 风格做尊重引号的命令分词，取首 token 为命令名
    - 实现分类（大小写无关）：先判危险命令集合（CONFIG/EVAL/FLUSHALL/FLUSHDB/SHUTDOWN/SCRIPT/DEBUG…）、再判写命令集合（SET/DEL/EXPIRE/`FLUSH*`/LPUSH/HSET…）、最后只读白名单兜底（GET/MGET/HGET/HGETALL/HMGET/HKEYS/HVALS/HLEN/LRANGE/LLEN/LINDEX/SMEMBERS/SISMEMBER/SCARD/ZRANGE/ZRANGEBYSCORE/ZSCORE/ZCARD/TYPE/TTL/PTTL/EXISTS/STRLEN/SCAN/HSCAN/SSCAN/ZSCAN/GETRANGE/DBSIZE/INFO）
    - 分类结果 → 对应 `gwerr` 错误消息（写命令「仅允许只读命令」/危险「命令被拒绝」/未知「不支持的命令」）
    - _Requirements: 6.6, 6.8, 6.9, 6.10, 9.3_

  - [x] 10.2 编写 Redis 命令分类属性测试
    - **Property 11: Redis 命令分类大小写无关且默认拒绝**
    - **Validates: Requirements 6.6, 6.7, 6.8, 6.9, 6.10, 9.3**
    - 注释 `// Feature: pprof-redis-proxy, Property 11: Redis 命令分类大小写无关且默认拒绝`
    - 随机命令名（任意大小写变体），断言分类与大小写无关，且仅白名单命令归为 allow，其余一律拒绝；≥100 次迭代

  - [x] 10.3 实现 ExecCommand（执行 + 凭据应用）redisq.go
    - 实现 `ExecCommand(ctx, cli redis.UniversalClient, command string) (any, error)`：分类命中 allow → `Do(ctx, args...)` 执行（SCAN/HSCAN 等允许 MATCH/COUNT 只读子参数）；非白名单按类别返回错误
    - 接入 `config` 的 Redis 凭据/地址优先级解析（service > env > global），按 `addr`+凭据指纹池化客户端；连接/执行失败 → 含原因错误
    - _Requirements: 6.4, 6.7, 6.11, 9.3_

  - [x] 10.4 编写 ExecCommand 单元测试
    - 用内存/mock Redis 覆盖 GET/HGETALL/TTL/EXISTS 等结果形状，以及写/危险/未知命令拒绝与连接失败
    - _Requirements: 6.7, 6.8, 6.9, 6.10, 6.11_

- [x] 11. internal/auth（Bearer 鉴权中间件）
  - [x] 11.1 实现 Bearer 提取与白名单中间件
    - 实现 `Middleware(tokens []config.TokenEntry) func(http.Handler) http.Handler`：按 `token` 值建索引（`name` 不参与）；从 `Authorization: Bearer <token>` 提取；缺失/不匹配 → 401 且不进入工具分发、不访问内网
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_

  - [x] 11.2 编写鉴权属性测试
    - **Property 6: 鉴权仅取决于 token 值且与 name 无关**
    - **Validates: Requirements 2.3, 2.4**
    - 注释 `// Feature: pprof-redis-proxy, Property 6: 鉴权仅取决于 token 值且与 name 无关`
    - 随机白名单（含随机 name）与待校验 token，断言通过当且仅当等于某条目 token 值，且改动任意 name 不改变结果；≥100 次迭代

  - [x] 11.3 编写中间件单元测试
    - 缺 token / 错误 token → 401 且不调用下游；正确 token → 透传
    - _Requirements: 2.5_

- [x] 12. 检查点 — 后端适配器（pprofx/redisq/auth）测试通过
  - Ensure all tests pass, ask the user if questions arise.

- [x] 13. internal/mcptools（4 个工具 schema + handler）
  - [x] 13.1 实现工具元数据与输入 schema meta.go
    - 定义 `MongoQueryInput`/`RedisQueryInput`/`PprofCollectInput`/`ListInstancesInput` 及其 `jsonschema` 描述：实例名格式 `<service><id>`、project/env（版本级别）含义、mongo 只读方法与游标链列举、pprof 9 种 profile 与 seconds 范围（1..3600，仅 profile/trace）、各工具只读性质说明、pprof 基于时间采集需客户端配置足够长超时
    - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5, 10.6, 7.16_

  - [x] 13.2 实现 mongo_query handler
    - `internal/mcptools/mongo_query.go`：校验 instance → `Resolver.Resolve` → 用 `mongo.readonly` 连接目标库 → `mongoq.RunQuery` → 结果 JSON 返回；错误经 `gwerr` 映射为 MCP 工具错误（含 DBURL 掩码）
    - _Requirements: 5.1, 5.2, 5.3, 5.9, 5.10, 9.1, 9.2, 11.1, 11.2_

  - [x] 13.3 实现 redis_query handler
    - `internal/mcptools/redis_query.go`：校验 instance → `Resolver.Resolve` 得 RedisAddr（回退模型缺失/空白报错）→ 按优先级解析凭据 → `redisq.ExecCommand` → 结果返回
    - _Requirements: 6.1, 6.2, 6.3, 6.5, 9.3, 11.1, 11.2_

  - [x] 13.4 实现 pprof_collect handler
    - `internal/mcptools/pprof_collect.go`：`pprofx` 输入校验 → `Resolver.Resolve` 得 PprofHostIP → `pprofx.DerivePort` → `pprofx.Collect`（cmdline 经 `RedactCmdline`）→ base64 返回；各类错误映射
    - _Requirements: 7.1, 7.6, 7.10, 7.11, 7.14, 7.17, 9.4, 9.5, 11.1, 11.2, 11.4_

  - [x] 13.5 实现 list_instances handler
    - `internal/mcptools/list_instances.go`：`Resolver.ListInstances` → 返回 `[]InstanceInfo`（仅实例名 + 基本信息，**绝不含凭据/DBURL 密码**）；连接/列举失败含原因错误
    - _Requirements: 8.1, 8.5, 8.6, 8.7, 9.8, 11.1_

  - [x] 13.6 编写对外输出无凭据属性测试
    - **Property 17: 对外输出绝不含凭据**
    - **Validates: Requirements 8.6, 9.8**
    - 注释 `// Feature: pprof-redis-proxy, Property 17: 对外输出绝不含凭据`
    - 随机构造含内嵌凭据（DBURL/vars.dburl）的后端记录集合，断言 `list_instances`/Resolver 面向调用方的输出不含任何凭据明文，且 `InstanceInfo` 无凭据字段；≥100 次迭代

  - [x] 13.7 编写工具元数据自描述 smoke 测试
    - 断言每个工具 schema 含 project/env/instance 描述、mongo 方法与游标链列举、pprof profile 取值与 seconds 范围、只读性质说明等关键字
    - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5, 10.6_

- [x] 14. cmd/gateway 装配与集成
  - [x] 14.1 实现 main.go 装配
    - `cmd/gateway/main.go`：加载并校验配置（失败写 stderr 并受控退出）→ 构建 `Resolver` 与 4 个工具 → 用 MCP SDK 生成 Streamable HTTP `http.Handler`，经 `auth.Middleware` 包裹挂到 `cfg.Server.Endpoint`，由 `http.Server` 在 `cfg.Server.Listen` 监听
    - 单次工具调用失败经 handler 捕获返回 MCP 工具错误，进程不退出；移除/收编旧 `main.go` 的 CLI 入口
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 2.6, 3.12, 11.5_

  - [-] 14.2 编写 tools/list 集成测试
    - 启动测试服务，`tools/list` 返回 `mongo_query`/`redis_query`/`pprof_collect`/`list_instances` 四个工具及名称/描述/schema
    - _Requirements: 1.5_

  - [-] 14.3 编写 tools/call 往返与协议错误集成测试
    - POST 一条 `tools/call` 得到响应（可对 mock 后端走通解析→执行→返回）；非法 MCP 消息返回协议错误且服务仍可用；缺/错 token 被中间件拒绝
    - _Requirements: 1.2, 1.3, 1.6, 2.5, 11.5_

- [x] 15. 最终检查点 — 全部测试通过
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- 标记 `*` 的子任务为可选测试任务（属性测试 / 单元 / 集成 / smoke），可为更快的 MVP 跳过；顶层任务不带 `*`。
- 每个任务引用其满足的需求编号；属性测试子任务显式引用设计的 Correctness Property（Property 1–18）。
- 属性测试统一用 `pgregory.net/rapid`，≥100 次迭代，并以 `// Feature: pprof-redis-proxy, Property N: ...` 注释标注。
- 关键重构贯穿 `internal/mongoq` 与 `internal/resolver`：`die()/os.Exit()` → 返回 error；`runQuery` → 返回结果而非打印。
- 检查点用于增量验证；属性测试覆盖普遍正确性，单元/集成/smoke 测试覆盖具体场景与框架行为。

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1"] },
    { "id": 1, "tasks": ["1.2", "2.1", "3.1", "3.3"] },
    { "id": 2, "tasks": ["2.2", "3.2", "3.4", "4.1", "4.4", "6.1", "6.2", "6.3", "7.1", "7.3", "7.5", "7.7", "7.9", "9.1", "9.3", "9.6", "10.1", "11.1"] },
    { "id": 3, "tasks": ["4.2", "4.3", "4.5", "4.6", "4.7", "6.4", "6.5", "7.2", "7.4", "7.6", "7.8", "7.10", "9.2", "9.4", "9.5", "9.7", "9.8", "10.2", "10.3", "11.2", "11.3"] },
    { "id": 4, "tasks": ["4.8", "7.11", "9.9", "10.4", "13.1"] },
    { "id": 5, "tasks": ["7.12", "13.2", "13.3", "13.4", "13.5"] },
    { "id": 6, "tasks": ["13.6", "13.7", "14.1"] },
    { "id": 7, "tasks": ["14.2", "14.3"] }
  ]
}
```
