# Requirements Document

## Introduction

本特性将现有的游戏运维查询能力（`main.go` 中的只读 MongoDB 查询代理 `mgq`）演进为一个
**统一的游戏运维查询网关（MCP Gateway）**。该网关是一个 **单一的 MCP 服务**，部署在 **内网
（LAN）之内**，因此能够直接访问各主机的内网地址与各类内部服务端口。它通过 MCP Streamable HTTP
协议向 **远程的 LLM 客户端** 暴露一组工具（MCP tool）；当客户端调用工具时，网关 **代表用户在
内网内执行或转发** 相应的只读操作，并将结果回传给客户端。

这种设计的核心目标是 **降低用户的连接成本**：用户只需持有一个有效令牌（Bearer Token）和一组
逻辑选择器（project、env，必要时加上 instance），无需了解、配置或接触任何内部网络拓扑（主机
IP、端口、数据库连接串、etcd 集群地址、Redis 地址、数据库凭据等）。网关根据逻辑选择器在内部
**自动选取 etcd 集群、自动路由** 到正确的主机与端口，对用户隐藏全部内部细节。

数据来源采用 **etcd 双后端模型，etcd 优先**：

- 内部的「服务配置解析」能力（用于路由工具调用，**不是** 面向用户的 MCP 工具）根据
  (project, env, instance) 进行解析。
- IF 配置文件中为该 (project, env) 配置了 etcd 集群 → **仅使用 etcd**（不回退 mongo）：从
  etcd 读取该实例对应的 value（包含 `Name`、`Addr`、`Label`、`Weight`、`DBURL` 字段），据此
  推导 mongo 路由目标与 pprof 主机 IP。
- ELSE（该 project+env 未配置 etcd 集群）→ 回退到既有的 mongo `autoops`（管理数据库
  `autoops_v2`）`processes` 集合解析逻辑（既有 mgq 行为）。

**关键凭据规则（最高优先级）**：数据库凭据 **始终** 取自网关配置文件中的只读账号；etcd 的
`DBURL` 中内嵌的凭据（如 `admin:<password>`）**绝不** 用于建立连接，也 **绝不** 返回或暴露给
调用方。网关仅使用 etcd 的 `DBURL` 来推导 `host:port` 与库名（routing）；任何在内部出现的
`DBURL` 都必须对其中的密码做掩码处理。

网关对外暴露以下 4 个 MCP 工具，每个工具均接受逻辑选择器 project 与 env（必要时加上 instance）；
project/env 在内部通过配置文件选取 etcd 集群，集群的具体 endpoints 与 flag 永不暴露给调用方：

1. **`mongo_query(project, env, instance, query)`** —— 对目标实例执行 **只读** MongoDB 查询。
   复用 `mgq` 既有的安全模型（只读方法白名单、允许的游标链、对 server-side JS 与写阶段的结构化
   拒绝）；路由目标由内部服务解析器决定，连接始终使用配置文件中的只读账号。
2. **`redis_query(project, env, instance, command)`** —— 对目标实例对应的 Redis 执行 **只读**
   命令，通过只读命令白名单保证安全；Redis 地址在 etcd 模型下来自配置文件，在 mongo 回退模型下
   来自 `processes.vars.redis`；Redis 凭据来自配置文件（全局默认 + 按 env 覆盖）。
3. **`pprof_collect(project, env, instance, profile, seconds?)`** —— 网关向内网内的 pprof 端点
   `http://<host_ip>:<pprof_port>/debug/pprof/<profile>?seconds=<seconds>` 转发一个 HTTP GET
   请求，并将采集到的 profile 字节以 base64 blob 形式回传给调用方。
4. **`list_instances(project, env)`** —— 发现类工具，列出可用实例，使 LLM 无需猜测实例名；etcd
   模型下按 etcd 前缀列举，mongo 回退模型下从 `processes` 集合列举。

整套链路 **端到端严格只读**：网关侧配置只读数据库账号，MongoDB 走只读方法白名单，Redis 走只读
命令白名单，pprof 仅对 `/debug/pprof/` 发起 HTTP GET，etcd 仅做只读 get/prefix 且仅供内部使用
（不暴露任何通用 etcd 工具）。通过任何工具都无法改变受管系统的运维状态，也无法获取内部凭据。

### 关键设计决策（已确认）

- **统一服务**：所有能力收敛到 **同一个 MCP 服务** 中，而非多个独立 CLI 可执行文件。
- **内网部署 + 自动路由**：网关运行在内网，用户只提供 Token 与逻辑选择器（project、env、
  instance），网关自动完成集群选取、路由与执行。
- **传输方式**：采用 **MCP Streamable HTTP**（非 stdio、非裸 WebSocket）。
- **数据来源双后端，etcd 优先**：为某 (project, env) 配置了 etcd 集群时 **仅用 etcd**（不回退
  mongo）；否则回退到既有 mongo `autoops`（`processes` 集合）解析。
- **配置文件驱动**：etcd 集群（按 project → env 组织）、只读 mongo 账号、Redis 地址与 Redis
  凭据（全局 + 按 env 覆盖）、Token 白名单、pprof 端口基准、MCP 监听地址等，均集中在配置文件中
  定义，且 **不对调用方暴露**。
- **凭据始终来自配置文件**：所有 mongo 连接（autoops 与目标库）均使用配置文件只读账号；etcd 的
  `DBURL` 仅用于 `host:port`/库名路由，其内嵌密码绝不使用、绝不暴露，且内部呈现时必须掩码。
- **始终代理执行**：网关 **始终** 执行/转发操作并返回结果；**不** 提供“仅返回地址/URL”的行为。
- **同步采集**：pprof 采集当前为 **同步** 实现；异步任务 + 轮询作为未来可选项，不在本期范围内。
- **pprof 主机 IP 来源（待确认）**：etcd 模型下取 etcd value 中 `Addr` 字段的 IP 部分（例如
  `192.168.5.29:22032` → `192.168.5.29`）；mongo 回退模型下经 `processes.host_id` →
  `hosts.lanip` 解析。该决策 **待确认（to-confirm）**，后续可能调整。

### 未来扩展（不在本期范围）

- 按 Token 的细粒度授权 / 授权范围限定（将某 Token 限定到特定 project、env 或实例）。**说明：**
  结构化 Token 格式本身（每个条目含用于备注 / 审计的 `name` 与作为 Bearer 凭据的 `token`）已在
  本期范围内并已实现（见需求 2）；此处仅延后 **基于 Token 的 project/env/实例级细粒度授权范围
  限定**，本期所有有效 Token 在鉴权通过后均拥有相同的工具访问能力。
- 完整审计日志（记录每次工具调用的主体、目标与时间）。
- pprof 异步采集任务与轮询接口。
- pprof 的可选 `debug` 查询参数（例如 `?debug=1`，用于返回人类可读的 goroutine/heap 文本）
  **暂不支持 / 本期不实现（out of scope）**；本期仅支持默认（二进制 / pprof 原生）输出格式。

## Glossary

- **MCP Gateway（网关）**：本特性交付的单一 MCP 服务，部署在内网内，向远程 LLM 客户端暴露 MCP
  工具，并代表用户在内网内执行或转发只读操作。
- **MCP tool（MCP 工具）**：网关通过 MCP 协议暴露的可调用能力。本特性包含 `mongo_query`、
  `redis_query`、`pprof_collect`、`list_instances` 四个工具。
- **Streamable HTTP（可流式 HTTP 传输）**：MCP 的一种传输方式。客户端到服务端的消息通过 HTTP
  POST 发送到单一 MCP 端点；服务端响应可以是单条 JSON，也可以是 SSE 事件流；客户端还可以通过
  HTTP GET 打开一条服务端到客户端的 SSE 流。
- **MCP Endpoint（MCP 端点）**：网关用于接收 MCP 请求的单一 HTTP 路径。
- **Token（令牌）**：客户端用于向网关证明自身身份的凭据，通过 HTTP `Authorization` 头以 Bearer
  形式提供，对应 Token Allowlist 条目中的 `token` 字段值。
- **Token Allowlist（令牌白名单）**：网关配置文件中定义的有效令牌条目列表；每个条目包含一个
  `name` 字段（仅用于备注 / 审计标签，例如 `alice@dev`，不参与鉴权）与一个 `token` 字段（实际
  的 Bearer 凭据值）。仅当请求携带的令牌匹配某条目的 `token` 值时，请求才被接受。
- **project（项目）**：逻辑选择器之一，标识一个游戏项目（例如 `h5`、`ice`）。与 env 一起用于在
  配置文件中选取 etcd 集群，并作为 mongo 回退模型下 `processes` 的 `project` 过滤条件。
- **env（环境 / 版本级别）**：逻辑选择器之一，标识一个版本级别（version level，例如 `h5dev2`、
  `h5gold`、`h5prod`）。与 project 一起选取 etcd 集群，并参与 etcd key 模板与库名前缀的推导。
- **Instance Name（实例名）**：标识单个进程的字符串，形式为 `<service><id>`，其中 `<service>`
  是一个或多个 ASCII 字母（service-type），`<id>` 是一个或多个十进制数字（serverid），例如
  `actv1`、`game421`、`cross1008`、`gate5`。
- **service-type（服务类型）**：实例名的字母前缀（例如 `actv`、`game`、`cross`、`gate`）。在
  etcd key 模板中作为 `{service}`，在 mongo 回退模型下对应 `processes.serverName`。
- **serverid（实例编号）**：实例名的数字后缀，按十进制整数解释（例如 `1`、`421`、`5`）。在 etcd
  key 模板中作为 `{serverid}`，在 mongo 回退模型下对应 `processes.vars.id`；pprof 端口推导中作为
  加到基准端口上的偏移量。
- **Config File（配置文件）**：网关启动时加载的配置文件，**不对调用方暴露**。包含 etcd 集群
  （按 project → env 组织）、只读 mongo 账号、Redis 地址与 Redis 凭据（全局 + 按 env 覆盖）、
  Token 白名单、pprof 端口基准、MCP 监听地址等。
- **etcd Cluster（etcd 集群）**：配置文件中按 project → env 组织的一项配置，形如
  `{ endpoints: [...], db_name_group: <bool>, namespace: <bool> }`，描述某 (project, env) 对应
  的 etcd 集群接入点与解析标志。
- **endpoints（接入点列表）**：etcd 集群配置中的 etcd 节点地址列表（例如
  `["192.168.50.11:2379"]`）。属于内部细节，永不暴露给调用方。
- **namespace flag（namespace 标志）**：etcd 集群配置项，默认 `true`，决定 etcd key 模板是否带
  环境/项目命名空间前缀。`true` → `{env}/{project}/gs/{service}/{serverid}`；`false` →
  `{project}/gs/{service}/{serverid}`（用于生产环境中的 `ice` 等历史项目）。
- **db_name_group flag（db_name_group 标志）**：etcd 集群配置项，默认 `false`，对应进程启动参数
  `--dbnameGroup 1`。为 `true` 时目标库名加上 `{env}_` 前缀；为 `false` 时不加前缀。
- **etcd Key Template（etcd key 模板）**：根据 namespace 标志拼出的 etcd 键：namespace=true 时为
  `{env}/{project}/gs/{service}/{serverid}`（例如 `h5dev2/h5/gs/actv/1`）；namespace=false 时为
  `{project}/gs/{service}/{serverid}`。
- **etcd Value（etcd 值）**：etcd key 对应的 JSON 对象，包含字段 `Name`、`Addr`、`Label`、
  `Weight`、`DBURL`，例如
  `{"Name":"game32","Addr":"192.168.5.29:22032","Label":"Dev","Weight":0,"DBURL":"admin:****@192.168.5.29:27017/test?authSource=admin"}`。
- **Addr**：etcd value 字段，形如 `<ip>:<port>`，承载实例的网络地址。pprof 主机 IP（etcd 模型）
  取其 IP 部分（待确认）。
- **DBURL**：etcd value 字段，形如 `<user>:<password>@<host>:<port>/<db>?...` 的连接串。网关 **仅**
  使用其 `host:port` 与库名做路由；其中内嵌的凭据 **绝不** 用于连接，也 **绝不** 暴露，内部呈现
  时密码必须掩码。
- **Service Resolver（服务解析器）**：内部能力（非 MCP 工具），根据 (project, env, instance) 解析
  出 mongo 路由目标、Redis 地址来源与 pprof 主机 IP。先解析实例名，再按 etcd 优先 / mongo 回退
  规则路由。
- **Management Database（管理数据库）**：mongo 回退模型使用的 MongoDB 数据库 `autoops_v2`，通过
  `DB_HOST`/`DB_PORT`/`DB_USER`/`DB_PASS`/`DB_NAME_AUTOOPS` 配置访问，包含 `processes` 与
  `hosts` 集合。
- **processes collection（processes 集合）**：管理数据库中的集合。相关字段：`_id`、`name`、
  `project`、`serverid`、`serverName`、`type`、`host_id`、`hostName`、`label`、`vars.id`、
  `vars.dburl`、`vars.csv`、`vars.redis`。
- **hosts collection（hosts 集合）**：管理数据库中的集合。相关字段：`_id`、`lanip`、`sship`、
  `wanip`、`name`、`label`、`project`。
- **lanip（内网 IP）**：`hosts` 文档的 `lanip` 字段；mongo 回退模型下网关访问某主机内部服务
  （如 pprof 端点）时使用的网络地址。
- **Read-only Account（只读账号）**：配置文件中定义的、对 mongo（autoops 与目标库）仅具有只读
  权限的数据库账号。**所有** mongo 连接均使用该账号，不向调用方暴露。
- **Target Database（目标数据库）**：由服务解析器解析出的、承载该实例业务数据的 MongoDB 数据库。
  etcd 模型下其 `host:port` 与库名由 etcd value 的 `DBURL` 推导（库名按 db_name_group 决定是否
  加 `{env}_` 前缀）；mongo 回退模型下库名由 `buildDBName` 规则推导，地址由 `vars.dburl` 解析。
- **Redis Global Credentials（Redis 全局凭据）**：配置文件中定义的 Redis 账号/密码默认值，适用于
  所有未被 env 级覆盖的环境。
- **Redis Per-Env Credentials（Redis 按 env 凭据）**：配置文件中按 env（版本级别，例如 `h5dev2`）
  定义的 Redis 账号/密码覆盖值，优先级高于 Redis 全局凭据。
- **Pprof Port（pprof 端口）**：由 service-type 的基准端口与 serverid 计算出的 TCP 端口
  （`port = base + serverid`）。
- **Port Base Mapping（端口基准映射）**：将 service-type 映射到基准端口的可配置表，内置默认
  `game=27000`、`cross=28000`、`gate=24000`，可在配置文件中覆盖。
- **Pprof Endpoint（pprof 端点）**：形如
  `http://<host_ip>:<Pprof Port>/debug/pprof/<Profile Name>` 的 HTTP URL。
- **Profile Name（profile 名称）**：pprof 的 profile 路径片段，取值为 Go 标准
  `net/http/pprof` 提供的 9 个具名 profile 之一：{allocs, block, cmdline, goroutine, heap,
  mutex, profile, threadcreate, trace}。其中 `profile`（CPU）与 `trace` 为基于时间的 profile，
  支持可选的 `seconds` 时长参数。
- **Read-only Method Whitelist（只读方法白名单）**：MongoDB 允许执行的只读方法集合
  （find/findOne/count/countDocuments/estimatedDocumentCount/aggregate/distinct）。
- **Read-only Command Whitelist（只读命令白名单）**：Redis 允许执行的只读命令集合。
- **MCP Tool Error（MCP 工具错误）**：工具执行失败时，以 MCP 协议规定的工具错误形式返回给客户端
  的结构化错误结果，包含清晰的错误消息。

## Requirements

### 需求 1：MCP 服务、Streamable HTTP 传输与工具自动发现

**用户故事：** 作为一个远程的 LLM 客户端，我想要通过 MCP Streamable HTTP 连接到一个单一的网关
服务并自动发现其工具，以便在不接触内网细节的前提下正确路由并调用运维查询工具。

#### 验收标准

1. THE MCP Gateway SHALL 作为单一服务进程运行，并在配置文件指定的监听地址与端口上暴露一个
   MCP Endpoint。
2. THE MCP Gateway SHALL 通过 MCP Streamable HTTP 传输与客户端通信，接受发送到 MCP Endpoint 的
   HTTP POST 消息。
3. WHEN 客户端通过 HTTP POST 向 MCP Endpoint 发送一条 MCP 请求消息，THE MCP Gateway SHALL 以单条
   JSON 响应或一条 SSE 事件流作为该请求的响应。
4. WHERE 客户端通过 HTTP GET 向 MCP Endpoint 发起请求，THE MCP Gateway SHALL 打开一条服务端到
   客户端的 SSE 流。
5. WHEN 客户端发起 MCP 工具发现（tools/list）请求，THE MCP Gateway SHALL 返回 `mongo_query`、
   `redis_query`、`pprof_collect` 与 `list_instances` 四个工具，并为每个工具提供名称、描述与
   输入参数 schema。
6. IF 客户端发送的请求不是合法的 MCP 消息，THEN THE MCP Gateway SHALL 返回一条协议错误响应，并
   保持服务持续可用以处理后续请求。

### 需求 2：基于令牌的鉴权与令牌白名单

**用户故事：** 作为一个平台负责人，我想要每次工具调用都必须出示有效令牌，以便只有获授权的客户端
才能通过网关访问内网资源。

#### 验收标准

1. THE MCP Gateway SHALL 从配置文件读取 Token Allowlist，该 Token Allowlist SHALL 为一个条目
   列表，每个条目包含一个 `name` 字段（仅用于备注 / 审计标签，例如 `alice@dev`）与一个 `token`
   字段（实际的 Bearer 凭据值）。
2. WHEN 网关收到一条 MCP 请求，THE MCP Gateway SHALL 从 HTTP `Authorization` 头中以 Bearer 形式
   提取所携带的令牌。
3. WHEN 校验请求，THE MCP Gateway SHALL 仅将请求携带的令牌与 Token Allowlist 中各条目的 `token`
   字段值比对，且 `name` 字段 SHALL NOT 影响鉴权结果。
4. WHEN 请求携带的令牌匹配 Token Allowlist 中某条目的 `token` 值，THE MCP Gateway SHALL 接受该
   请求并继续处理。
5. IF 请求未携带令牌，OR 携带的令牌不匹配 Token Allowlist 中任何条目的 `token` 值，THEN THE MCP
   Gateway SHALL 拒绝该请求，返回一条鉴权失败错误，并 SHALL NOT 执行任何工具或访问任何内网资源。
6. IF Token Allowlist 在启动时为空或未配置，THEN THE MCP Gateway SHALL 拒绝启动并将一条配置错误
   写入标准错误。

### 需求 3：配置文件模型

**用户故事：** 作为一个运维人员，我想要通过单一配置文件集中定义 etcd 集群、只读数据库账号、
Redis 地址与凭据、令牌白名单、pprof 端口基准与监听地址，以便集中管理内部拓扑并对调用方完全隐藏。

#### 验收标准

1. WHEN 网关启动，THE MCP Gateway SHALL 从配置文件加载配置，包含 etcd 集群、只读 mongo 账号、
   Redis 地址、Redis 凭据、Token Allowlist（每个条目含 `name` 与 `token` 两个字段）、pprof 端口
   基准与 MCP 监听地址。
2. THE Config File SHALL 按 project → env → `{ endpoints, db_name_group, namespace }` 的层级
   组织 etcd 集群，其中 `endpoints` 是 etcd 节点地址列表，`db_name_group` 与 `namespace` 为可选
   标志。
3. WHERE 某 etcd 集群未显式提供 `namespace` 标志，THE MCP Gateway SHALL 将其默认为 `true`。
4. WHERE 某 etcd 集群未显式提供 `db_name_group` 标志，THE MCP Gateway SHALL 将其默认为 `false`。
5. THE Config File SHALL 定义一个用于所有 mongo 连接（管理数据库与目标数据库）的只读账号。
6. THE Config File SHALL 定义 etcd 模型下使用的 Redis 地址，因为 etcd 不携带 Redis 信息。
7. THE Config File SHALL 定义 Redis 凭据，包含一个全局默认凭据与可选的按 env（版本级别）覆盖
   凭据。
8. WHERE 某 env 配置了 Redis 按 env 凭据，THE MCP Gateway SHALL 在连接该 env 的 Redis 时优先使用
   该按 env 凭据而非全局默认凭据。
9. WHERE 某 env 未配置 Redis 按 env 凭据，THE MCP Gateway SHALL 在连接该 env 的 Redis 时使用全局
   默认 Redis 凭据。
10. THE Config File SHALL 定义 pprof 端口基准映射，并允许覆盖内置默认值
    （`game=27000`、`cross=28000`、`gate=24000`）。
11. THE Config File SHALL 定义 MCP 服务的监听地址与端口。
12. IF 配置文件缺失、无法解析，OR 缺少必填项（只读 mongo 账号、Token Allowlist、MCP 监听地址），
    THEN THE MCP Gateway SHALL 拒绝启动并将一条配置错误写入标准错误。

### 需求 4：内部服务解析（etcd 优先双后端）

**用户故事：** 作为一个运维人员，我想要仅凭 project、env 与实例名就被自动路由到正确的主机与服务，
以便无需了解 etcd、mongo 或任何内部网络拓扑即可完成查询。

#### 验收标准

1. WHEN Service Resolver 收到一个实例名，THE Service Resolver SHALL 将该实例名拆分为 service-type
   （前导 ASCII 字母）与 serverid（结尾十进制数字），并保留 service-type 原有的字母大小写。
2. IF 实例名为空、没有前导字母、没有结尾数字，OR 包含 `[A-Za-z0-9]` 以外的字符，THEN THE Service
   Resolver SHALL 返回一条描述期望的 `<service><id>` 格式的 MCP 工具错误，并不解析任何路由目标。
3. WHEN 解析 (project, env, instance)，THE Service Resolver SHALL 检查配置文件中是否为该
   (project, env) 配置了 etcd 集群。
4. WHERE 为该 (project, env) 配置了 etcd 集群，THE Service Resolver SHALL **仅** 使用 etcd 解析
   （SHALL NOT 回退到 mongo `autoops`）。
5. WHILE 使用 etcd 解析且其 `namespace` 标志为 `true`，THE Service Resolver SHALL 按 etcd key
   模板 `{env}/{project}/gs/{service}/{serverid}` 读取 etcd value（例如 `h5dev2/h5/gs/actv/1`）。
6. WHILE 使用 etcd 解析且其 `namespace` 标志为 `false`，THE Service Resolver SHALL 按 etcd key
   模板 `{project}/gs/{service}/{serverid}` 读取 etcd value。
7. WHEN 读取到 etcd value，THE Service Resolver SHALL 将其解析为包含 `Name`、`Addr`、`Label`、
   `Weight`、`DBURL` 字段的 JSON 对象。
8. WHEN 从 etcd value 推导 mongo 路由目标，THE Service Resolver SHALL 仅从 `DBURL` 取得目标
   `host:port` 与库名，并 SHALL NOT 使用 `DBURL` 中内嵌的凭据。
9. WHERE 该 etcd 集群的 `db_name_group` 标志为 `true`，THE Service Resolver SHALL 在目标库名前
   加上 `{env}_` 前缀；WHERE 其为 `false`，THE Service Resolver SHALL 不添加任何前缀。
10. IF 在 etcd 中找不到对应该 key 的条目，THEN THE Service Resolver SHALL 返回一条包含实例名的
    “实例不存在”MCP 工具错误。
11. WHERE 未为该 (project, env) 配置 etcd 集群，THE Service Resolver SHALL 回退到管理数据库
    `processes` 集合解析：按 `project`、作为 `serverName` 的 service-type，以及作为 `vars.id` 的
    serverid 过滤，并经 `vars.dburl` 推导 `host:port`、经 `buildDBName` 规则推导库名。
12. IF mongo 回退模型下不存在匹配的 `processes` 文档，THEN THE Service Resolver SHALL 返回一条
    包含实例名的“实例不存在”MCP 工具错误。
13. IF mongo 回退模型下有超过一个 `processes` 文档匹配该过滤条件，THEN THE Service Resolver SHALL
    返回一条包含实例名与匹配数量的“实例不唯一”MCP 工具错误。
14. WHEN 连接 mongo 建立目标连接，THE Service Resolver SHALL 始终使用配置文件中的 Read-only
    Account，而非任何来自 etcd `DBURL` 或 `vars.dburl` 的凭据。
15. WHEN 在内部呈现或记录任何 `DBURL`，THE MCP Gateway SHALL 对其中的密码做掩码处理。
16. IF 在 10 秒内无法建立与 etcd 集群或管理数据库的连接，OR 连接以其他方式失败，THEN THE Service
    Resolver SHALL 返回一条连接错误 MCP 工具错误。

### 需求 5：mongo_query 工具（只读）

**用户故事：** 作为一个 LLM 驱动的运维人员，我想要对某实例执行只读 MongoDB 查询，以便获取结构化
的业务数据用于诊断。

#### 验收标准

1. THE `mongo_query` 工具 SHALL 接受 project、env、instance 与 query 四个参数。
2. WHEN 调用 `mongo_query`，THE MCP Gateway SHALL 通过 Service Resolver 解析 (project, env,
   instance)，得到目标数据库的 `host:port` 与库名。
3. WHEN 连接目标数据库，THE MCP Gateway SHALL 使用配置文件中的 Read-only Account 建立连接，并
   SHALL NOT 使用任何来自 etcd `DBURL` 或 `vars.dburl` 的凭据。
4. WHEN 解析查询，THE `mongo_query` 工具 SHALL 仅允许只读方法白名单中的方法
   （find、findOne、count、countDocuments、estimatedDocumentCount、aggregate、distinct）。
5. WHEN 查询包含游标链式修饰，THE `mongo_query` 工具 SHALL 仅允许 `.sort`、`.skip`、`.limit`
   三种只读修饰。
6. IF 查询使用了不在只读方法白名单中的方法，THEN THE `mongo_query` 工具 SHALL 在不执行该查询的
   情况下返回一条“不支持的方法”MCP 工具错误。
7. IF 查询包含 server-side JS 操作符（`$where`、`$function`、`$accumulator`），THEN THE
   `mongo_query` 工具 SHALL 在不执行该查询的情况下返回一条“禁止使用 server-side JS 操作符”
   MCP 工具错误。
8. IF aggregate pipeline 包含写阶段（`$out`、`$merge`），THEN THE `mongo_query` 工具 SHALL 在不
   执行该查询的情况下返回一条“禁止使用写阶段”MCP 工具错误。
9. WHEN 查询成功执行，THE `mongo_query` 工具 SHALL 将查询结果以 JSON 形式返回给调用方。
10. IF 查询格式无法识别或执行失败，THEN THE `mongo_query` 工具 SHALL 返回一条包含失败原因的
    MCP 工具错误。

### 需求 6：redis_query 工具（只读命令白名单）

**用户故事：** 作为一个运维人员，我想要对某实例对应的 Redis 执行只读命令，以便检查缓存与运行时
状态而不改动任何数据。

#### 验收标准

1. THE `redis_query` 工具 SHALL 接受 project、env、instance 与 command 四个参数。
2. WHERE 该 (project, env) 使用 etcd 模型，THE `redis_query` 工具 SHALL 从配置文件读取 Redis
   地址（etcd 不携带 Redis 信息）。
3. WHERE 该 (project, env) 使用 mongo 回退模型，THE `redis_query` 工具 SHALL 从
   `processes.vars.redis` 读取 Redis 目标地址（形如 `<host>:<port>`）。
4. WHEN 连接 Redis，THE `redis_query` 工具 SHALL 使用配置文件中的 Redis 凭据，并对该 env 优先
   使用 Redis 按 env 凭据，否则使用 Redis 全局凭据。
5. IF mongo 回退模型下 `processes` 文档缺少 `vars.redis` 字段，OR `vars.redis` 为空字符串或仅含
   空白，THEN THE `redis_query` 工具 SHALL 返回一条指明该实例未配置 Redis 地址（并包含实例名）的
   MCP 工具错误。
6. THE `redis_query` 工具 SHALL 维护一个只读命令白名单，至少包含 GET、MGET、HGET、HGETALL、
   LRANGE、SMEMBERS、ZRANGE、TYPE、TTL、EXISTS、SCAN、INFO。
7. WHEN 收到的命令的命令名（不区分大小写）存在于只读命令白名单中，THE `redis_query` 工具 SHALL
   对 Redis 目标执行该命令并将结果返回给调用方。
8. IF 命令名是写命令（例如 SET、DEL、EXPIRE，以及任意 `FLUSH*` 命令），THEN THE `redis_query`
   工具 SHALL 在不执行该命令的情况下返回一条“仅允许只读命令”MCP 工具错误。
9. IF 命令名是危险命令（例如 CONFIG、EVAL、FLUSHALL、FLUSHDB、SHUTDOWN），THEN THE `redis_query`
   工具 SHALL 在不执行该命令的情况下返回一条“命令被拒绝”MCP 工具错误。
10. IF 命令名不存在于只读命令白名单中，THEN THE `redis_query` 工具 SHALL 在不执行该命令的情况下
    返回一条“不支持的命令”MCP 工具错误。
11. IF 与 Redis 目标的连接失败或命令执行失败，THEN THE `redis_query` 工具 SHALL 返回一条包含失败
    原因的 MCP 工具错误。

### 需求 7：pprof_collect 工具（代理转发）

**用户故事：** 作为一个 LLM 驱动的运维人员，我想要让网关代我采集某实例的 pprof profile，以便
无需直接访问内网即可获得性能诊断数据。

> **说明（示例）：** 以下两种采集均由同一个 `pprof_collect` 工具处理，仅 profile 名称与
> `seconds` 不同：
>
> - trace 采集 120 秒：`pprof_collect(project, env, instance, "trace", 120)` →
>   `GET http://<host_ip>:<port>/debug/pprof/trace?seconds=120`
> - CPU profile 采集 30 秒：`pprof_collect(project, env, instance, "profile", 30)` →
>   `GET http://<host_ip>:<port>/debug/pprof/profile?seconds=30`

#### 验收标准

1. THE `pprof_collect` 工具 SHALL 接受 project、env、instance、profile 四个参数与一个可选的
   `seconds` 时长参数。
2. IF profile 名称不是 {allocs, block, cmdline, goroutine, heap, mutex, profile, threadcreate,
   trace} 之一，THEN THE `pprof_collect` 工具 SHALL 在不发起任何请求的情况下返回一条“profile
   名称不受支持”MCP 工具错误。
3. IF 提供了 `seconds` 参数且其值不是位于 1 到 3600（含）区间内的整数，THEN THE `pprof_collect`
   工具 SHALL 在不发起任何请求的情况下返回一条时长校验错误 MCP 工具错误。
4. WHERE profile 为 `profile`（CPU）或 `trace`，THE `pprof_collect` 工具 SHALL 允许提供可选的
   整数 `seconds`（1 到 3600，含），并在发起请求时以查询参数 `?seconds=<seconds>` 形式追加到
   pprof 端点 URL。
5. IF 为 `profile` 与 `trace` 以外的任何 profile 提供了 `seconds` 参数，THEN THE `pprof_collect`
   工具 SHALL 在不发起任何请求的情况下返回一条指明该 profile 不接受 `seconds` 时长参数的 MCP
   工具错误，而非静默忽略该参数。
6. WHEN 调用 `pprof_collect`，THE MCP Gateway SHALL 通过 Service Resolver 解析 (project, env,
   instance)，并按端口推导规则计算 pprof 端口。
7. WHERE 该 (project, env) 使用 etcd 模型，THE `pprof_collect` 工具 SHALL 取 etcd value 中 `Addr`
   字段的 IP 部分作为目标主机 IP（例如 `192.168.5.29:22032` → `192.168.5.29`）（待确认）。
8. WHERE 该 (project, env) 使用 mongo 回退模型，THE `pprof_collect` 工具 SHALL 经
   `processes.host_id` 查询 `hosts` 集合（按 `_id` 等于 `host_id` 过滤）读取 `lanip` 作为目标
   主机 IP（待确认）。
9. IF 无法解析出目标主机 IP（etcd value 缺少 `Addr` 或其 IP 部分为空，OR mongo 回退模型下
   `host_id` 为空、无匹配 `hosts` 文档、`lanip` 为空），THEN THE `pprof_collect` 工具 SHALL 返回
   一条指明无法解析目标主机的 MCP 工具错误。
10. WHEN 目标主机 IP 与 pprof 端口解析成功，THE `pprof_collect` 工具 SHALL 向 pprof 端点
    `http://<host_ip>:<Pprof Port>/debug/pprof/<Profile Name>` 发起一个 HTTP GET 请求，并仅当
    profile 为 `profile` 或 `trace` 且提供了 `seconds` 时追加查询参数 `?seconds=<seconds>`。
11. WHEN 请求的 profile 为 `cmdline`，THE `pprof_collect` 工具 SHALL 照常向 pprof 端点发起 HTTP
    GET 请求，但在将响应返回给调用方之前 SHALL 对响应中的命令行文本进行密钥脱敏（redact）。
12. WHEN 对 `cmdline` 文本进行脱敏，THE `pprof_collect` 工具 SHALL 至少覆盖以下三类密钥：连接串中
    内嵌的凭据（`user:password@host` → `user:****@host`）；敏感命令行 flag（如 `--pass`、
    `--password`、`--token`、`--secret`、`--key` 及其短形式）的取值；以及敏感 URL 查询参数
    （如 `password=`、`token=`）的值，并 SHALL 复用 需求 9 与 需求 11 中对 `DBURL` 密码所要求的
    同一掩码原则（凭据绝不暴露给调用方）。
13. IF 无法对 `cmdline` 文本可靠地完成脱敏，THEN THE `pprof_collect` 工具 SHALL 确保不向调用方
    返回任何未掩码的密钥（例如返回一条指明脱敏失败的 MCP 工具错误，而非返回可能含密钥的原文）。
14. WHEN pprof 请求以成功的 HTTP 状态完成，THE `pprof_collect` 工具 SHALL 将（对 `cmdline` 已完成
    脱敏后的）完整响应体以 base64 编码的二进制 blob 形式返回给调用方。
15. THE `pprof_collect` 工具 SHALL 同步执行采集，并 SHALL 应用一个超过所请求 `seconds` 时长的
    HTTP 请求超时，使采集能够在超时之前完成。
16. WHERE 调用方请求了基于时间的 profile（profile 或 trace），THE `pprof_collect` 工具 SHALL 在
    工具描述中说明客户端需要为该调用配置足够长的超时时间。
17. IF pprof 请求连接失败、超过 HTTP 请求超时，OR 返回非成功的 HTTP 状态，THEN THE
    `pprof_collect` 工具 SHALL 返回一条包含失败详情的 MCP 工具错误。

#### pprof 端口推导

18. THE Port Base Mapping SHALL 内置如下基准端口：service-type `game` 为 27000，`cross` 为
    28000，`gate` 为 24000，并允许在配置文件中覆盖。
19. WHEN 推导 pprof 端口，THE MCP Gateway SHALL 将端口计算为该 service-type 的基准端口加上
    serverid（`port = base + serverid`），例如 game421→27421、cross1008→29008、gate5→24005。
20. IF service-type 在配置文件覆盖与内置默认值中都没有对应的基准端口，THEN THE `pprof_collect`
    工具 SHALL 返回一条点名该 service-type 的“未知 service-type”MCP 工具错误。
21. IF 推导出的 pprof 端口落在 1 到 65535（含）区间之外，THEN THE `pprof_collect` 工具 SHALL
    返回一条“端口超出范围”MCP 工具错误。

### 需求 8：list_instances 发现工具

**用户故事：** 作为一个 LLM 客户端，我想要列出某 (project, env) 下可用的实例名，以便在调用其它
工具时无需猜测实例名。

#### 验收标准

1. THE `list_instances` 工具 SHALL 接受 project 与 env 两个参数。
2. WHERE 该 (project, env) 使用 etcd 模型且其 `namespace` 标志为 `true`，THE `list_instances`
   工具 SHALL 按 etcd 前缀 `{env}/{project}/gs/` 列举可用实例。
3. WHERE 该 (project, env) 使用 etcd 模型且其 `namespace` 标志为 `false`，THE `list_instances`
   工具 SHALL 按 etcd 前缀 `{project}/gs/` 列举可用实例。
4. WHERE 该 (project, env) 使用 mongo 回退模型，THE `list_instances` 工具 SHALL 查询管理数据库的
   `processes` 集合，按 project 过滤可用实例。
5. WHEN 列举成功，THE `list_instances` 工具 SHALL 返回一个实例列表，其中每个条目至少包含可用于
   调用其它工具的实例名（由 service-type 与 serverid 组合而成）及基本信息。
6. THE `list_instances` 工具 SHALL NOT 在返回结果中包含任何凭据或 `DBURL` 中的密码。
7. IF 与 etcd 集群或管理数据库的连接或列举失败，THEN THE `list_instances` 工具 SHALL 返回一条
   包含失败原因的 MCP 工具错误。

### 需求 9：端到端只读安全姿态与凭据不暴露

**用户故事：** 作为一个平台负责人，我想要整套链路对受管系统严格只读且绝不泄露内部凭据，以便任何
工具调用都无法改变运维状态或获取内部连接信息。

#### 验收标准

1. THE MCP Gateway SHALL 使用配置文件中对 mongo 仅具有只读权限的 Read-only Account 连接所有
   mongo（管理数据库与目标数据库）。
2. THE `mongo_query` 工具 SHALL 仅允许只读方法白名单中的方法，并 SHALL 拒绝任何写操作、
   server-side JS 操作符与 aggregate 写阶段。
3. THE `redis_query` 工具 SHALL 仅允许只读命令白名单中的命令，并 SHALL 拒绝写命令与危险命令。
4. THE `pprof_collect` 工具 SHALL 仅向已解析主机的 `/debug/pprof/` 路径发起 HTTP GET 请求。
5. IF 某个 pprof 采集动作需要 GET 以外的任何 HTTP 方法，THEN THE `pprof_collect` 工具 SHALL 在
   不发送该请求的情况下拒绝该动作，并返回一条指明仅允许 HTTP GET 的 MCP 工具错误。
6. THE MCP Gateway SHALL 仅对 etcd 做只读 get/prefix 操作且仅供内部服务解析使用，并 SHALL NOT
   暴露任何通用 etcd 工具。
7. THE MCP Gateway SHALL NOT 使用 etcd `DBURL` 或 `processes.vars.dburl` 中内嵌的凭据建立任何
   连接。
8. THE MCP Gateway SHALL NOT 向调用方暴露任何内部连接细节（主机 IP、端口、数据库连接串、etcd
   集群 endpoints、Redis 地址、数据库凭据，OR etcd `DBURL` 中的密码）。
9. THE MCP Gateway SHALL NOT 在任何工具结果中暴露明文凭据，包括 etcd `DBURL` 中内嵌的密码，
   以及 `pprof_collect` 的 `cmdline` profile 响应中出现的密钥（连接串内嵌凭据、敏感命令行 flag
   取值、敏感 URL 查询参数值），二者均 SHALL 在返回调用方前完成掩码 / 脱敏。

### 需求 10：工具元数据自描述质量

**用户故事：** 作为一个消费这些工具的 LLM，我想要每个工具的名称、描述与参数 schema 足够自描述，
以便我无需额外的用户说明即可正确自动发现并路由到合适的工具并填写参数。

#### 验收标准

1. THE MCP Gateway SHALL 为每个工具提供足够自描述的名称、描述与输入参数 schema，使消费方 LLM
   能够通过 tools/list 正确自动发现并路由到合适的工具，无需额外用户说明。
2. THE 工具元数据 SHALL 说明实例名格式 `<service><id>`（前导字母为 service-type、结尾数字为
   serverid）。
3. THE 工具元数据 SHALL 说明 project 与 env 选择器的含义（env 即版本级别 / version level）。
4. THE `pprof_collect` 工具元数据 SHALL 列出允许的 profile 名称（allocs、block、cmdline、
   goroutine、heap、mutex、profile、threadcreate、trace）及 `seconds` 参数的取值范围
   （1 到 3600，仅适用于 `profile` 与 `trace`）。
5. THE `mongo_query` 工具元数据 SHALL 列出允许的只读方法
   （find、findOne、count、countDocuments、estimatedDocumentCount、aggregate、distinct）及允许的
   游标链（`.sort`、`.skip`、`.limit`）。
6. THE 各工具元数据 SHALL 说明其只读性质（mongo 只读、Redis 只读、pprof 仅 HTTP GET）。

### 需求 11：错误处理与对 LLM 友好的结果

**用户故事：** 作为一个消费这些工具的 LLM，我想要结构化、可预测的结果与清晰的错误，以便可靠地
解析结果并区分成功与失败。

#### 验收标准

1. WHEN 某工具成功执行，THE MCP Gateway SHALL 以结构化、可预测的形式返回结果：`mongo_query` 与
   `list_instances` 返回 JSON，`redis_query` 返回命令结果，`pprof_collect` 返回 base64 二进制
   blob。
2. IF 某工具执行失败，THEN THE MCP Gateway SHALL 以 MCP 工具错误的形式返回一条清晰的错误消息，
   而非静默失败或返回空结果。
3. WHEN 某工具因输入校验被拒绝（无效实例名、不支持的方法/命令、不支持的 profile、无效时长、
   未配置 etcd 集群且 mongo 回退也无匹配），THE MCP Gateway SHALL 在不访问任何内网资源的情况下
   返回一条指明具体校验失败原因的 MCP 工具错误。
4. WHEN 返回任何错误消息或结果，THE MCP Gateway SHALL 对其中出现的任何 `DBURL` 密码以及
   `pprof_collect` 的 `cmdline` 响应中的密钥（连接串内嵌凭据、敏感命令行 flag 取值、敏感 URL
   查询参数值）做掩码 / 脱敏处理，并 SHALL NOT 包含任何明文内部凭据。
5. WHILE 任意单个工具调用正在处理或失败，THE MCP Gateway SHALL 保持服务持续可用以处理后续请求。
