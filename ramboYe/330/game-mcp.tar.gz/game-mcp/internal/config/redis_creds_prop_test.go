package config

// Feature: pprof-redis-proxy, Property 7: Redis 凭据优先级 service > env > global
//
// Validates: Requirements 3.8, 3.9, 6.4

import (
	"testing"

	"pgregory.net/rapid"
)

// credStringGen generates an optional, non-empty credential string.
// Returns a *string that is either nil (absent) or points to a non-empty value.
var credStringGen = rapid.Custom(func(t *rapid.T) *string {
	present := rapid.Bool().Draw(t, "present")
	if !present {
		return nil
	}
	v := rapid.StringMatching(`[a-zA-Z0-9_]{1,20}`).Draw(t, "value")
	return &v
})

// addrGen generates an optional address string: either empty (absent) or a
// non-empty "host:port" style string safe for use as a Redis address.
var addrGen = rapid.Custom(func(t *rapid.T) string {
	present := rapid.Bool().Draw(t, "addrPresent")
	if !present {
		return ""
	}
	return rapid.StringMatching(`[a-zA-Z0-9]{1,10}:[0-9]{1,5}`).Draw(t, "addrValue")
})

// strVal dereferences a *string, returning "" for nil.
func strVal(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}

// TestRedisCredsPriority_Property7_ServiceGtEnvGtGlobal verifies that
// ResolveRedisCredentials always selects the credential value from the
// highest-priority layer that has an explicit (non-nil) value:
//
//	Highest: redis.envs.<env>.services.<service>  (service override)
//	Middle:  redis.envs.<env>                     (per-env)
//	Lowest:  redis.global                         (global default)
//
// For each randomly generated configuration, the test independently computes
// what the expected credential should be by applying the same priority rules,
// and asserts that ResolveRedisCredentials returns exactly that value.
// ≥100 iterations (rapid default, typically 100).
func TestRedisCredsPriority_Property7_ServiceGtEnvGtGlobal(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		const env = "testenv"
		const service = "gs"

		// ── Global layer ──────────────────────────────────────────────────────
		globalUser := rapid.StringMatching(`[a-zA-Z0-9_]{1,20}`).Draw(t, "globalUser")
		globalPass := rapid.StringMatching(`[a-zA-Z0-9_]{1,20}`).Draw(t, "globalPass")

		// ── Env layer (the whole env entry may or may not exist) ──────────────
		envExists := rapid.Bool().Draw(t, "envExists")
		var (
			envAddr *string // use pointer to model presence
			envUser *string
			envPass *string
		)
		if envExists {
			envAddr = func() *string {
				a := addrGen.Draw(t, "envAddr")
				if a == "" {
					return nil
				}
				return &a
			}()
			envUser = credStringGen.Draw(t, "envUser")
			envPass = credStringGen.Draw(t, "envPass")
		}

		// ── Service layer (only meaningful when env exists) ───────────────────
		svcExists := envExists && rapid.Bool().Draw(t, "svcExists")
		var (
			svcAddr *string
			svcUser *string
			svcPass *string
		)
		if svcExists {
			svcAddr = func() *string {
				a := addrGen.Draw(t, "svcAddr")
				if a == "" {
					return nil
				}
				return &a
			}()
			svcUser = credStringGen.Draw(t, "svcUser")
			svcPass = credStringGen.Draw(t, "svcPass")
		}

		// ── Build Config ──────────────────────────────────────────────────────
		cfg := &Config{
			Redis: RedisConfig{
				Global: Credential{
					User: globalUser,
					Pass: globalPass,
				},
			},
		}

		if envExists {
			redisEnv := RedisEnv{
				User: envUser,
				Pass: envPass,
			}
			if envAddr != nil {
				redisEnv.Addr = *envAddr
			}
			if svcExists {
				svc := RedisService{
					User: svcUser,
					Pass: svcPass,
				}
				if svcAddr != nil {
					svc.Addr = *svcAddr
				}
				redisEnv.Services = map[string]RedisService{service: svc}
			}
			cfg.Redis.Envs = map[string]RedisEnv{env: redisEnv}
		}

		// ── Compute expected values independently ─────────────────────────────
		// User: walk from global → env → service, taking the last non-nil layer.
		expectedUser := globalUser
		expectedPass := globalPass
		expectedAddr := ""

		if envExists {
			if envAddr != nil {
				expectedAddr = *envAddr
			}
			if envUser != nil {
				expectedUser = *envUser
			}
			if envPass != nil {
				expectedPass = *envPass
			}
			if svcExists {
				if svcAddr != nil {
					expectedAddr = *svcAddr
				}
				if svcUser != nil {
					expectedUser = *svcUser
				}
				if svcPass != nil {
					expectedPass = *svcPass
				}
			}
		}

		// ── Run the function under test ───────────────────────────────────────
		got := ResolveRedisCredentials(cfg, env, service)

		// ── Assert ────────────────────────────────────────────────────────────
		if got.User != expectedUser {
			t.Fatalf("User mismatch: got %q, want %q\n"+
				"  globalUser=%q envUser=%v svcUser=%v\n"+
				"  envExists=%v svcExists=%v",
				got.User, expectedUser,
				globalUser, strVal(envUser), strVal(svcUser),
				envExists, svcExists)
		}
		if got.Pass != expectedPass {
			t.Fatalf("Pass mismatch: got %q, want %q\n"+
				"  globalPass=%q envPass=%v svcPass=%v\n"+
				"  envExists=%v svcExists=%v",
				got.Pass, expectedPass,
				globalPass, strVal(envPass), strVal(svcPass),
				envExists, svcExists)
		}
		if got.Addr != expectedAddr {
			t.Fatalf("Addr mismatch: got %q, want %q\n"+
				"  envAddr=%v svcAddr=%v\n"+
				"  envExists=%v svcExists=%v",
				got.Addr, expectedAddr,
				strVal(envAddr), strVal(svcAddr),
				envExists, svcExists)
		}
	})
}

// TestRedisCredsPriority_Property7_ServiceWinsOverEnvAndGlobal verifies the
// focused case where all three layers exist simultaneously: the service layer
// must dominate for every credential field it explicitly sets.
//
// ≥100 iterations (rapid default).
func TestRedisCredsPriority_Property7_ServiceWinsOverEnvAndGlobal(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		const env = "prod"
		const service = "gate"

		cred := rapid.StringMatching(`[a-zA-Z0-9_]{1,20}`)

		globalUser := cred.Draw(t, "globalUser")
		globalPass := cred.Draw(t, "globalPass")
		envUser := cred.Draw(t, "envUser")
		envPass := cred.Draw(t, "envPass")
		envAddr := rapid.StringMatching(`[a-zA-Z0-9]{1,10}:[0-9]{1,5}`).Draw(t, "envAddr")
		svcUser := cred.Draw(t, "svcUser")
		svcPass := cred.Draw(t, "svcPass")
		svcAddr := rapid.StringMatching(`[a-zA-Z0-9]{1,10}:[0-9]{1,5}`).Draw(t, "svcAddr")

		cfg := &Config{
			Redis: RedisConfig{
				Global: Credential{User: globalUser, Pass: globalPass},
				Envs: map[string]RedisEnv{
					env: {
						Addr: envAddr,
						User: &envUser,
						Pass: &envPass,
						Services: map[string]RedisService{
							service: {
								Addr: svcAddr,
								User: &svcUser,
								Pass: &svcPass,
							},
						},
					},
				},
			},
		}

		got := ResolveRedisCredentials(cfg, env, service)

		if got.User != svcUser {
			t.Fatalf("service User should win: got %q, want %q (env=%q global=%q)",
				got.User, svcUser, envUser, globalUser)
		}
		if got.Pass != svcPass {
			t.Fatalf("service Pass should win: got %q, want %q (env=%q global=%q)",
				got.Pass, svcPass, envPass, globalPass)
		}
		if got.Addr != svcAddr {
			t.Fatalf("service Addr should win: got %q, want %q (env=%q)",
				got.Addr, svcAddr, envAddr)
		}
	})
}

// TestRedisCredsPriority_Property7_EnvWinsOverGlobal verifies that when no
// service override exists the env layer takes priority over global.
//
// ≥100 iterations (rapid default).
func TestRedisCredsPriority_Property7_EnvWinsOverGlobal(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		const env = "staging"
		const service = "cross"

		cred := rapid.StringMatching(`[a-zA-Z0-9_]{1,20}`)

		globalUser := cred.Draw(t, "globalUser")
		globalPass := cred.Draw(t, "globalPass")
		envUser := cred.Draw(t, "envUser")
		envPass := cred.Draw(t, "envPass")
		envAddr := rapid.StringMatching(`[a-zA-Z0-9]{1,10}:[0-9]{1,5}`).Draw(t, "envAddr")

		cfg := &Config{
			Redis: RedisConfig{
				Global: Credential{User: globalUser, Pass: globalPass},
				Envs: map[string]RedisEnv{
					env: {
						Addr: envAddr,
						User: &envUser,
						Pass: &envPass,
						// No service override.
					},
				},
			},
		}

		got := ResolveRedisCredentials(cfg, env, service)

		if got.User != envUser {
			t.Fatalf("env User should win over global: got %q, want %q (global=%q)",
				got.User, envUser, globalUser)
		}
		if got.Pass != envPass {
			t.Fatalf("env Pass should win over global: got %q, want %q (global=%q)",
				got.Pass, envPass, globalPass)
		}
		if got.Addr != envAddr {
			t.Fatalf("env Addr should be used when no service override: got %q, want %q",
				got.Addr, envAddr)
		}
	})
}

// TestRedisCredsPriority_Property7_GlobalFallback verifies that when neither
// env nor service entries exist, global credentials are returned and addr is
// empty (global has no address).
//
// ≥100 iterations (rapid default).
func TestRedisCredsPriority_Property7_GlobalFallback(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		cred := rapid.StringMatching(`[a-zA-Z0-9_]{1,20}`)
		globalUser := cred.Draw(t, "globalUser")
		globalPass := cred.Draw(t, "globalPass")

		// Draw env/service names that are guaranteed absent from the config.
		env := rapid.StringMatching(`[a-z]{3,10}`).Draw(t, "env")
		service := rapid.StringMatching(`[a-z]{3,10}`).Draw(t, "service")

		cfg := &Config{
			Redis: RedisConfig{
				Global: Credential{User: globalUser, Pass: globalPass},
				// Envs is nil — no env entries at all.
			},
		}

		got := ResolveRedisCredentials(cfg, env, service)

		if got.User != globalUser {
			t.Fatalf("global User should be returned when no env/service: got %q, want %q",
				got.User, globalUser)
		}
		if got.Pass != globalPass {
			t.Fatalf("global Pass should be returned when no env/service: got %q, want %q",
				got.Pass, globalPass)
		}
		if got.Addr != "" {
			t.Fatalf("Addr should be empty when only global exists: got %q", got.Addr)
		}
	})
}
