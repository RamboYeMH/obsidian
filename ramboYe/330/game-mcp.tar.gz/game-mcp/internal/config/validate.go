package config

import (
	"fmt"
	"regexp"
)

// serviceTypeRe matches a valid service-type key: non-empty, letters only.
var serviceTypeRe = regexp.MustCompile(`^[a-zA-Z]+$`)

// builtinPprofPortBases holds the default pprof port bases injected when not overridden.
var builtinPprofPortBases = map[string]int{
	"game":  27000,
	"cross": 28000,
	"gate":  24000,
}

// boolPtr returns a pointer to the given bool value.
func boolPtr(b bool) *bool {
	return &b
}

// Validate checks semantic constraints on cfg and injects missing default values.
//
// Validation rules (any failure returns an error; the caller should write it to
// stderr and refuse to start):
//  1. cfg.Tokens must be non-nil and non-empty (requirement 2.6).
//  2. cfg.Server.Listen must not be empty (requirement 3.12).
//  3. cfg.Mongo.Readonly: user and pass must both be set, or both be empty
//     (empty = anonymous / no-auth connection). A half-configured pair is an error.
//  5. Every entry in cfg.PprofPortBases must have a valid service-type key
//     (^[a-zA-Z]+$) and a port value in 1..65535 (requirement 3.10).
//
// Default value injection (mutations applied before the function returns):
//   - Built-in pprof port bases game=27000, cross=28000, gate=24000 are injected
//     into cfg.PprofPortBases when not already present (requirement 3.10).
//   - For each EtcdCluster: Namespace defaults to true, DBNameGroup defaults to
//     false when the respective pointer is nil (requirements 3.3, 3.4).
func Validate(cfg *Config) error {
	// 1. Token allowlist must not be empty.
	if len(cfg.Tokens) == 0 {
		return fmt.Errorf("token allowlist is empty or not configured")
	}

	// 2. server.listen is required.
	if cfg.Server.Listen == "" {
		return fmt.Errorf("server.listen is required but not configured")
	}

	// 3 & 4. mongo.readonly credentials.
	// 支持匿名连接：user 与 pass 均为空时视为无账号登录（目标库未开启鉴权）。
	// 但只要配置了 user，就必须同时配置 pass，避免半配错误。
	if cfg.Mongo.Readonly.User != "" && cfg.Mongo.Readonly.Pass == "" {
		return fmt.Errorf("mongo.readonly.pass is required when mongo.readonly.user is set")
	}
	if cfg.Mongo.Readonly.User == "" && cfg.Mongo.Readonly.Pass != "" {
		return fmt.Errorf("mongo.readonly.user is required when mongo.readonly.pass is set")
	}

	// 5. Validate each pprof_port_bases entry.
	for key, port := range cfg.PprofPortBases {
		if !serviceTypeRe.MatchString(key) {
			return fmt.Errorf(
				"pprof_port_bases: invalid service-type key %q (must match ^[a-zA-Z]+$)", key)
		}
		if port < 1 || port > 65535 {
			return fmt.Errorf(
				"pprof_port_bases: port base %d for service-type %q is out of range (must be 1..65535)",
				port, key)
		}
	}

	// --- Default value injection ---

	// Inject default log directory when not explicitly configured.
	if cfg.Log.Dir == "" {
		cfg.Log.Dir = "/data/game-mcp/log"
	}

	// Inject built-in pprof port bases for any key not already present.
	if cfg.PprofPortBases == nil {
		cfg.PprofPortBases = make(map[string]int)
	}
	for svc, base := range builtinPprofPortBases {
		if _, exists := cfg.PprofPortBases[svc]; !exists {
			cfg.PprofPortBases[svc] = base
		}
	}

	// Inject EtcdCluster defaults: Namespace → true, DBNameGroup → false.
	for project, envMap := range cfg.Etcd {
		for env, cluster := range envMap {
			if cluster.Namespace == nil {
				cluster.Namespace = boolPtr(true)
			}
			if cluster.DBNameGroup == nil {
				cluster.DBNameGroup = boolPtr(false)
			}
			// Write back because EtcdCluster is a value type in the map.
			cfg.Etcd[project][env] = cluster
		}
	}

	return nil
}
