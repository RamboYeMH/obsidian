// Package config defines the gateway configuration structures.
package config

// Config is the top-level gateway configuration loaded from the YAML file.
type Config struct {
	Server         ServerConfig                      `yaml:"server"`
	Tokens         []TokenEntry                      `yaml:"tokens"`
	Log            LogConfig                         `yaml:"log"`
	Mongo          MongoConfig                       `yaml:"mongo"`
	Etcd           map[string]map[string]EtcdCluster `yaml:"etcd"` // project -> env -> cluster
	Redis          RedisConfig                       `yaml:"redis"`
	PprofPortBases map[string]int                    `yaml:"pprof_port_bases"`
}

// LogConfig holds the access-log settings.
type LogConfig struct {
	// Dir is the directory where access log files are written.
	// Log files are rotated daily; each file is named access.YYYYMMDD.log.
	// Defaults to /data/game-mcp/log when not set.
	Dir string `yaml:"dir"`
}

// ServerConfig holds the HTTP listener and MCP endpoint path.
type ServerConfig struct {
	Listen    string `yaml:"listen"`
	Endpoint  string `yaml:"endpoint"`
	PublicURL string `yaml:"public_url"` // 供 pprof_save 构造下载链接，如 http://1.2.3.4:8080
}

// TokenEntry is a single Bearer token entry in the whitelist.
// Name is a human-readable audit label only; it does not participate in auth.
type TokenEntry struct {
	Name  string `yaml:"name"`  // 备注/审计，不参与鉴权
	Token string `yaml:"token"` // 实际 Bearer 凭据值
}

// MongoConfig holds the read-only credential used for all MongoDB connections
// and the autoops management-database access information.
type MongoConfig struct {
	Readonly Credential    `yaml:"readonly"`
	Autoops  AutoopsConfig `yaml:"autoops"`
}

// Credential is a simple username/password pair.
type Credential struct {
	User string `yaml:"user"`
	Pass string `yaml:"pass"`
}

// AutoopsConfig describes the autoops management database (mongo fallback backend).
// Account is optional; when absent, mongo.readonly is used instead.
// AuthSource is the authentication database; defaults to "admin" when empty.
type AutoopsConfig struct {
	Host       string      `yaml:"host"`
	Port       int         `yaml:"port"`
	DB         string      `yaml:"db"`
	AuthSource string      `yaml:"auth_source"` // 认证库，默认 "admin"
	Account    *Credential `yaml:"account"`     // 可空：覆盖管理库账号（仅回退路径）
}

// EtcdCluster describes a single etcd cluster for a (project, env) pair.
// DBNameGroup and Namespace use *bool so that "not set" can be distinguished
// from an explicit false (enabling correct default injection at validation time).
type EtcdCluster struct {
	Endpoints   []string `yaml:"endpoints"`
	DBNameGroup *bool    `yaml:"db_name_group"` // 指针区分"未设置(默认 false)"
	Namespace   *bool    `yaml:"namespace"`     // 指针区分"未设置(默认 true)"
}

// RedisConfig holds the global default Redis credentials and per-env overrides.
type RedisConfig struct {
	Global Credential          `yaml:"global"`
	Envs   map[string]RedisEnv `yaml:"envs"`
}

// RedisEnv describes the Redis configuration for a specific environment.
// User and Pass are pointers so that an absent value can be distinguished from
// an empty string, which matters for credential priority resolution.
type RedisEnv struct {
	Addr     string                  `yaml:"addr"`
	User     *string                 `yaml:"user"`
	Pass     *string                 `yaml:"pass"`
	Services map[string]RedisService `yaml:"services"`
}

// RedisService is a per-service Redis address/credential override (highest priority).
type RedisService struct {
	Addr string  `yaml:"addr"`
	User *string `yaml:"user"`
	Pass *string `yaml:"pass"`
}
