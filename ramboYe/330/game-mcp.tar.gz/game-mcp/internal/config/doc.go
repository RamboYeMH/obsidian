// Package config defines the gateway configuration structures,
// YAML loader, startup validation, and Redis credential priority resolution.
package config

import _ "gopkg.in/yaml.v3"
