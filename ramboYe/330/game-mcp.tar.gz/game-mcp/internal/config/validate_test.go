package config

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// minimalValidConfig returns a Config that satisfies all Validate constraints
// with the bare minimum fields set.
func minimalValidConfig() *Config {
	return &Config{
		Server: ServerConfig{
			Listen: ":8080",
		},
		Tokens: []TokenEntry{
			{Name: "test", Token: "secret-token"},
		},
		Mongo: MongoConfig{
			Readonly: Credential{
				User: "ro_user",
				Pass: "ro_pass",
			},
		},
	}
}

// TestValidate_DefaultNamespaceTrue verifies that an EtcdCluster with an unset
// Namespace pointer gets defaulted to true after Validate().
// Requirements: 3.3
func TestValidate_DefaultNamespaceTrue(t *testing.T) {
	cfg := minimalValidConfig()
	cfg.Etcd = map[string]map[string]EtcdCluster{
		"proj1": {
			"prod": {Endpoints: []string{"localhost:2379"}},
		},
	}
	if err := Validate(cfg); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	cluster := cfg.Etcd["proj1"]["prod"]
	if cluster.Namespace == nil {
		t.Fatal("Namespace should not be nil after Validate; expected default true")
	}
	if *cluster.Namespace != true {
		t.Errorf("Namespace default: got %v, want true", *cluster.Namespace)
	}
}

// TestValidate_DefaultDBNameGroupFalse verifies that an EtcdCluster with an
// unset DBNameGroup pointer gets defaulted to false after Validate().
// Requirements: 3.4
func TestValidate_DefaultDBNameGroupFalse(t *testing.T) {
	cfg := minimalValidConfig()
	cfg.Etcd = map[string]map[string]EtcdCluster{
		"proj1": {
			"prod": {Endpoints: []string{"localhost:2379"}},
		},
	}
	if err := Validate(cfg); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	cluster := cfg.Etcd["proj1"]["prod"]
	if cluster.DBNameGroup == nil {
		t.Fatal("DBNameGroup should not be nil after Validate; expected default false")
	}
	if *cluster.DBNameGroup != false {
		t.Errorf("DBNameGroup default: got %v, want false", *cluster.DBNameGroup)
	}
}

// TestValidate_ExplicitNamespaceFalsePreserved verifies that an explicitly set
// Namespace=false is not overwritten by the default injection.
func TestValidate_ExplicitNamespaceFalsePreserved(t *testing.T) {
	cfg := minimalValidConfig()
	f := false
	cfg.Etcd = map[string]map[string]EtcdCluster{
		"proj1": {"prod": {Endpoints: []string{"localhost:2379"}, Namespace: &f}},
	}
	if err := Validate(cfg); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	cluster := cfg.Etcd["proj1"]["prod"]
	if cluster.Namespace == nil || *cluster.Namespace != false {
		t.Errorf("explicit Namespace=false should be preserved; got %v", cluster.Namespace)
	}
}

// TestValidate_ExplicitDBNameGroupTruePreserved verifies that an explicitly set
// DBNameGroup=true is not overwritten by the default injection.
func TestValidate_ExplicitDBNameGroupTruePreserved(t *testing.T) {
	cfg := minimalValidConfig()
	tr := true
	cfg.Etcd = map[string]map[string]EtcdCluster{
		"proj1": {"prod": {Endpoints: []string{"localhost:2379"}, DBNameGroup: &tr}},
	}
	if err := Validate(cfg); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	cluster := cfg.Etcd["proj1"]["prod"]
	if cluster.DBNameGroup == nil || *cluster.DBNameGroup != true {
		t.Errorf("explicit DBNameGroup=true should be preserved; got %v", cluster.DBNameGroup)
	}
}

// TestValidate_BuiltinPprofPortBasesInjected verifies that game/cross/gate
// pprof port bases are injected when cfg.PprofPortBases is nil.
// Requirements: 2.6
func TestValidate_BuiltinPprofPortBasesInjected(t *testing.T) {
	cfg := minimalValidConfig()
	if err := Validate(cfg); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	want := map[string]int{"game": 27000, "cross": 28000, "gate": 24000}
	for svc, base := range want {
		got, ok := cfg.PprofPortBases[svc]
		if !ok {
			t.Errorf("built-in port base %q not injected", svc)
			continue
		}
		if got != base {
			t.Errorf("port base %q: got %d, want %d", svc, got, base)
		}
	}
}

// TestValidate_BuiltinPprofPortBaseNotOverwritten verifies that a user-supplied
// port base for "game" is not overwritten by the built-in default.
func TestValidate_BuiltinPprofPortBaseNotOverwritten(t *testing.T) {
	cfg := minimalValidConfig()
	cfg.PprofPortBases = map[string]int{"game": 30000}
	if err := Validate(cfg); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if cfg.PprofPortBases["game"] != 30000 {
		t.Errorf("user-supplied game port base should not be overwritten; got %d", cfg.PprofPortBases["game"])
	}
	if cfg.PprofPortBases["cross"] != 28000 {
		t.Errorf("cross port base not injected; got %d", cfg.PprofPortBases["cross"])
	}
	if cfg.PprofPortBases["gate"] != 24000 {
		t.Errorf("gate port base not injected; got %d", cfg.PprofPortBases["gate"])
	}
}

// TestValidate_EmptyTokensRejected verifies that a nil token list is rejected.
// Requirements: 2.6
func TestValidate_EmptyTokensRejected(t *testing.T) {
	cfg := minimalValidConfig()
	cfg.Tokens = nil
	err := Validate(cfg)
	if err == nil {
		t.Fatal("expected error for nil token list, got nil")
	}
	if !strings.Contains(strings.ToLower(err.Error()), "token") {
		t.Errorf("error message should mention 'token'; got: %s", err.Error())
	}
}

// TestValidate_EmptyTokenSliceRejected verifies that an explicitly empty token
// slice (not nil) is also rejected.
func TestValidate_EmptyTokenSliceRejected(t *testing.T) {
	cfg := minimalValidConfig()
	cfg.Tokens = []TokenEntry{}
	err := Validate(cfg)
	if err == nil {
		t.Fatal("expected error for empty token slice, got nil")
	}
}

// TestValidate_MissingServerListenRejected verifies that a missing server.listen
// causes Validate to return an error.
// Requirements: 3.12
func TestValidate_MissingServerListenRejected(t *testing.T) {
	cfg := minimalValidConfig()
	cfg.Server.Listen = ""
	err := Validate(cfg)
	if err == nil {
		t.Fatal("expected error for empty server.listen, got nil")
	}
	if !strings.Contains(strings.ToLower(err.Error()), "listen") {
		t.Errorf("error message should mention 'listen'; got: %s", err.Error())
	}
}

// TestValidate_MissingMongoReadonlyUserRejected verifies that a missing
// mongo.readonly.user causes Validate to return an error.
// Requirements: 3.12
func TestValidate_MissingMongoReadonlyUserRejected(t *testing.T) {
	cfg := minimalValidConfig()
	cfg.Mongo.Readonly.User = ""
	err := Validate(cfg)
	if err == nil {
		t.Fatal("expected error for empty mongo.readonly.user, got nil")
	}
	if !strings.Contains(strings.ToLower(err.Error()), "user") {
		t.Errorf("error message should mention 'user'; got: %s", err.Error())
	}
}

// TestValidate_MissingMongoReadonlyPassRejected verifies that a missing
// mongo.readonly.pass causes Validate to return an error.
// Requirements: 3.12
func TestValidate_MissingMongoReadonlyPassRejected(t *testing.T) {
	cfg := minimalValidConfig()
	cfg.Mongo.Readonly.Pass = ""
	err := Validate(cfg)
	if err == nil {
		t.Fatal("expected error for empty mongo.readonly.pass, got nil")
	}
	if !strings.Contains(strings.ToLower(err.Error()), "pass") {
		t.Errorf("error message should mention 'pass'; got: %s", err.Error())
	}
}

// TestValidate_MalformedPprofPortBase_PortZero verifies that a port base of 0 is rejected.
func TestValidate_MalformedPprofPortBase_PortZero(t *testing.T) {
	cfg := minimalValidConfig()
	cfg.PprofPortBases = map[string]int{"game": 0}
	err := Validate(cfg)
	if err == nil {
		t.Fatal("expected error for port base 0, got nil")
	}
}

// TestValidate_MalformedPprofPortBase_PortNegative verifies that a negative port base is rejected.
func TestValidate_MalformedPprofPortBase_PortNegative(t *testing.T) {
	cfg := minimalValidConfig()
	cfg.PprofPortBases = map[string]int{"game": -1}
	err := Validate(cfg)
	if err == nil {
		t.Fatal("expected error for negative port base, got nil")
	}
}

// TestValidate_MalformedPprofPortBase_PortTooHigh verifies that a port base > 65535 is rejected.
func TestValidate_MalformedPprofPortBase_PortTooHigh(t *testing.T) {
	cfg := minimalValidConfig()
	cfg.PprofPortBases = map[string]int{"game": 65536}
	err := Validate(cfg)
	if err == nil {
		t.Fatal("expected error for port base 65536, got nil")
	}
}

// TestValidate_MalformedPprofPortBase_InvalidKey verifies that a service-type key
// containing non-letter characters is rejected.
func TestValidate_MalformedPprofPortBase_InvalidKey(t *testing.T) {
	cases := []struct {
		name string
		key  string
	}{
		{"digits", "game1"},
		{"underscore", "game_svc"},
		{"hyphen", "game-svc"},
		{"empty", ""},
		{"space", "game svc"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			cfg := minimalValidConfig()
			cfg.PprofPortBases = map[string]int{tc.key: 27000}
			err := Validate(cfg)
			if err == nil {
				t.Errorf("expected error for invalid key %q, got nil", tc.key)
			}
		})
	}
}

// TestValidate_ValidPprofPortBase verifies that a valid port base passes validation.
func TestValidate_ValidPprofPortBase(t *testing.T) {
	cfg := minimalValidConfig()
	cfg.PprofPortBases = map[string]int{"mysvc": 20000}
	if err := Validate(cfg); err != nil {
		t.Errorf("unexpected error for valid port base: %v", err)
	}
}

// TestValidate_ValidConfig verifies that a fully-specified valid config passes
// all validation checks without error.
func TestValidate_ValidConfig(t *testing.T) {
	tr := true
	f := false
	cfg := &Config{
		Server: ServerConfig{
			Listen:   ":9000",
			Endpoint: "/mcp",
		},
		Tokens: []TokenEntry{
			{Name: "alice", Token: "tok-alice"},
			{Name: "bob", Token: "tok-bob"},
		},
		Mongo: MongoConfig{
			Readonly: Credential{User: "ro", Pass: "s3cret"},
		},
		Etcd: map[string]map[string]EtcdCluster{
			"myproject": {
				"dev":  {Endpoints: []string{"etcd1:2379"}, Namespace: &tr, DBNameGroup: &f},
				"prod": {Endpoints: []string{"etcd2:2379"}},
			},
		},
		PprofPortBases: map[string]int{"game": 27000, "cross": 28000},
	}

	if err := Validate(cfg); err != nil {
		t.Errorf("unexpected validation error: %v", err)
	}
}

// --- Loader YAML parse failure tests ---

// TestLoad_YAMLParseFailure verifies that Load returns an error when the file
// contains invalid YAML syntax.
// Requirements: 3.12
func TestLoad_YAMLParseFailure(t *testing.T) {
	tmp := t.TempDir()
	badYAML := filepath.Join(tmp, "bad.yaml")
	if err := os.WriteFile(badYAML, []byte(":\tinvalid: yaml: [\n"), 0o600); err != nil {
		t.Fatalf("failed to write temp file: %v", err)
	}

	_, err := Load(badYAML)
	if err == nil {
		t.Fatal("expected error for malformed YAML, got nil")
	}
	if !strings.Contains(strings.ToLower(err.Error()), "parse") &&
		!strings.Contains(strings.ToLower(err.Error()), "yaml") {
		t.Errorf("error message should indicate a YAML parse problem; got: %s", err.Error())
	}
}

// TestLoad_FileNotFound verifies that Load returns a descriptive error when the
// config file does not exist.
func TestLoad_FileNotFound(t *testing.T) {
	_, err := Load("/nonexistent/path/config.yaml")
	if err == nil {
		t.Fatal("expected error for missing file, got nil")
	}
}

// TestLoad_ValidYAML verifies that a syntactically valid YAML file is loaded
// without error and returns a non-nil Config.
func TestLoad_ValidYAML(t *testing.T) {
	tmp := t.TempDir()
	validYAML := filepath.Join(tmp, "good.yaml")
	content := `
server:
  listen: ":8080"
tokens:
  - name: ci
    token: mytoken
mongo:
  readonly:
    user: ro
    pass: secret
`
	if err := os.WriteFile(validYAML, []byte(content), 0o600); err != nil {
		t.Fatalf("failed to write temp file: %v", err)
	}

	cfg, err := Load(validYAML)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if cfg == nil {
		t.Fatal("expected non-nil Config, got nil")
	}
	if cfg.Server.Listen != ":8080" {
		t.Errorf("server.listen: got %q, want \":8080\"", cfg.Server.Listen)
	}
	if len(cfg.Tokens) != 1 || cfg.Tokens[0].Token != "mytoken" {
		t.Errorf("tokens not parsed correctly: %+v", cfg.Tokens)
	}
}
