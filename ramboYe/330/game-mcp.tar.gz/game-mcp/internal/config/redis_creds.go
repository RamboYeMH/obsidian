package config

// RedisCredentials holds the resolved Redis connection parameters for a given
// (env, service) pair after applying the three-level priority merge:
//
//	Highest: redis.envs.<env>.services.<service>  (service override)
//	Middle:  redis.envs.<env>                     (per-env)
//	Lowest:  redis.global                         (global default)
type RedisCredentials struct {
	User string
	Pass string
	Addr string
}

// ResolveRedisCredentials resolves the Redis credentials and address for the
// given (env, service) pair by merging the three configuration layers in
// priority order.
//
// Priority rules (high → low):
//  1. redis.envs.<env>.services.<service>  — service override (highest)
//  2. redis.envs.<env>                     — per-env settings
//  3. redis.global                         — global default (lowest)
//
// For credentials (user/pass): a layer overrides the lower layers only when
// its *string pointer is non-nil (explicitly set in YAML).
// For address: a layer overrides when its Addr string is non-empty.
//
// The function never panics even if the Envs or Services maps are nil.
func ResolveRedisCredentials(cfg *Config, env, service string) RedisCredentials {
	// Start from global defaults. Addr begins empty because global has no address.
	result := RedisCredentials{
		User: cfg.Redis.Global.User,
		Pass: cfg.Redis.Global.Pass,
		Addr: "",
	}

	// Layer 2: per-env override.
	envCfg, envOK := cfg.Redis.Envs[env]
	if envOK {
		if envCfg.Addr != "" {
			result.Addr = envCfg.Addr
		}
		if envCfg.User != nil {
			result.User = *envCfg.User
		}
		if envCfg.Pass != nil {
			result.Pass = *envCfg.Pass
		}

		// Layer 1: service override (highest priority, only available if env entry exists).
		svcCfg, svcOK := envCfg.Services[service]
		if svcOK {
			if svcCfg.Addr != "" {
				result.Addr = svcCfg.Addr
			}
			if svcCfg.User != nil {
				result.User = *svcCfg.User
			}
			if svcCfg.Pass != nil {
				result.Pass = *svcCfg.Pass
			}
		}
	}

	return result
}
