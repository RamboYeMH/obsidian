package config

import (
	"fmt"
	"os"

	"gopkg.in/yaml.v3"
)

// Load reads the YAML configuration file at path and returns a parsed Config.
//
// Errors:
//   - If the file does not exist or cannot be read, a descriptive error is returned.
//   - If the file contains invalid YAML syntax, a descriptive error wrapping the
//     parse error is returned.
//
// No semantic validation is performed here; call Validate() on the returned Config
// to enforce startup constraints (task 6.2).
func Load(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, fmt.Errorf("config file not found: %s", path)
		}
		return nil, fmt.Errorf("failed to read config file %s: %w", path, err)
	}

	var cfg Config
	if err := yaml.Unmarshal(data, &cfg); err != nil {
		return nil, fmt.Errorf("failed to parse config file %s: %w", path, err)
	}

	return &cfg, nil
}
