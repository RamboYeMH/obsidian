package gwerr_test

import (
	"errors"
	"fmt"
	"testing"

	"github.com/modelcontextprotocol/go-sdk/mcp"

	"game-mcp/internal/gwerr"
)

// helper to cast error to *GatewayError and fail if the assertion doesn't hold.
func asGatewayError(t *testing.T, err error) *gwerr.GatewayError {
	t.Helper()
	var ge *gwerr.GatewayError
	if !errors.As(err, &ge) {
		t.Fatalf("expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	return ge
}

// assertTextContent extracts the first TextContent from a CallToolResult and
// returns its text, failing the test if it is not present.
func assertTextContent(t *testing.T, result *mcp.CallToolResult) string {
	t.Helper()
	if len(result.Content) == 0 {
		t.Fatal("CallToolResult.Content is empty")
	}
	tc, ok := result.Content[0].(*mcp.TextContent)
	if !ok {
		t.Fatalf("expected *mcp.TextContent, got %T", result.Content[0])
	}
	return tc.Text
}

// ---------------------------------------------------------------------------
// Kind constructor tests
// ---------------------------------------------------------------------------

func TestValidation(t *testing.T) {
	err := gwerr.Validation("bad input: %s", "foo")
	ge := asGatewayError(t, err)
	if ge.Kind != gwerr.KindValidation {
		t.Errorf("expected KindValidation, got %v", ge.Kind)
	}
	if ge.Msg != "bad input: foo" {
		t.Errorf("unexpected Msg: %q", ge.Msg)
	}
}

func TestValidationWithCause(t *testing.T) {
	cause := errors.New("root cause")
	err := gwerr.ValidationWithCause(cause, "wrapped: %s", "val")
	ge := asGatewayError(t, err)
	if ge.Kind != gwerr.KindValidation {
		t.Errorf("expected KindValidation, got %v", ge.Kind)
	}
	if !errors.Is(err, cause) {
		t.Error("errors.Is should find the cause via Unwrap")
	}
}

func TestNotFound(t *testing.T) {
	err := gwerr.NotFound("instance %q not found", "game1")
	ge := asGatewayError(t, err)
	if ge.Kind != gwerr.KindNotFound {
		t.Errorf("expected KindNotFound, got %v", ge.Kind)
	}
	want := `instance "game1" not found`
	if ge.Msg != want {
		t.Errorf("Msg = %q, want %q", ge.Msg, want)
	}
}

func TestAmbiguous(t *testing.T) {
	err := gwerr.Ambiguous("matched %d instances", 3)
	ge := asGatewayError(t, err)
	if ge.Kind != gwerr.KindAmbiguous {
		t.Errorf("expected KindAmbiguous, got %v", ge.Kind)
	}
	if ge.Msg != "matched 3 instances" {
		t.Errorf("unexpected Msg: %q", ge.Msg)
	}
}

func TestConnection(t *testing.T) {
	err := gwerr.Connection("dial timeout to %s", "10.0.0.1:27017")
	ge := asGatewayError(t, err)
	if ge.Kind != gwerr.KindConnection {
		t.Errorf("expected KindConnection, got %v", ge.Kind)
	}
}

func TestConnectionWithCause(t *testing.T) {
	cause := errors.New("i/o timeout")
	err := gwerr.ConnectionWithCause(cause, "connection failed")
	ge := asGatewayError(t, err)
	if ge.Kind != gwerr.KindConnection {
		t.Errorf("expected KindConnection, got %v", ge.Kind)
	}
	if !errors.Is(err, cause) {
		t.Error("errors.Is should find the cause via Unwrap")
	}
}

func TestRejected(t *testing.T) {
	err := gwerr.Rejected("method %q is not allowed", "drop")
	ge := asGatewayError(t, err)
	if ge.Kind != gwerr.KindRejected {
		t.Errorf("expected KindRejected, got %v", ge.Kind)
	}
	want := `method "drop" is not allowed`
	if ge.Msg != want {
		t.Errorf("Msg = %q, want %q", ge.Msg, want)
	}
}

func TestUpstream(t *testing.T) {
	err := gwerr.Upstream("backend returned code %d", 500)
	ge := asGatewayError(t, err)
	if ge.Kind != gwerr.KindUpstream {
		t.Errorf("expected KindUpstream, got %v", ge.Kind)
	}
	if ge.Msg != "backend returned code 500" {
		t.Errorf("unexpected Msg: %q", ge.Msg)
	}
}

func TestUpstreamWithCause(t *testing.T) {
	cause := errors.New("EOF")
	err := gwerr.UpstreamWithCause(cause, "upstream error")
	ge := asGatewayError(t, err)
	if ge.Kind != gwerr.KindUpstream {
		t.Errorf("expected KindUpstream, got %v", ge.Kind)
	}
	if !errors.Is(err, cause) {
		t.Error("errors.Is should find the cause via Unwrap")
	}
}

func TestRedaction(t *testing.T) {
	err := gwerr.Redaction("redaction failed: %s", "pattern mismatch")
	ge := asGatewayError(t, err)
	if ge.Kind != gwerr.KindRedaction {
		t.Errorf("expected KindRedaction, got %v", ge.Kind)
	}
}

// ---------------------------------------------------------------------------
// Error() interface
// ---------------------------------------------------------------------------

func TestError_ReturnsMsg(t *testing.T) {
	msg := "something went wrong"
	err := gwerr.Validation("%s", msg)
	if err.Error() != msg {
		t.Errorf("Error() = %q, want %q", err.Error(), msg)
	}
}

func TestError_FormattedMsg(t *testing.T) {
	err := gwerr.NotFound("no instance named %q in env %q", "cross1", "prod")
	want := `no instance named "cross1" in env "prod"`
	if err.Error() != want {
		t.Errorf("Error() = %q, want %q", err.Error(), want)
	}
}

// ---------------------------------------------------------------------------
// Unwrap()
// ---------------------------------------------------------------------------

func TestUnwrap_NilWhenNoCause(t *testing.T) {
	err := gwerr.Validation("no cause")
	var ge *gwerr.GatewayError
	errors.As(err, &ge)
	if ge.Unwrap() != nil {
		t.Errorf("Unwrap() should be nil when no cause, got %v", ge.Unwrap())
	}
}

func TestUnwrap_ReturnsCause(t *testing.T) {
	sentinel := fmt.Errorf("sentinel")
	err := gwerr.ConnectionWithCause(sentinel, "outer")
	if !errors.Is(err, sentinel) {
		t.Error("errors.Is traversal via Unwrap should reach the sentinel")
	}
}

// ---------------------------------------------------------------------------
// ToMCPToolError() — Requirements 11.2
// ---------------------------------------------------------------------------

func TestToMCPToolError_IsError(t *testing.T) {
	constructors := []struct {
		name string
		err  error
	}{
		{"Validation", gwerr.Validation("v")},
		{"NotFound", gwerr.NotFound("nf")},
		{"Ambiguous", gwerr.Ambiguous("amb")},
		{"Connection", gwerr.Connection("conn")},
		{"Rejected", gwerr.Rejected("rej")},
		{"Upstream", gwerr.Upstream("up")},
		{"Redaction", gwerr.Redaction("red")},
	}

	for _, tc := range constructors {
		t.Run(tc.name, func(t *testing.T) {
			ge := asGatewayError(t, tc.err)
			result := ge.ToMCPToolError()
			if result == nil {
				t.Fatal("ToMCPToolError() returned nil")
			}
			if !result.IsError {
				t.Error("IsError should be true")
			}
		})
	}
}

func TestToMCPToolError_CarriesMessage(t *testing.T) {
	msg := "instance not found: game42"
	err := gwerr.NotFound("%s", msg)
	ge := asGatewayError(t, err)
	result := ge.ToMCPToolError()
	text := assertTextContent(t, result)
	if text != msg {
		t.Errorf("text content = %q, want %q", text, msg)
	}
}

func TestToMCPToolError_MessageMatchesErrorString(t *testing.T) {
	err := gwerr.Upstream("backend timeout after %dms", 5000)
	ge := asGatewayError(t, err)
	result := ge.ToMCPToolError()
	text := assertTextContent(t, result)
	if text != err.Error() {
		t.Errorf("MCP text %q != Error() %q", text, err.Error())
	}
}

func TestToMCPToolError_HasExactlyOneContent(t *testing.T) {
	ge := asGatewayError(t, gwerr.Rejected("not allowed"))
	result := ge.ToMCPToolError()
	if len(result.Content) != 1 {
		t.Errorf("expected 1 content item, got %d", len(result.Content))
	}
}
