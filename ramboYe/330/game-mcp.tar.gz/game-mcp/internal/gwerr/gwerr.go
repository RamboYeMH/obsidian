package gwerr

import (
	"fmt"

	"github.com/modelcontextprotocol/go-sdk/mcp"
)

// Kind classifies a GatewayError so callers can distinguish error categories
// without parsing message text.
type Kind int

const (
	KindValidation Kind = iota // 输入校验失败（不触达内网）
	KindNotFound               // 实例不存在
	KindAmbiguous              // 实例不唯一
	KindConnection             // 连接/超时失败
	KindRejected               // 安全拒绝（方法/命令/HTTP方法）
	KindUpstream               // 后端执行失败
	KindRedaction              // 脱敏失败
)

// GatewayError is the unified error type for the MCP gateway. Msg is the
// already-masked, caller-safe message; err is the raw underlying error kept
// only for internal logging and never surfaced to callers.
type GatewayError struct {
	Kind Kind
	Msg  string // 已掩码的安全消息
	err  error  // 原始错误（仅内部日志，输出前掩码）
}

// Error implements the error interface, returning the safe masked message.
func (e *GatewayError) Error() string {
	return e.Msg
}

// Unwrap returns the underlying raw error, enabling errors.Is/As traversal.
func (e *GatewayError) Unwrap() error {
	return e.err
}

// ToMCPToolError converts the GatewayError into a CallToolResult with
// IsError=true and the masked message as text content. This is the canonical
// way to return a gateway error from an MCP tool handler.
func (e *GatewayError) ToMCPToolError() *mcp.CallToolResult {
	return &mcp.CallToolResult{
		Content: []mcp.Content{&mcp.TextContent{Text: e.Msg}},
		IsError: true,
	}
}

// newf constructs a GatewayError with the given kind, formatted message, and
// no underlying cause.
func newf(kind Kind, format string, args ...any) *GatewayError {
	return &GatewayError{Kind: kind, Msg: fmt.Sprintf(format, args...)}
}

// newfe constructs a GatewayError with the given kind, formatted message, and
// an underlying cause error.
func newfe(kind Kind, cause error, format string, args ...any) *GatewayError {
	return &GatewayError{Kind: kind, Msg: fmt.Sprintf(format, args...), err: cause}
}

// Validation returns a KindValidation GatewayError. Use this for input
// validation failures that are caught before touching any internal network
// resource (satisfies requirement 11.3).
func Validation(format string, args ...any) error {
	return newf(KindValidation, format, args...)
}

// ValidationWithCause returns a KindValidation GatewayError with an underlying
// cause error retained for internal logging.
func ValidationWithCause(cause error, format string, args ...any) error {
	return newfe(KindValidation, cause, format, args...)
}

// NotFound returns a KindNotFound GatewayError indicating that the requested
// instance does not exist.
func NotFound(format string, args ...any) error {
	return newf(KindNotFound, format, args...)
}

// Ambiguous returns a KindAmbiguous GatewayError indicating that the requested
// instance matched more than one record.
func Ambiguous(format string, args ...any) error {
	return newf(KindAmbiguous, format, args...)
}

// Connection returns a KindConnection GatewayError for connection or timeout
// failures.
func Connection(format string, args ...any) error {
	return newf(KindConnection, format, args...)
}

// ConnectionWithCause returns a KindConnection GatewayError with an underlying
// cause error retained for internal logging.
func ConnectionWithCause(cause error, format string, args ...any) error {
	return newfe(KindConnection, cause, format, args...)
}

// Rejected returns a KindRejected GatewayError for security rejections such as
// disallowed methods, commands, or HTTP methods.
func Rejected(format string, args ...any) error {
	return newf(KindRejected, format, args...)
}

// Upstream returns a KindUpstream GatewayError for failures that originate in
// a backend service after a successful connection.
func Upstream(format string, args ...any) error {
	return newf(KindUpstream, format, args...)
}

// UpstreamWithCause returns a KindUpstream GatewayError with an underlying
// cause error retained for internal logging.
func UpstreamWithCause(cause error, format string, args ...any) error {
	return newfe(KindUpstream, cause, format, args...)
}

// Redaction returns a KindRedaction GatewayError indicating that the redaction
// step failed and the caller must not return the unredacted content.
func Redaction(format string, args ...any) error {
	return newf(KindRedaction, format, args...)
}
