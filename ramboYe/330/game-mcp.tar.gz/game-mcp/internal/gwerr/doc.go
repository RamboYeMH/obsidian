// Package gwerr defines the gateway error type and kind-based constructors
// that map to MCP tool errors.
package gwerr
