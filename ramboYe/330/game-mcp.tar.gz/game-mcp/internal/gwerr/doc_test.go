// Package gwerr_test ensures build dependencies are retained.
package gwerr_test

import _ "pgregory.net/rapid"
