// Feature: pprof-redis-proxy, Property 17: 对外输出绝不含凭据
package mcptools

// Validates: Requirements 8.6, 9.8

import (
	"encoding/json"
	"fmt"
	"reflect"
	"strings"
	"testing"

	"pgregory.net/rapid"

	"game-mcp/internal/resolver"
)

// credentialFieldNames is the set of field names (case-insensitive) that must
// never appear on InstanceInfo or ResolvedTarget — these would constitute a
// credential leak.
var credentialFieldNames = []string{
	"password", "pass", "passwd", "secret", "token", "key",
	"credential", "cred", "dburl", "connstr", "connectionstring",
	"auth", "apikey",
}

// ---------------------------------------------------------------------------
// 1. Compile-time / reflection: InstanceInfo has no credential fields
// ---------------------------------------------------------------------------

// TestNoCredentials_Property17_InstanceInfoHasNoCredentialFields performs a
// reflection-based check that resolver.InstanceGroup contains no fields whose
// names suggest credential material.
//
// This is a deterministic (single-pass) check that acts as a compile-time
// guard expressed as a test.
func TestNoCredentials_Property17_InstanceInfoHasNoCredentialFields(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		typ := reflect.TypeOf(resolver.InstanceGroup{})
		for i := 0; i < typ.NumField(); i++ {
			fieldName := strings.ToLower(typ.Field(i).Name)
			for _, credWord := range credentialFieldNames {
				if strings.Contains(fieldName, credWord) {
					t.Fatalf(
						"InstanceGroup has a credential-named field %q (contains %q) — "+
							"credential fields must not be present on the public output struct "+
							"(Requirements 8.6, 9.8)",
						typ.Field(i).Name, credWord,
					)
				}
			}
		}
	})
}

// ---------------------------------------------------------------------------
// 2. Reflection: ResolvedTarget has no credential fields
// ---------------------------------------------------------------------------

// TestNoCredentials_Property17_ResolvedTargetHasNoCredentialFields mirrors the
// above check for resolver.ResolvedTarget.
func TestNoCredentials_Property17_ResolvedTargetHasNoCredentialFields(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		typ := reflect.TypeOf(resolver.ResolvedTarget{})
		for i := 0; i < typ.NumField(); i++ {
			fieldName := strings.ToLower(typ.Field(i).Name)
			for _, credWord := range credentialFieldNames {
				if strings.Contains(fieldName, credWord) {
					t.Fatalf(
						"ResolvedTarget has a credential-named field %q (contains %q) — "+
							"credential fields must not be present on the routing output struct "+
							"(Requirements 8.6, 9.8)",
						typ.Field(i).Name, credWord,
					)
				}
			}
		}
	})
}

// ---------------------------------------------------------------------------
// 3. ParseDBURL + ExtractHostIP: credential material never enters ResolvedTarget
// ---------------------------------------------------------------------------

// safeCredComponent generates non-empty alphanumeric strings (1-16 chars)
// that are safe to embed inside a URL without confusing the parser.
var safeCredComponent = rapid.StringMatching(`[a-zA-Z0-9]{1,16}`)

// TestNoCredentials_Property17_DBURLCredentialsNotInResolvedOutput verifies
// that when a randomly-generated EtcdValue with embedded credentials in its
// DBURL is processed through ParseDBURL and ExtractHostIP — the same code path
// as resolveViaEtcd — the resulting hostPort and dbName contain no credential
// material, and neither does a simulated ResolvedTarget built from those values.
//
// ≥100 iterations.
func TestNoCredentials_Property17_DBURLCredentialsNotInResolvedOutput(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		user := safeCredComponent.Draw(t, "user")
		pass := safeCredComponent.Draw(t, "pass")
		host := safeCredComponent.Draw(t, "host")
		port := rapid.IntRange(1, 65535).Draw(t, "port")
		db := safeCredComponent.Draw(t, "db")
		project := safeCredComponent.Draw(t, "project")
		env := safeCredComponent.Draw(t, "env")
		_ = project // project is internal etcd detail; workspace = env in this model
		service := rapid.StringMatching(`[a-zA-Z]{1,8}`).Draw(t, "service")
		serverID := rapid.StringMatching(`[0-9]{1,4}`).Draw(t, "serverID")

		// Construct an EtcdValue with credentials embedded in DBURL.
		dburl := fmt.Sprintf("%s:%s@%s:%d/%s", user, pass, host, port, db)
		addrIP := fmt.Sprintf("10.%d.%d.%d",
			rapid.IntRange(0, 255).Draw(t, "b"),
			rapid.IntRange(0, 255).Draw(t, "c"),
			rapid.IntRange(1, 254).Draw(t, "d"),
		)
		addr := fmt.Sprintf("%s:27000", addrIP)

		// Run through the same code path as resolveViaEtcd.
		hostPort, dbName, err := resolver.ParseDBURL(dburl)
		if err != nil {
			// A parse failure is acceptable here — it just means ParseDBURL
			// correctly rejected the input; no credential can leak.
			return
		}

		pprofIP, err := resolver.ExtractHostIP(addr)
		if err != nil {
			return
		}

		// Build a ResolvedTarget exactly as resolveViaEtcd does (no credential
		// fields exist on the struct, but verify the string fields are clean).
		target := resolver.ResolvedTarget{
			Workspace:     env,
			Service:       service,
			ServerID:      serverID,
			ServerIDNum:   0,
			Backend:       resolver.BackendEtcd,
			MongoHostPort: hostPort,
			MongoDBName:   dbName,
			PprofHostIP:   pprofIP,
			RedisAddr:     "",
		}

		// Collect all exported string field values from ResolvedTarget.
		v := reflect.ValueOf(target)
		typ := v.Type()
		plainCred := fmt.Sprintf("%s:%s@", user, pass)
		for i := 0; i < v.NumField(); i++ {
			field := typ.Field(i)
			if field.Type.Kind() != reflect.String {
				continue
			}
			fieldVal := v.Field(i).String()
			if strings.Contains(fieldVal, plainCred) {
				t.Fatalf(
					"ResolvedTarget.%s contains plain-text credential %q "+
						"(field value: %q, input dburl: %q)",
					field.Name, plainCred, fieldVal, dburl,
				)
			}
			// Also check that neither the raw password alone occurs as an
			// obvious credential embedding — but only when pass is long enough
			// to be distinguishable (short passwords like "a" or "1" would
			// cause false positives because they appear in port numbers, etc.).
			if len(pass) >= 6 && strings.Contains(fieldVal, pass) &&
				strings.Contains(fieldVal, user) {
				t.Fatalf(
					"ResolvedTarget.%s appears to contain both user %q and pass %q "+
						"— possible credential leak (field value: %q, input dburl: %q)",
					field.Name, user, pass, fieldVal, dburl,
				)
			}
		}
	})
}

// ---------------------------------------------------------------------------
// 4. JSON serialisation of []InstanceInfo contains no credential material
// ---------------------------------------------------------------------------

// TestNoCredentials_Property17_InstanceInfoJSONHasNoCredentials verifies that
// the JSON serialisation of a randomly-constructed []InstanceGroup slice — as
// returned by ListInstancesHandler — never contains credential substrings.
//
// The test constructs InstanceGroup entries from randomly generated service
// names and IDs, then marshals the slice to JSON and checks that no credential
// material appears in the output.
//
// ≥100 iterations.
func TestNoCredentials_Property17_InstanceInfoJSONHasNoCredentials(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		// Generate random credentials that could theoretically be leaked.
		user := safeCredComponent.Draw(t, "user")
		pass := safeCredComponent.Draw(t, "pass")
		host := safeCredComponent.Draw(t, "host")
		port := rapid.IntRange(1024, 65535).Draw(t, "port")
		db := safeCredComponent.Draw(t, "db")
		_ = host // not used in InstanceGroup, just generated to simulate back-end data

		// Simulate what the list path would return: grouped by service type,
		// only type name + numeric IDs, never DBURL or password.
		count := rapid.IntRange(0, 5).Draw(t, "count")
		groups := make([]resolver.InstanceGroup, count)
		for i := 0; i < count; i++ {
			svc := rapid.StringMatching(`[a-zA-Z]{1,8}`).Draw(t, fmt.Sprintf("svc%d", i))
			idCount := rapid.IntRange(1, 5).Draw(t, fmt.Sprintf("idCount%d", i))
			ids := make([]int, idCount)
			for j := 0; j < idCount; j++ {
				ids[j] = rapid.IntRange(1, 9999).Draw(t, fmt.Sprintf("id%d_%d", i, j))
			}
			groups[i] = resolver.InstanceGroup{Type: svc, IDs: ids}
		}

		data, err := json.Marshal(groups)
		if err != nil {
			t.Fatalf("json.Marshal([]InstanceGroup) failed: %v", err)
		}

		jsonStr := string(data)
		plainCred := fmt.Sprintf("%s:%s@", user, pass)
		dbURLSubstring := fmt.Sprintf("@%s:%d/%s", host, port, db)

		if strings.Contains(jsonStr, plainCred) {
			t.Fatalf(
				"JSON output of []InstanceGroup contains credential %q (json: %q)",
				plainCred, jsonStr,
			)
		}
		if strings.Contains(jsonStr, dbURLSubstring) {
			t.Fatalf(
				"JSON output of []InstanceGroup contains DBURL fragment %q (json: %q)",
				dbURLSubstring, jsonStr,
			)
		}
		// The JSON must only contain the two allowed field keys.
		for _, forbidden := range credentialFieldNames {
			if strings.Contains(strings.ToLower(jsonStr), `"`+forbidden+`"`) {
				t.Fatalf(
					"JSON output of []InstanceGroup contains forbidden field key %q (json: %q)",
					forbidden, jsonStr,
				)
			}
		}
	})
}

// ---------------------------------------------------------------------------
// 5. EtcdValue with varying credentials: output struct fields remain clean
// ---------------------------------------------------------------------------

// TestNoCredentials_Property17_EtcdValueCredentialsDiscarded verifies that
// for randomly constructed EtcdValue records containing varied embedded
// credentials, the output of the DBURL and hostIP parsing code paths never
// carries credential material — even when user/pass are long and distinctive.
//
// ≥100 iterations.
func TestNoCredentials_Property17_EtcdValueCredentialsDiscarded(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		// Use longer credentials to make false-positive overlap very unlikely.
		user := rapid.StringMatching(`[a-zA-Z]{4,12}`).Draw(t, "user")
		pass := rapid.StringMatching(`[a-zA-Z0-9]{8,16}`).Draw(t, "pass")
		host := rapid.StringMatching(`[a-z]{4,12}`).Draw(t, "host")
		port := rapid.IntRange(1024, 65535).Draw(t, "port")
		db := rapid.StringMatching(`[a-z]{4,12}`).Draw(t, "db")

		dburl := fmt.Sprintf("%s:%s@%s:%d/%s", user, pass, host, port, db)

		hostPort, dbName, err := resolver.ParseDBURL(dburl)
		if err != nil {
			// Any rejection is acceptable — no output to leak.
			return
		}

		// The plain-text password must not appear in either output field.
		for _, out := range []struct {
			name  string
			value string
		}{
			{"hostPort", hostPort},
			{"dbName", dbName},
		} {
			if strings.Contains(out.value, pass) {
				t.Fatalf(
					"ParseDBURL output field %q contains plain-text password %q "+
						"(hostPort=%q, dbName=%q, dburl=%q)",
					out.name, pass, hostPort, dbName, dburl,
				)
			}
			plainCred := fmt.Sprintf("%s:%s@", user, pass)
			if strings.Contains(out.value, plainCred) {
				t.Fatalf(
					"ParseDBURL output field %q contains credential substring %q "+
						"(value=%q, dburl=%q)",
					out.name, plainCred, out.value, dburl,
				)
			}
		}
	})
}
