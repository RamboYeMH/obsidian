// Package mcptools exposes the four MCP tool schemas and handlers.
package mcptools

// Tool name constants used when registering tools with the MCP server and when
// referencing tools in tests and integration code.
const (
	// ToolMongoQuery is the name of the read-only MongoDB query tool.
	ToolMongoQuery = "mongo_query"

	// ToolRedisQuery is the name of the read-only Redis query tool.
	ToolRedisQuery = "redis_query"

	// ToolPprofCollect is the name of the pprof collection tool.
	//
	// NOTE: the "profile" (CPU) and "trace" profiles are time-based and require
	// the caller to supply the "seconds" parameter (1..3600). Callers must
	// configure a sufficiently long HTTP/MCP client timeout for these profiles;
	// the collection will block for the full requested duration before returning.
	ToolPprofCollect = "pprof_collect"

	// ToolListInstances is the name of the instance enumeration tool.
	// It lists all known service instances for a given workspace and returns
	// each instance name in the "<service><id>" format that can be passed
	// directly to the other three tools.
	ToolListInstances = "list_instances"

	// ToolListWorkspaces is the name of the workspace enumeration tool.
	// It lists all known workspace identifiers so that callers do not need to
	// guess valid values for the workspace parameter of the other tools.
	ToolListWorkspaces = "list_workspaces"

	// ToolPprofSave is the name of the pprof save tool.
	// It collects a pprof profile and saves it to a temporary file on the server,
	// returning a download URL instead of base64-encoding the data into the MCP
	// response. This avoids polluting the LLM context with large binary blobs.
	ToolPprofSave = "pprof_save"
)

// ---------------------------------------------------------------------------
// Input structs
//
// Field descriptions use the `jsonschema:"..."` struct tag, which the MCP SDK
// reflects into the JSON Schema exposed via tools/list. Rich descriptions help
// LLM clients auto-route requests to the correct tool and supply valid inputs.
// ---------------------------------------------------------------------------

// MongoQueryInput is the typed input for the mongo_query tool.
//
// This tool is read-only: it only allows the methods
// find / findOne / count / countDocuments / estimatedDocumentCount /
// aggregate / distinct, with cursor chains limited to .sort / .skip / .limit.
// Server-side JavaScript ($where, $function, $accumulator) and aggregate write
// stages ($out, $merge) are rejected unconditionally.
type MongoQueryInput struct {
	// Workspace identifies the deployment environment, e.g. "h5dev-zaza",
	// "h5gold", "h5prod". It corresponds to the value in vars.workspace
	// (mongo model) or the environment key in the etcd config (etcd model).
	// Use list_instances to discover available workspaces and instances.
	Workspace string `json:"workspace" jsonschema:"部署环境标识，如 h5dev-zaza/h5gold/h5prod；可通过 list_instances 发现可用值"`

	// Instance names the target service instance in the format <service><id>,
	// e.g. "game1", "gate5", "cross1008". The service part is one or more ASCII
	// letters; the id part is one or more decimal digits.
	Instance string `json:"instance" jsonschema:"实例名 <service><id>，如 game1/gate5/cross1008"`

	// Query is a mongo-shell-style read-only query string.
	// Allowed methods: find, findOne, count, countDocuments,
	// estimatedDocumentCount, aggregate, distinct.
	// Cursor chain operators: .sort, .skip, .limit only.
	// Also supports the special query "show tables" (or "show collections").
	// Write operations, server-side JS, and aggregate write stages are rejected.
	Query string `json:"query" jsonschema:"mongo shell 风格只读查询，仅允许 find/findOne/count/countDocuments/estimatedDocumentCount/aggregate/distinct，链式仅 .sort/.skip/.limit；亦支持 'show tables'"`
}

// RedisQueryInput is the typed input for the redis_query tool.
//
// This tool is read-only: only commands on the allow-list are executed.
// Write commands (SET, DEL, EXPIRE, LPUSH, HSET, FLUSH*, …) are rejected with
// "仅允许只读命令". Dangerous commands (CONFIG, EVAL, FLUSHALL, FLUSHDB,
// SHUTDOWN, SCRIPT, DEBUG, …) are rejected with "命令被拒绝". Any other
// unlisted command is rejected with "不支持的命令".
type RedisQueryInput struct {
	// Workspace identifies the deployment environment, e.g. "h5dev-zaza".
	Workspace string `json:"workspace" jsonschema:"部署环境标识，如 h5dev-zaza/h5gold/h5prod"`

	// Instance names the target service instance in the format <service><id>,
	// e.g. "game1", "gate5", "cross1008".
	Instance string `json:"instance" jsonschema:"实例名 <service><id>，如 game1/gate5/cross1008"`

	// Command is the read-only Redis command to execute, e.g.
	// "GET key", "HGETALL myhash", "SCAN 0 MATCH p:* COUNT 100".
	// Only the following commands are allowed (case-insensitive):
	// GET, MGET, HGET, HGETALL, HMGET, HKEYS, HVALS, HLEN,
	// LRANGE, LLEN, LINDEX,
	// SMEMBERS, SISMEMBER, SCARD,
	// ZRANGE, ZRANGEBYSCORE, ZSCORE, ZCARD,
	// TYPE, TTL, PTTL, EXISTS, STRLEN,
	// SCAN, HSCAN, SSCAN, ZSCAN, GETRANGE, DBSIZE, INFO.
	Command string `json:"command" jsonschema:"只读 Redis 命令，如 'GET key'、'HGETALL h'、'SCAN 0 MATCH p:* COUNT 100'；仅允许只读命令白名单"`
}

// PprofCollectInput is the typed input for the pprof_collect tool.
//
// This tool fetches a Go pprof profile from the target instance via HTTP GET
// and returns the raw profile bytes as a base64-encoded blob. Exactly nine
// profile names are supported (see the Profile field). Only the "profile"
// (CPU) and "trace" profiles accept a Seconds parameter; all other profiles
// do not accept Seconds and will return an error if one is provided.
//
// ⚠ Time-based profiles: "profile" and "trace" block for the full Seconds
// duration before returning. Callers MUST configure a sufficiently long
// HTTP/MCP client timeout (at least Seconds + a few dozen seconds of overhead)
// or the connection will be torn down before data is returned.
type PprofCollectInput struct {
	// Workspace identifies the deployment environment, e.g. "h5dev-zaza".
	Workspace string `json:"workspace" jsonschema:"部署环境标识，如 h5dev-zaza/h5gold/h5prod"`

	// Instance names the target service instance in the format <service><id>,
	// e.g. "game1", "gate5", "cross1008".
	Instance string `json:"instance" jsonschema:"实例名 <service><id>，如 game1/gate5/cross1008"`

	// Profile is the name of the Go pprof profile to collect.
	// Allowed values (exactly): allocs, block, cmdline, goroutine, heap,
	// mutex, profile, threadcreate, trace.
	//   - "profile" collects a CPU profile (time-based, requires Seconds).
	//   - "trace"   collects an execution trace (time-based, requires Seconds).
	//   - All others are instantaneous snapshot profiles.
	// The cmdline profile response is automatically redacted before being
	// returned to remove sensitive flags and connection strings.
	Profile string `json:"profile" jsonschema:"profile 名称，取值 allocs|block|cmdline|goroutine|heap|mutex|profile|threadcreate|trace"`

	// Seconds specifies the collection duration in seconds (1..3600).
	// Only valid for the "profile" (CPU) and "trace" profiles.
	// Providing Seconds for any other profile is an error (not silently ignored).
	// Omit this field for all instantaneous snapshot profiles.
	//
	// IMPORTANT: because collection blocks for the full duration, the MCP/HTTP
	// client timeout must be configured to exceed this value by a comfortable
	// margin (e.g. Seconds + 30 s or more).
	Seconds *int `json:"seconds,omitempty" jsonschema:"采集时长(秒)，1..3600，仅 profile(CPU) 与 trace 接受；注意：基于时间的采集需客户端配置足够长的超时"`
}

// ListInstancesInput is the typed input for the list_instances tool.
//
// This tool enumerates all service instances registered for the given workspace
// and returns them as a JSON array. Each entry contains the instance name in
// the "<service><id>" format that can be passed directly to mongo_query,
// redis_query, or pprof_collect. No credentials, host addresses, or other
// internal topology details are ever included in the response.
//
// Optional filters:
//   - Service: if non-empty, only instances whose service type matches are returned.
//   - Instance: if non-empty, the response contains at most one entry (the named
//     instance) and the "exists" field indicates whether it was found.
type ListInstancesInput struct {
	// Workspace identifies the deployment environment, e.g. "h5dev-zaza",
	// "h5gold", "h5prod". This is the primary selector for all four tools.
	Workspace string `json:"workspace" jsonschema:"部署环境标识，如 h5dev-zaza/h5gold/h5prod"`

	// Service is an optional service-type filter, e.g. "game", "gate", "cross".
	// When set, only instances of that service type are returned.
	// Mutually exclusive with Instance: if Instance is set, Service is ignored.
	Service string `json:"service,omitempty" jsonschema:"可选，按服务类型过滤，如 game/gate/cross；与 instance 互斥"`

	// Instance is an optional instance name (e.g. "game1") to check for
	// existence. When set, the tool returns a single-element array if the
	// instance exists, or an empty array if it does not.
	// Takes precedence over Service when both are supplied.
	Instance string `json:"instance,omitempty" jsonschema:"可选，指定实例名（如 game1）以检查其是否存在；存在则返回单条结果，否则返回空数组"`
}

// ListWorkspacesInput is the typed input for the list_workspaces tool.
// The tool takes no parameters — it returns all available workspaces.
type ListWorkspacesInput struct{}

// PprofSaveInput is the typed input for the pprof_save tool.
//
// Identical to PprofCollectInput but the result is saved to a temporary file
// on the server and a download URL is returned instead of base64 data.
// This avoids writing large binary blobs into the LLM context window.
//
// ⚠ Time-based profiles: "profile" and "trace" block for the full Seconds
// duration. Configure client timeouts accordingly (Seconds + 30 s).
type PprofSaveInput struct {
	// Workspace identifies the deployment environment, e.g. "h5dev-zaza".
	Workspace string `json:"workspace" jsonschema:"部署环境标识，如 h5dev-zaza/h5gold/h5prod"`

	// Instance names the target service instance in the format <service><id>,
	// e.g. "game1", "gate5", "cross1008".
	Instance string `json:"instance" jsonschema:"实例名 <service><id>，如 game1/gate5/cross1008"`

	// Profile is the name of the Go pprof profile to collect.
	// Allowed values: allocs, block, cmdline, goroutine, heap, mutex, profile,
	// threadcreate, trace.
	Profile string `json:"profile" jsonschema:"profile 名称，取值 allocs|block|cmdline|goroutine|heap|mutex|profile|threadcreate|trace"`

	// Seconds specifies the collection duration in seconds (1..3600).
	// Only valid for "profile" (CPU) and "trace". Omit for snapshot profiles.
	Seconds *int `json:"seconds,omitempty" jsonschema:"采集时长(秒)，1..3600，仅 profile(CPU) 与 trace 接受"`
}
