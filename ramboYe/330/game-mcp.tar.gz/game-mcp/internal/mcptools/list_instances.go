package mcptools

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"

	"github.com/modelcontextprotocol/go-sdk/mcp"

	"game-mcp/internal/accesslog"
	"game-mcp/internal/gwerr"
	"game-mcp/internal/resolver"
)

// RegisterListInstances registers the list_instances tool on the given MCP server.
func RegisterListInstances(s *mcp.Server, r *resolver.Resolver) {
	mcp.AddTool(s, listInstancesTool(), ListInstancesHandler(r))
}

// ListInstancesHandler returns a ToolHandlerFor that handles the list_instances
// tool. It calls resolver.ListInstances for the given workspace, serialises the
// resulting []InstanceGroup to JSON, and returns it as MCP text content.
//
// The response is grouped by service type:
//
//	[{"type":"game","ids":[1,5,10]},{"type":"gate","ids":[1,2,3]}]
//
// Combine type + any id to form a valid instance name (e.g. "game1", "gate3")
// to pass to mongo_query / redis_query / pprof_collect.
//
// No credentials, host addresses, or internal topology are ever included in the
// response (requirements 8.6, 9.8).
//
// Any *gwerr.GatewayError is converted to a MCP tool error via
// GatewayError.ToMCPToolError(); any other unexpected error is wrapped in a
// generic GatewayError before conversion.
func ListInstancesHandler(r *resolver.Resolver) mcp.ToolHandlerFor[ListInstancesInput, any] {
	return func(
		ctx context.Context,
		req *mcp.CallToolRequest,
		input ListInstancesInput,
	) (*mcp.CallToolResult, any, error) {
		accesslog.SetTool(ctx, req.Params.Name)
		instances, err := r.ListInstances(ctx, input.Workspace, input.Service, input.Instance)
		if err != nil {
			recordReason(ctx, err)
			var gwErr *gwerr.GatewayError
			if errors.As(err, &gwErr) {
				res := gwErr.ToMCPToolError()
				recordToolError(ctx, res)
				return res, nil, nil
			}
			wrapped := gwerr.UpstreamWithCause(err,
				"list_instances 失败（workspace=%s）：%s",
				input.Workspace, err.Error())
			var wrappedGwErr *gwerr.GatewayError
			errors.As(wrapped, &wrappedGwErr)
			res := wrappedGwErr.ToMCPToolError()
			recordToolError(ctx, res)
			return res, nil, nil
		}

		data, jsonErr := json.Marshal(instances)
		if jsonErr != nil {
			wrapped := gwerr.UpstreamWithCause(jsonErr,
				"list_instances 结果序列化失败（workspace=%s）：%s",
				input.Workspace, jsonErr.Error())
			var wrappedGwErr *gwerr.GatewayError
			errors.As(wrapped, &wrappedGwErr)
			res := wrappedGwErr.ToMCPToolError()
			recordToolError(ctx, res)
			return res, nil, nil
		}

		return &mcp.CallToolResult{
			Content: []mcp.Content{&mcp.TextContent{Text: string(data)}},
		}, nil, nil
	}
}

// listInstancesTool returns the *mcp.Tool descriptor for the list_instances
// tool. It is used by the gateway assembler (cmd/gateway) to register the tool
// with the MCP server.
func listInstancesTool() *mcp.Tool {
	return &mcp.Tool{
		Name: ToolListInstances,
		Description: fmt.Sprintf(
			"%s: 列出指定 workspace 下已注册的服务实例，按服务类型分组返回。"+
				"结果格式：[{\"type\":\"game\",\"ids\":[1,5,10]},{\"type\":\"gate\",\"ids\":[1,2,3]}]；"+
				"将 type 与 ids 中的任意数字拼接即得可传入 %s / %s / %s 的实例名（如 game1、gate3）。"+
				"结果不含任何凭据、主机地址或内部拓扑信息。"+
				"可选参数 service 只返回该服务类型的分组；"+
				"可选参数 instance 检查指定实例是否存在（存在返回对应单条分组，不存在返回空数组）；"+
				"两者同时提供时 instance 优先。",
			ToolListInstances, ToolMongoQuery, ToolRedisQuery, ToolPprofCollect,
		),
	}
}
