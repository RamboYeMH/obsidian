// Package mcptools exposes the four MCP tool schemas and handlers:
// mongo_query, redis_query, pprof_collect, and list_instances.
package mcptools

import _ "github.com/modelcontextprotocol/go-sdk/mcp"
