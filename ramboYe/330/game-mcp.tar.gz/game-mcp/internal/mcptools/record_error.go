package mcptools

import (
	"context"
	"errors"
	"regexp"
	"strings"

	"github.com/modelcontextprotocol/go-sdk/mcp"

	"game-mcp/internal/accesslog"
	"game-mcp/internal/gwerr"
	"game-mcp/internal/secret"
)

// mongoCodeRe extracts the MongoDB server error code name that the driver wraps
// in parentheses, e.g. "(AuthenticationFailed) Authentication failed." → "AuthenticationFailed".
var mongoCodeRe = regexp.MustCompile(`\(([A-Za-z][A-Za-z0-9]+)\)`)

// reasonMaxLen caps the length of the fallback reason string written to the log.
const reasonMaxLen = 200

// recordToolError inspects an MCP tool result and, when it represents a tool
// failure (IsError=true), records the (already-masked, caller-safe) error text
// into the access-log fields via accesslog.SetError.
//
// MCP tool errors are returned to the client as HTTP 200 with IsError=true, so
// without this the access log would show status 200 for failed calls and could
// not distinguish success from failure. This helper makes every tool failure
// visible in the server-side access log with its reason.
//
// It is a no-op for nil results or successful results.
func recordToolError(ctx context.Context, result *mcp.CallToolResult) {
	if result == nil || !result.IsError {
		return
	}
	for _, c := range result.Content {
		if tc, ok := c.(*mcp.TextContent); ok && tc.Text != "" {
			accesslog.SetError(ctx, tc.Text)
			return
		}
	}
	// IsError but no text content: still record a generic marker.
	accesslog.SetError(ctx, "(tool error)")
}

// recordReason extracts a short underlying failure reason from err's cause and
// records it into the access log (server-side only) via accesslog.SetReason.
// This detail is never returned to the MCP caller; it exists purely to aid
// server-side debugging (e.g. distinguishing an auth failure from a timeout).
// It is a no-op when no meaningful underlying cause is present.
func recordReason(ctx context.Context, err error) {
	if reason := reasonFromError(err); reason != "" {
		accesslog.SetReason(ctx, reason)
	}
}

// reasonFromError derives a concise, credential-safe reason from the underlying
// cause of err:
//
//   - MongoDB driver errors expose a code name in parentheses (e.g.
//     "(AuthenticationFailed)") which is returned directly.
//   - Context deadline / timeout errors map to "timeout".
//   - Otherwise the masked cause string is returned, truncated to reasonMaxLen.
//
// When err carries no deeper cause beyond the caller-safe message (e.g. a pure
// validation error), an empty string is returned.
func reasonFromError(err error) string {
	if err == nil {
		return ""
	}

	// Resolve the underlying cause: for a GatewayError use its wrapped cause,
	// since the Msg is already the caller-safe (masked) message.
	cause := err
	var gwe *gwerr.GatewayError
	if errors.As(err, &gwe) {
		u := gwe.Unwrap()
		if u == nil {
			return "" // no deeper cause; nothing to add beyond the masked Msg
		}
		cause = u
	}

	msg := cause.Error()

	// MongoDB server error code, e.g. "(AuthenticationFailed)".
	if m := mongoCodeRe.FindStringSubmatch(msg); m != nil {
		return m[1]
	}

	// Common transport failures.
	switch {
	case strings.Contains(msg, "context deadline exceeded"),
		strings.Contains(msg, "i/o timeout"),
		strings.Contains(msg, "timeout"):
		return "timeout"
	case strings.Contains(msg, "connection refused"):
		return "connection refused"
	case strings.Contains(msg, "no such host"):
		return "no such host"
	}

	// Fallback: masked, truncated cause string (server-side only).
	masked := secret.MaskDBURL(msg)
	if len(masked) > reasonMaxLen {
		masked = masked[:reasonMaxLen] + "…"
	}
	return masked
}
