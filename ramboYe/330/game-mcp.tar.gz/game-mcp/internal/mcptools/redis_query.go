package mcptools

import (
	"context"
	"encoding/json"
	"errors"
	"strings"

	"github.com/modelcontextprotocol/go-sdk/mcp"

	"game-mcp/internal/accesslog"
	"game-mcp/internal/config"
	"game-mcp/internal/gwerr"
	"game-mcp/internal/redisq"
	"game-mcp/internal/resolver"
)

// RegisterRedisQuery registers the redis_query tool with the given MCP server.
// It requires a Resolver and the global Config (for Redis credential priority
// resolution).
func RegisterRedisQuery(srv *mcp.Server, res *resolver.Resolver, cfg *config.Config) {
	mcp.AddTool(srv, &mcp.Tool{
		Name:        ToolRedisQuery,
		Description: redisQueryDescription,
	}, makeRedisQueryHandler(res, cfg))
}

// redisQueryDescription is the human-readable tool description exposed via
// tools/list, satisfying requirement 10.2.
const redisQueryDescription = `只读 Redis 查询工具。根据 (workspace, instance) 解析目标实例，
并以只读 Redis 命令访问该实例的 Redis 服务。

仅允许以下命令（大小写不敏感）：
GET, MGET, HGET, HGETALL, HMGET, HKEYS, HVALS, HLEN, LRANGE, LLEN, LINDEX,
SMEMBERS, SISMEMBER, SCARD, ZRANGE, ZRANGEBYSCORE, ZSCORE, ZCARD,
TYPE, TTL, PTTL, EXISTS, STRLEN, SCAN, HSCAN, SSCAN, ZSCAN, GETRANGE, DBSIZE, INFO。

写命令（SET/DEL/EXPIRE/LPUSH/HSET 等）被拒绝。
危险命令（CONFIG/EVAL/FLUSHALL/FLUSHDB/SHUTDOWN/SCRIPT/DEBUG 等）被拒绝。
所有内部拓扑、主机地址与凭据均不暴露给调用方。`

// makeRedisQueryHandler returns a ToolHandlerFor[RedisQueryInput, any] that
// implements the full redis_query execution flow:
//
//  1. Validate instance name format via Resolver.
//  2. Resolve (project, env, instance) → ResolvedTarget.
//  3. Determine Redis address:
//     - BackendEtcd:           config.ResolveRedisCredentials(cfg, env, service).Addr
//     - BackendMongoFallback:  target.RedisAddr; empty/blank → validation error
//  4. Resolve credentials via config priority (service > env > global).
//  5. Get/create a Redis client from the ClientPool.
//  6. Execute the command via redisq.ExecCommand.
//  7. Serialize the result to JSON and return as MCP text content.
//  8. Any *gwerr.GatewayError → ToMCPToolError().
func makeRedisQueryHandler(
	res *resolver.Resolver,
	cfg *config.Config,
) mcp.ToolHandlerFor[RedisQueryInput, any] {
	pool := &redisq.ClientPool{}

	return func(
		ctx context.Context,
		req *mcp.CallToolRequest,
		input RedisQueryInput,
	) (*mcp.CallToolResult, any, error) {
		accesslog.SetTool(ctx, req.Params.Name)
		result, err := execRedisQuery(ctx, res, cfg, pool, input)
		if err != nil {
			recordReason(ctx, err)
			var gwErr *gwerr.GatewayError
			if errors.As(err, &gwErr) {
				res := gwErr.ToMCPToolError()
				recordToolError(ctx, res)
				return res, nil, nil
			}
			// Unexpected non-gateway error: wrap it as upstream.
			wrapped := gwerr.UpstreamWithCause(err, "redis_query 内部错误")
			var gwWrapped *gwerr.GatewayError
			errors.As(wrapped, &gwWrapped)
			res := gwWrapped.ToMCPToolError()
			recordToolError(ctx, res)
			return res, nil, nil
		}
		return result, nil, nil
	}
}

// execRedisQuery contains the core logic for the redis_query handler, separated
// for testability.
func execRedisQuery(
	ctx context.Context,
	res *resolver.Resolver,
	cfg *config.Config,
	pool *redisq.ClientPool,
	input RedisQueryInput,
) (*mcp.CallToolResult, error) {
	// Step 1 & 2: Resolve instance → ResolvedTarget.
	// ParseInstance is called internally by Resolve; validation errors bubble up.
	target, err := res.Resolve(ctx, input.Workspace, input.Instance)
	if err != nil {
		return nil, err
	}

	// Step 3: Determine Redis address.
	var redisAddr string
	switch target.Backend {
	case resolver.BackendEtcd:
		// etcd model: address comes from config (requirement 6.2).
		creds := config.ResolveRedisCredentials(cfg, input.Workspace, target.Service)
		redisAddr = creds.Addr
		if strings.TrimSpace(redisAddr) == "" {
			return nil, gwerr.Validation(
				"workspace %s service %s 未配置 Redis 地址（redis.envs.%s）",
				input.Workspace, target.Service, input.Workspace,
			)
		}
	case resolver.BackendMongoFallback:
		// mongo fallback model: address comes from vars.redis (requirement 6.3/6.5).
		redisAddr = strings.TrimSpace(target.RedisAddr)
		if redisAddr == "" {
			return nil, gwerr.Validation(
				"实例 %s 未配置 Redis 地址（vars.redis 缺失或为空）", input.Instance,
			)
		}
	default:
		return nil, gwerr.Validation("未知后端类型，无法解析 Redis 地址")
	}

	// Step 4: Resolve credentials via priority rules (service > env > global).
	creds := config.ResolveRedisCredentials(cfg, input.Workspace, target.Service)

	// 记录将使用的 Redis 账号到服务端访问日志（空账号表示无认证，记为 "none"）。
	accesslog.SetRedisUser(ctx, creds.User)

	// Step 5: Get or create a Redis client from the pool.
	cli, err := pool.Get(redisAddr, creds.User, creds.Pass)
	if err != nil {
		return nil, err
	}

	// Step 6: Execute the command (whitelist enforcement is inside ExecCommand).
	cmdResult, err := redisq.ExecCommand(ctx, cli, input.Command)
	if err != nil {
		return nil, err
	}

	// Step 7: Serialize result to JSON and return as MCP text content
	// (requirement 11.1).
	jsonBytes, jsonErr := json.Marshal(cmdResult)
	if jsonErr != nil {
		return nil, gwerr.UpstreamWithCause(jsonErr, "结果序列化失败")
	}

	return &mcp.CallToolResult{
		Content: []mcp.Content{
			&mcp.TextContent{Text: string(jsonBytes)},
		},
	}, nil
}
