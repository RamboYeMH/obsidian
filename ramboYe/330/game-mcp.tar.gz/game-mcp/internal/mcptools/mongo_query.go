package mcptools

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"os"
	"time"

	"github.com/modelcontextprotocol/go-sdk/mcp"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	mongooptions "go.mongodb.org/mongo-driver/mongo/options"
	"go.mongodb.org/mongo-driver/mongo/readpref"

	"game-mcp/internal/accesslog"
	"game-mcp/internal/config"
	"game-mcp/internal/gwerr"
	"game-mcp/internal/mongoq"
	"game-mcp/internal/resolver"
	"game-mcp/internal/secret"
)

const mongoConnectTimeout = 10 * time.Second

// mongoResultSizeWarn 是触发「结果较大」提示的序列化字节阈值。
// 超过该大小的结果可能被 MCP 客户端截断，因此附带一条提示建议收窄查询。
const mongoResultSizeWarn = 64 * 1024 // 64KB

// RegisterMongoQuery registers the mongo_query tool on the given MCP server.
// It wires the typed handler so the SDK handles schema generation and input
// unmarshaling automatically.
func RegisterMongoQuery(s *mcp.Server, res *resolver.Resolver, cfg *config.Config) {
	mcp.AddTool(s, &mcp.Tool{
		Name: ToolMongoQuery,
		Description: "Execute a read-only mongo-shell-style query against a resolved game-server instance. " +
			"Allowed methods: find, findOne, count, countDocuments, estimatedDocumentCount, aggregate, distinct. " +
			"Cursor chain operators: .sort, .skip, .limit. " +
			"Also supports 'show tables' / 'show collections'. " +
			"Write operations, server-side JS ($where/$function/$accumulator), and aggregate write stages ($out/$merge) are rejected unconditionally.",
	}, makeMongoQueryHandler(res, cfg))
}

// makeMongoQueryHandler returns the typed ToolHandlerFor used by RegisterMongoQuery.
func makeMongoQueryHandler(res *resolver.Resolver, cfg *config.Config) mcp.ToolHandlerFor[MongoQueryInput, any] {
	return func(ctx context.Context, req *mcp.CallToolRequest, input MongoQueryInput) (*mcp.CallToolResult, any, error) {
		accesslog.SetTool(ctx, req.Params.Name)
		result := HandleMongoQuery(ctx, res, cfg, &input)
		recordToolError(ctx, result)
		return result, nil, nil
	}
}

// HandleMongoQuery is the core handler for the mongo_query tool.
// It validates the input, resolves the target instance, connects to MongoDB
// using the read-only credential from cfg, runs the query, and returns the
// result as a JSON text content.
//
// All errors are mapped to MCP tool errors (IsError=true) via gwerr; the
// handler itself never returns a protocol-level error.
func HandleMongoQuery(
	ctx context.Context,
	res *resolver.Resolver,
	cfg *config.Config,
	input *MongoQueryInput,
) *mcp.CallToolResult {
	// ── 1. Validate instance name (ParseInstance inside Resolve will do this,
	//       but we call it explicitly so validation errors are returned before
	//       any network activity — requirement 11.3).
	if input.Instance == "" {
		return gwerr.Validation("instance 不能为空").(*gwerr.GatewayError).ToMCPToolError()
	}
	if input.Query == "" {
		return gwerr.Validation("query 不能为空").(*gwerr.GatewayError).ToMCPToolError()
	}

	// ── 2. Resolve the target instance.
	target, err := res.Resolve(ctx, input.Workspace, input.Instance)
	if err != nil {
		return toMCPToolError(ctx, err)
	}

	// 把解析出的目标库名写入服务端访问日志（仅文件、不回传调用方），便于调试。
	accesslog.SetDB(ctx, target.MongoDBName)

	// ── 3. Build MongoDB URI using mongo.readonly credentials + target host:port + dbName.
	//       Format: mongodb://user:pass@hostPort/dbName?authSource=admin
	//       The URI contains credentials only in memory; it is never logged or
	//       returned to the caller.
	cred := cfg.Mongo.Readonly
	mongoURI := buildTargetMongoURI(cred, target.MongoHostPort, target.MongoDBName, target.MongoReplicaSet)

	// 先按「打算使用的账号」记一次（即使后续连接/探测失败也有可审计记录）。
	// 连接成功后会用服务端 connectionStatus 返回的真实认证身份覆盖它。
	// 空账号表示匿名连接，SetMongoUser 内部会记为 "(anonymous)"。
	accesslog.SetMongoUser(ctx, cred.User)

	// ── 4. Connect to the target MongoDB with a 10 s timeout.
	connCtx, connCancel := context.WithTimeout(ctx, mongoConnectTimeout)
	defer connCancel()

	cli, err := mongo.Connect(connCtx, mongooptions.Client().ApplyURI(mongoURI))
	if err != nil {
		// 仅回传调用方已知的实例名，不泄露 host/port 或库名等内部拓扑；
		// 原始错误保留在 GatewayError 内部供服务端排障。
		return toMCPToolError(ctx,
			gwerr.ConnectionWithCause(err,
				"无法连接目标实例 %s 的 MongoDB", input.Instance),
		)
	}
	defer func() { _ = cli.Disconnect(context.Background()) }()

	// ── 5. Run the read-only query (maxLimit = 100).
	result, err := mongoq.RunQuery(ctx, cli, target.MongoDBName, input.Query, 100)
	if err != nil {
		return toMCPToolError(ctx, err)
	}

	// ── 5b. 探测本次读取实际落在的副本集节点角色。
	//        这是网关自身发起的 hello 命令，不经过用户 query 的白名单（调用方
	//        无法注入），使用与查询一致的 secondary 读偏好，结果反映真实读取路由。
	//        完整信息（含节点地址）只写入服务端日志，绝不返回给调用方，符合
	//        “不向调用方泄露 host/port 拓扑” 的安全策略；响应中只附带角色判定。
	role, node, probeErr := probeReplicaRole(ctx, cli, target.MongoHostPort)
	if probeErr != nil {
		fmt.Fprintf(os.Stderr,
			"mongo_query: 探测副本集角色失败（instance=%s db=%s）: %v\n",
			input.Instance, target.MongoDBName, probeErr)
	} else {
		// 角色判定与节点地址写入服务端访问日志（按天滚动的文件），不打控制台、
		// 也不返回调用方；调用方仅通过下方 roleHint 收到角色提示。
		accesslog.SetRole(ctx, role.Role, role.SetName, node)
	}

	// ── 5c. 探测服务端确认的真实认证身份（connectionStatus）。
	//        这是地面真相：反映该连接在服务端实际认证成的用户，而非我们打算用
	//        的账号。匿名连接时 authenticatedUsers 为空，记为 "(anonymous)"。
	//        同样是网关自身发起的命令，不经过用户 query 白名单；结果仅写服务端
	//        访问日志，不回传调用方。探测失败时保留先前记录的 intended 账号。
	if authUser, authErr := probeAuthUser(ctx, cli); authErr != nil {
		fmt.Fprintf(os.Stderr,
			"mongo_query: 探测认证身份失败（instance=%s db=%s）: %v\n",
			input.Instance, target.MongoDBName, authErr)
	} else {
		accesslog.SetMongoUser(ctx, authUser)
	}

	// ── 6. Serialize result to JSON and return as text content.
	jsonBytes, err := json.Marshal(result)
	if err != nil {
		return toMCPToolError(ctx,
			gwerr.UpstreamWithCause(err, "结果序列化失败"),
		)
	}

	return &mcp.CallToolResult{
		Content: buildMongoContent(jsonBytes),
	}
}

// replicaRole 描述 mongo_query 实际连接节点的副本集角色。
// 仅含角色判定，不携带 host/port 等拓扑细节，可安全返回给调用方。
type replicaRole struct {
	Role    string // "primary" | "secondary" | "standalone" | "unknown"
	SetName string // 副本集名（仅用于服务端日志）
}

// probeReplicaRole 通过 hello 命令探测当前读取实际落在的节点角色。
//
// 该调用由网关自身发起（非用户 query），因此不经过 mongoq 的只读白名单——
// 调用方无法借此注入任意命令。读偏好与查询保持一致（secondary），使探测结果
// 真实反映读取路由；对单实例（standalone / Single 拓扑）读偏好被驱动忽略，
// 不会因此报错。
//
// 返回值 node（hello.me，即节点 host:port）仅供服务端日志使用，调用方不可见。
func probeReplicaRole(ctx context.Context, cli *mongo.Client, hostPort string) (info replicaRole, node string, err error) {
	var raw bson.M
	err = cli.Database("admin").RunCommand(
		ctx,
		bson.D{{Key: "hello", Value: 1}},
		mongooptions.RunCmd().SetReadPreference(readpref.Secondary()),
	).Decode(&raw)
	if err != nil {
		return replicaRole{Role: "unknown"}, "", err
	}

	// MongoDB 5.0+ 使用 isWritablePrimary，旧版本回退到 ismaster。
	isPrimary, _ := raw["isWritablePrimary"].(bool)
	if !isPrimary {
		if v, ok := raw["ismaster"].(bool); ok {
			isPrimary = v
		}
	}
	isSecondary, _ := raw["secondary"].(bool)
	setName, _ := raw["setName"].(string)

	// hosts 是副本集可见成员列表；standalone 无此字段。成员数 ≤ 1 视为单节点
	// 部署（standalone 或单成员副本集），此时 readPreference 被驱动忽略，
	// 节点会自报 primary，但实际并无主从之分。
	hosts, _ := raw["hosts"].(bson.A)
	memberCount := len(hosts)

	role := "unknown"
	switch {
	case isSecondary:
		// 确实读到了从库——无论单节点还是多成员，都如实报告。
		role = "secondary"
	case isPrimary && (setName == "" || memberCount <= 1):
		// 单节点部署：standalone 或单成员副本集，无主从之分。
		role = "single"
	case isPrimary:
		// 多成员副本集却落在主库：通常意味着当前无可用从库，已回退到主库。
		role = "primary"
	}

	node, _ = raw["me"].(string)
	if node == "" {
		// 单实例（standalone）的 hello 回包不含 me 字段，用连接地址兜底。
		node = hostPort
	}
	return replicaRole{Role: role, SetName: setName}, node, nil
}

// probeAuthUser 通过 connectionStatus 命令探测服务端确认的真实认证身份。
//
// 返回 authInfo.authenticatedUsers 中的第一个用户，格式为 "user@db"
// （例如 "root@admin"）。当 authenticatedUsers 为空时表示匿名/无鉴权连接，
// 返回 "(anonymous)"。
//
// 该命令由网关自身发起（非用户 query），不经过 mongoq 只读白名单；
// connectionStatus 本身是只读诊断命令，不会改变任何状态。结果仅用于服务端
// 访问日志审计，不回传调用方。
func probeAuthUser(ctx context.Context, cli *mongo.Client) (string, error) {
	var raw bson.M
	err := cli.Database("admin").RunCommand(
		ctx,
		bson.D{{Key: "connectionStatus", Value: 1}},
	).Decode(&raw)
	if err != nil {
		return "", err
	}

	authInfo, _ := raw["authInfo"].(bson.M)
	users, _ := authInfo["authenticatedUsers"].(bson.A)
	if len(users) == 0 {
		// 服务端未认证任何用户 → 匿名连接。
		return "(anonymous)", nil
	}

	first, _ := users[0].(bson.M)
	user, _ := first["user"].(string)
	db, _ := first["db"].(string)
	if user == "" {
		return "(anonymous)", nil
	}
	if db != "" {
		return user + "@" + db, nil
	}
	return user, nil
}

// buildMongoContent 把序列化后的结果包装为 MCP 内容块。
// 当结果体积超过 mongoResultSizeWarn 时，追加一条提示，说明结果可能被客户端
// 截断，并建议使用投影、更精确的过滤条件或 .limit() 收窄返回量。
func buildMongoContent(jsonBytes []byte) []mcp.Content {
	content := []mcp.Content{&mcp.TextContent{Text: string(jsonBytes)}}
	if len(jsonBytes) > mongoResultSizeWarn {
		hint := fmt.Sprintf(
			"⚠️ 结果较大（约 %d KB / %d 字节），可能被客户端截断。"+
				"建议使用投影（projection）只取所需字段、添加更精确的过滤条件，或用 .limit() 缩小返回量。",
			len(jsonBytes)/1024, len(jsonBytes),
		)
		content = append(content, &mcp.TextContent{Text: hint})
	}
	return content
}

// buildTargetMongoURI builds a MongoDB connection URI for the target instance,
// injecting the supplied read-only credential. The hostPort parameter is a
// pre-validated "host:port" string (or a comma-joined replica-set seed list)
// extracted from the DBURL (credentials already stripped). The password is
// percent-encoded to handle special chars.
//
// When cred.User is empty the connection is treated as anonymous (no-auth):
// no "user:pass@" segment is emitted and authSource is omitted, producing a
// URI like "mongodb://hostPort/dbName?readPreference=secondary[&replicaSet=NAME]".
//
// Reads are pinned to a secondary (readPreference=secondary) so that querying a
// production instance never touches the primary. When replicaSet is non-empty
// it is included in the URI — this is required for the driver to recognise a
// replica-set topology and actually honour the read preference; without it a
// single seed is treated as a standalone (Single) topology and readPreference
// is ignored.
//
// Format (authenticated): mongodb://user:pass@hostPort/dbName?authSource=admin&readPreference=secondary[&replicaSet=NAME]
// Format (anonymous):      mongodb://hostPort/dbName?readPreference=secondary[&replicaSet=NAME]
func buildTargetMongoURI(cred config.Credential, hostPort, dbName, replicaSet string) string {
	var uri string
	if cred.User == "" {
		// 匿名连接：不注入凭据，也不指定 authSource。
		uri = fmt.Sprintf("mongodb://%s/%s?readPreference=secondary", hostPort, dbName)
	} else {
		encodedUser := url.PathEscape(cred.User)
		encodedPass := url.PathEscape(cred.Pass)
		uri = fmt.Sprintf("mongodb://%s:%s@%s/%s?authSource=admin&readPreference=secondary",
			encodedUser, encodedPass, hostPort, dbName)
	}
	if replicaSet != "" {
		uri += "&replicaSet=" + url.QueryEscape(replicaSet)
	}
	return uri
}

// toMCPToolError converts any error into a *mcp.CallToolResult with IsError=true.
// If the error is already a *gwerr.GatewayError, its ToMCPToolError() is used
// directly. Otherwise the raw error message is masked before being returned to
// prevent credential leakage via unexpected error paths.
//
// It also records a short underlying failure reason into the server-side access
// log (never returned to the caller) to aid debugging.
func toMCPToolError(ctx context.Context, err error) *mcp.CallToolResult {
	recordReason(ctx, err)
	var gwe *gwerr.GatewayError
	if errors.As(err, &gwe) {
		return gwe.ToMCPToolError()
	}
	// 未知 error：掩码后返回通用消息，原始内容不回传调用方
	masked := secret.MaskDBURL(err.Error())
	wrapped := gwerr.UpstreamWithCause(err, "内部错误: %s", masked)
	return wrapped.(*gwerr.GatewayError).ToMCPToolError()
}
