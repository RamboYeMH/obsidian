package mcptools

import (
	"reflect"
	"strings"
	"testing"
)

// meta_smoke_test.go verifies that tool metadata constants and input struct
// field tags carry the key words required by requirements 10.1–10.6.
//
// Tests use reflection on struct tags and string checks on the tool-name /
// tool-description constants defined in meta.go.

// ---------------------------------------------------------------------------
// Helper
// ---------------------------------------------------------------------------

// fieldTag returns the jsonschema tag value for the named field of the given
// struct value (or pointer-to-struct).  The test fails if the field is not
// found.
func fieldTag(t *testing.T, v any, fieldName string) string {
	t.Helper()
	rv := reflect.TypeOf(v)
	if rv.Kind() == reflect.Ptr {
		rv = rv.Elem()
	}
	if rv.Kind() != reflect.Struct {
		t.Fatalf("fieldTag: expected struct, got %v", rv.Kind())
	}
	f, ok := rv.FieldByName(fieldName)
	if !ok {
		t.Fatalf("fieldTag: field %q not found in %v", fieldName, rv)
	}
	return f.Tag.Get("jsonschema")
}

// assertContains fails the test if s does not contain sub.
func assertContains(t *testing.T, context, s, sub string) {
	t.Helper()
	if !strings.Contains(s, sub) {
		t.Errorf("%s: expected to contain %q\n  got: %q", context, sub, s)
	}
}

// ---------------------------------------------------------------------------
// 10.2 — Instance name format <service><id> appears in all four tools
// ---------------------------------------------------------------------------

func TestMetaSmoke_InstanceFormat_MongoQueryInput(t *testing.T) {
	tag := fieldTag(t, MongoQueryInput{}, "Instance")
	assertContains(t, "MongoQueryInput.Instance jsonschema", tag, "<service><id>")
}

func TestMetaSmoke_InstanceFormat_RedisQueryInput(t *testing.T) {
	tag := fieldTag(t, RedisQueryInput{}, "Instance")
	assertContains(t, "RedisQueryInput.Instance jsonschema", tag, "<service><id>")
}

func TestMetaSmoke_InstanceFormat_PprofCollectInput(t *testing.T) {
	tag := fieldTag(t, PprofCollectInput{}, "Instance")
	assertContains(t, "PprofCollectInput.Instance jsonschema", tag, "<service><id>")
}

// ---------------------------------------------------------------------------
// 10.3 — workspace selector described in all input structs
// ---------------------------------------------------------------------------

func TestMetaSmoke_Workspace_MongoQueryInput(t *testing.T) {
	tag := fieldTag(t, MongoQueryInput{}, "Workspace")
	if tag == "" {
		t.Errorf("MongoQueryInput.Workspace jsonschema tag is empty")
	}
}

func TestMetaSmoke_Workspace_RedisQueryInput(t *testing.T) {
	tag := fieldTag(t, RedisQueryInput{}, "Workspace")
	if tag == "" {
		t.Errorf("RedisQueryInput.Workspace jsonschema tag is empty")
	}
}

func TestMetaSmoke_Workspace_PprofCollectInput(t *testing.T) {
	tag := fieldTag(t, PprofCollectInput{}, "Workspace")
	if tag == "" {
		t.Errorf("PprofCollectInput.Workspace jsonschema tag is empty")
	}
}

func TestMetaSmoke_Workspace_ListInstancesInput(t *testing.T) {
	tag := fieldTag(t, ListInstancesInput{}, "Workspace")
	if tag == "" {
		t.Errorf("ListInstancesInput.Workspace jsonschema tag is empty")
	}
}

// ---------------------------------------------------------------------------
// 10.5 — mongo_query: readonly methods and cursor chains listed in Query tag
// ---------------------------------------------------------------------------

func TestMetaSmoke_MongoQuery_ReadonlyMethods(t *testing.T) {
	tag := fieldTag(t, MongoQueryInput{}, "Query")
	for _, method := range []string{
		"find",
		"findOne",
		"count",
		"aggregate",
		"distinct",
	} {
		assertContains(t, "MongoQueryInput.Query jsonschema", tag, method)
	}
}

func TestMetaSmoke_MongoQuery_CursorChains(t *testing.T) {
	tag := fieldTag(t, MongoQueryInput{}, "Query")
	for _, chain := range []string{".sort", ".skip", ".limit"} {
		assertContains(t, "MongoQueryInput.Query jsonschema", tag, chain)
	}
}

func TestMetaSmoke_MongoQuery_ReadonlyNature(t *testing.T) {
	// The Query field tag must mention "只读" (readonly in Chinese).
	tag := fieldTag(t, MongoQueryInput{}, "Query")
	assertContains(t, "MongoQueryInput.Query jsonschema", tag, "只读")
}

// ---------------------------------------------------------------------------
// 10.6 — redis_query: readonly commands mentioned
// ---------------------------------------------------------------------------

func TestMetaSmoke_RedisQuery_ReadonlyNature(t *testing.T) {
	tag := fieldTag(t, RedisQueryInput{}, "Command")
	assertContains(t, "RedisQueryInput.Command jsonschema", tag, "只读")
}

// ---------------------------------------------------------------------------
// 10.4 — pprof_collect: all 9 profile names and seconds range in Profile tag
// ---------------------------------------------------------------------------

func TestMetaSmoke_PprofCollect_ProfileNames(t *testing.T) {
	tag := fieldTag(t, PprofCollectInput{}, "Profile")
	for _, name := range []string{
		"allocs", "block", "cmdline", "goroutine", "heap",
		"mutex", "profile", "threadcreate", "trace",
	} {
		assertContains(t, "PprofCollectInput.Profile jsonschema", tag, name)
	}
}

func TestMetaSmoke_PprofCollect_SecondsRange(t *testing.T) {
	tag := fieldTag(t, PprofCollectInput{}, "Seconds")
	// Must mention the range 1..3600
	assertContains(t, "PprofCollectInput.Seconds jsonschema", tag, "1")
	assertContains(t, "PprofCollectInput.Seconds jsonschema", tag, "3600")
	// Must mention that only profile / trace accept seconds
	assertContains(t, "PprofCollectInput.Seconds jsonschema", tag, "profile")
	assertContains(t, "PprofCollectInput.Seconds jsonschema", tag, "trace")
}

func TestMetaSmoke_PprofCollect_TimeBasedClientTimeout(t *testing.T) {
	// The seconds tag must warn the caller about client-side timeout requirements.
	tag := fieldTag(t, PprofCollectInput{}, "Seconds")
	assertContains(t, "PprofCollectInput.Seconds jsonschema", tag, "超时")
}

// ---------------------------------------------------------------------------
// 10.2 — list_instances: instance name format <service><id> mentioned
// ---------------------------------------------------------------------------

func TestMetaSmoke_ListInstancesInput_InstanceFormat(t *testing.T) {
	tag := fieldTag(t, ListInstancesInput{}, "Workspace")
	if tag == "" {
		t.Errorf("ListInstancesInput.Workspace jsonschema tag must not be empty")
	}
}

// ---------------------------------------------------------------------------
// 10.6 — tool name constants are non-empty and carry the expected names
// ---------------------------------------------------------------------------

func TestMetaSmoke_ToolNameConstants(t *testing.T) {
	cases := map[string]string{
		"ToolMongoQuery":    ToolMongoQuery,
		"ToolRedisQuery":    ToolRedisQuery,
		"ToolPprofCollect":  ToolPprofCollect,
		"ToolListInstances": ToolListInstances,
	}
	for constName, value := range cases {
		if value == "" {
			t.Errorf("constant %s must not be empty", constName)
		}
	}
	if ToolMongoQuery != "mongo_query" {
		t.Errorf("ToolMongoQuery = %q, want %q", ToolMongoQuery, "mongo_query")
	}
	if ToolRedisQuery != "redis_query" {
		t.Errorf("ToolRedisQuery = %q, want %q", ToolRedisQuery, "redis_query")
	}
	if ToolPprofCollect != "pprof_collect" {
		t.Errorf("ToolPprofCollect = %q, want %q", ToolPprofCollect, "pprof_collect")
	}
	if ToolListInstances != "list_instances" {
		t.Errorf("ToolListInstances = %q, want %q", ToolListInstances, "list_instances")
	}
}

// ---------------------------------------------------------------------------
// 10.1 — readonly nature is documented via tool-constant comments / struct
//         doc comments; we verify indirectly that each tool has non-empty
//         name constant and that the struct types exist and compile.
// ---------------------------------------------------------------------------

func TestMetaSmoke_AllInputStructsExist(t *testing.T) {
	// This test will fail to compile (not just at runtime) if any of the
	// four input types disappear from meta.go, giving a build-time smoke signal.
	types := []any{
		MongoQueryInput{},
		RedisQueryInput{},
		PprofCollectInput{},
		ListInstancesInput{},
	}
	for i, typ := range types {
		rt := reflect.TypeOf(typ)
		if rt.Kind() != reflect.Struct {
			t.Errorf("types[%d] (%v) should be a struct", i, rt)
		}
	}
}
