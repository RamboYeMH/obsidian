package mcptools

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"

	"github.com/modelcontextprotocol/go-sdk/mcp"

	"game-mcp/internal/accesslog"
	"game-mcp/internal/gwerr"
	"game-mcp/internal/resolver"
)

// RegisterListWorkspaces registers the list_workspaces tool on the given MCP server.
func RegisterListWorkspaces(s *mcp.Server, r *resolver.Resolver) {
	mcp.AddTool(s, &mcp.Tool{
		Name: ToolListWorkspaces,
		Description: fmt.Sprintf(
			"%s: 列出所有可用的部署环境（workspace）。"+
				"返回的 workspace 值可直接用于 %s、%s、%s、%s 的 workspace 参数。"+
				"etcd 模型下来源于配置文件；mongo 模型下来源于管理库 processes 集合的去重 project 字段。"+
				"无需任何参数。",
			ToolListWorkspaces, ToolListInstances, ToolMongoQuery, ToolRedisQuery, ToolPprofCollect,
		),
	}, ListWorkspacesHandler(r))
}

// ListWorkspacesHandler returns the handler for the list_workspaces tool.
func ListWorkspacesHandler(r *resolver.Resolver) mcp.ToolHandlerFor[ListWorkspacesInput, any] {
	return func(
		ctx context.Context,
		req *mcp.CallToolRequest,
		_ ListWorkspacesInput,
	) (*mcp.CallToolResult, any, error) {
		accesslog.SetTool(ctx, req.Params.Name)
		workspaces, err := r.ListWorkspaces(ctx)
		if err != nil {
			recordReason(ctx, err)
			var gwErr *gwerr.GatewayError
			if errors.As(err, &gwErr) {
				res := gwErr.ToMCPToolError()
				recordToolError(ctx, res)
				return res, nil, nil
			}
			wrapped := gwerr.UpstreamWithCause(err, "list_workspaces 失败：%s", err.Error())
			var wrappedGwErr *gwerr.GatewayError
			errors.As(wrapped, &wrappedGwErr)
			res := wrappedGwErr.ToMCPToolError()
			recordToolError(ctx, res)
			return res, nil, nil
		}

		data, jsonErr := json.Marshal(workspaces)
		if jsonErr != nil {
			wrapped := gwerr.UpstreamWithCause(jsonErr, "list_workspaces 结果序列化失败：%s", jsonErr.Error())
			var wrappedGwErr *gwerr.GatewayError
			errors.As(wrapped, &wrappedGwErr)
			res := wrappedGwErr.ToMCPToolError()
			recordToolError(ctx, res)
			return res, nil, nil
		}

		return &mcp.CallToolResult{
			Content: []mcp.Content{&mcp.TextContent{Text: string(data)}},
		}, nil, nil
	}
}
