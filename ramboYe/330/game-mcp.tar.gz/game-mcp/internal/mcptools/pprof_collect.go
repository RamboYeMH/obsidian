package mcptools

import (
	"context"
	"errors"
	"strings"

	"github.com/modelcontextprotocol/go-sdk/mcp"

	"game-mcp/internal/accesslog"
	"game-mcp/internal/config"
	"game-mcp/internal/gwerr"
	"game-mcp/internal/pprofx"
	"game-mcp/internal/resolver"
)

// RegisterPprofCollect registers the pprof_collect tool on the given MCP server.
func RegisterPprofCollect(s *mcp.Server, r *resolver.Resolver, cfg *config.Config) {
	mcp.AddTool(s, &mcp.Tool{
		Name: ToolPprofCollect,
		Description: "采集目标实例的 Go pprof profile（CPU/内存/goroutine 等），" +
			"通过 HTTP GET /debug/pprof/<profile> 获取并以 base64 编码返回。" +
			"支持 9 种 profile：allocs/block/cmdline/goroutine/heap/mutex/profile/threadcreate/trace。" +
			"⚠ profile(CPU) 与 trace 为基于时间的采集，需提供 seconds(1..3600) 参数，" +
			"且客户端须配置足够长的超时（至少 seconds+30s）。cmdline 响应自动脱敏。",
	}, PprofCollectHandler(r, cfg))
}

// PprofCollectHandler returns a ToolHandlerFor that implements the
// pprof_collect MCP tool.
//
// The handler follows this flow (Requirements: 7.1, 7.6, 7.10, 7.11, 7.14,
// 7.17, 9.4, 9.5, 11.1, 11.2, 11.4):
//
//  1. Validate profile name and seconds via pprofx.ValidateInput.
//  2. Resolve instance → ResolvedTarget via resolver.Resolve.
//  3. Verify PprofHostIP is non-empty.
//  4. Derive port via pprofx.DerivePort.
//  5. Collect profile bytes via pprofx.Collect (HTTP GET only).
//  6. Prepare result via pprofx.PrepareProfileResult (cmdline redaction + base64).
//  7. Return base64 string as MCP text content.
//  8. Any *gwerr.GatewayError is mapped via .ToMCPToolError().
func PprofCollectHandler(
	r *resolver.Resolver,
	cfg *config.Config,
) func(context.Context, *mcp.CallToolRequest, PprofCollectInput) (*mcp.CallToolResult, any, error) {
	return func(
		ctx context.Context,
		req *mcp.CallToolRequest,
		input PprofCollectInput,
	) (*mcp.CallToolResult, any, error) {
		accesslog.SetTool(ctx, req.Params.Name)
		result := handlePprofCollect(ctx, r, cfg, input)
		recordToolError(ctx, result)
		return result, nil, nil
	}
}

// handlePprofCollect runs the pprof_collect flow and returns the MCP result
// (success or IsError). Separated from the handler wrapper so the wrapper can
// uniformly record tool errors into the access log.
func handlePprofCollect(
	ctx context.Context,
	r *resolver.Resolver,
	cfg *config.Config,
	input PprofCollectInput,
) *mcp.CallToolResult {
	// Step 1: Validate profile name and seconds before any network access.
	// Any validation failure returns immediately without touching the network
	// (Requirement 11.3, 9.5).
	if err := pprofx.ValidateInput(input.Profile, input.Seconds); err != nil {
		return toMCPToolErr(ctx, err)
	}

	// Step 2: Resolve instance → ResolvedTarget.
	target, err := r.Resolve(ctx, input.Workspace, input.Instance)
	if err != nil {
		return toMCPToolErr(ctx, err)
	}

	// Step 3: Verify PprofHostIP is present (Requirement 7.9).
	if strings.TrimSpace(target.PprofHostIP) == "" {
		gwErr := gwerr.Validation("无法解析目标主机 IP（实例 %s workspace=%s）",
			input.Instance, input.Workspace)
		return toMCPToolErr(ctx, gwErr)
	}

	// Step 4: Derive pprof port (Requirement 7.18–7.21).
	// DerivePort looks up service in cfg.PprofPortBases (after Validate has
	// merged built-in defaults) and computes base + serverIDNum.
	port, err := pprofx.DerivePort(cfg.PprofPortBases, target.Service, target.ServerIDNum)
	if err != nil {
		return toMCPToolErr(ctx, err)
	}

	// Step 5: Collect raw profile bytes via HTTP GET (Requirements 9.4, 9.5,
	// 7.10, 7.15, 7.17).
	data, err := pprofx.Collect(ctx, target.PprofHostIP, port, input.Profile, input.Seconds)
	if err != nil {
		return toMCPToolErr(ctx, err)
	}

	// Step 6: Handle cmdline redaction and base64 encoding (Requirements 7.11,
	// 7.12, 7.13, 7.14, 11.4).
	b64, err := pprofx.PrepareProfileResult(data, input.Profile)
	if err != nil {
		return toMCPToolErr(ctx, err)
	}

	// Step 7: Return the base64-encoded result as MCP text content
	// (Requirement 11.1).
	return &mcp.CallToolResult{
		Content: []mcp.Content{&mcp.TextContent{Text: b64}},
	}
}

// toMCPToolErr converts any error into a *mcp.CallToolResult with IsError=true.
// If the error wraps a *gwerr.GatewayError, its ToMCPToolError() is used so
// that the masked, caller-safe message is returned (Requirement 11.2, 11.4).
// For unexpected non-gateway errors, a generic message is returned without
// exposing the raw error content (which may contain internal addresses or credentials).
//
// It also records a short underlying failure reason into the server-side access
// log (never returned to the caller) to aid debugging.
func toMCPToolErr(ctx context.Context, err error) *mcp.CallToolResult {
	recordReason(ctx, err)
	var gwErr *gwerr.GatewayError
	if errors.As(err, &gwErr) {
		return gwErr.ToMCPToolError()
	}
	return &mcp.CallToolResult{
		Content: []mcp.Content{&mcp.TextContent{Text: "内部错误"}},
		IsError: true,
	}
}
