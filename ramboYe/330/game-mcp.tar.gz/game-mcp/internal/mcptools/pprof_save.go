package mcptools

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/modelcontextprotocol/go-sdk/mcp"

	"game-mcp/internal/accesslog"
	"game-mcp/internal/config"
	"game-mcp/internal/filestore"
	"game-mcp/internal/gwerr"
	"game-mcp/internal/pprofx"
	"game-mcp/internal/resolver"
)

// pprofSaveResult is the JSON payload returned to the caller.
type pprofSaveResult struct {
	Instance    string `json:"instance"`
	Profile     string `json:"profile"`
	SizeBytes   int    `json:"size_bytes"`
	DownloadURL string `json:"download_url"`
	Curl        string `json:"curl"`
	ExpiresIn   string `json:"expires_in"`
}

// RegisterPprofSave registers the pprof_save tool on the given MCP server.
func RegisterPprofSave(s *mcp.Server, r *resolver.Resolver, cfg *config.Config, fs *filestore.Store) {
	mcp.AddTool(s, &mcp.Tool{
		Name: ToolPprofSave,
		Description: "采集目标实例的 Go pprof profile 并保存到服务器临时文件，返回 download_url 和 curl 命令。" +
			"文件 5 分钟后自动过期。⚡ 优先使用此工具代替 pprof_collect——它不会将大量 base64 数据写入 LLM 上下文。" +
			"支持 9 种 profile：allocs/block/cmdline/goroutine/heap/mutex/profile(CPU)/threadcreate/trace。" +
			"profile(CPU) 与 trace 为基于时间的采集，需提供 seconds 参数并配置足够长的客户端超时。",
	}, PprofSaveHandler(r, cfg, fs))
}

// PprofSaveHandler returns the typed handler for the pprof_save tool.
//
// Flow:
//  1. Check server.public_url is configured.
//  2. Validate profile name and seconds via pprofx.ValidateInput.
//  3. Resolve instance → ResolvedTarget via resolver.Resolve.
//  4. Verify PprofHostIP is non-empty.
//  5. Derive port via pprofx.DerivePort.
//  6. Collect profile bytes via pprofx.Collect.
//  7. Redact cmdline if profile == "cmdline".
//  8. Save bytes to filestore; get UUID file ID.
//  9. Return JSON: {download_url, curl, expires_in}.
func PprofSaveHandler(
	r *resolver.Resolver,
	cfg *config.Config,
	fs *filestore.Store,
) func(context.Context, *mcp.CallToolRequest, PprofSaveInput) (*mcp.CallToolResult, any, error) {
	return func(
		ctx context.Context,
		req *mcp.CallToolRequest,
		input PprofSaveInput,
	) (*mcp.CallToolResult, any, error) {
		accesslog.SetTool(ctx, req.Params.Name)
		result := handlePprofSave(ctx, r, cfg, fs, input)
		recordToolError(ctx, result)
		return result, nil, nil
	}
}

func handlePprofSave(
	ctx context.Context,
	r *resolver.Resolver,
	cfg *config.Config,
	fs *filestore.Store,
	input PprofSaveInput,
) *mcp.CallToolResult {
	// Step 1: Require public_url — without it we cannot construct a usable URL.
	if strings.TrimSpace(cfg.Server.PublicURL) == "" {
		return toMCPToolErr(ctx, gwerr.Validation(
			"pprof_save 需要在 config.yaml 中配置 server.public_url（例如 http://1.2.3.4:8080）"))
	}

	// Step 2: Validate profile name and seconds.
	if err := pprofx.ValidateInput(input.Profile, input.Seconds); err != nil {
		return toMCPToolErr(ctx, err)
	}

	// Step 3: Resolve instance → ResolvedTarget.
	target, err := r.Resolve(ctx, input.Workspace, input.Instance)
	if err != nil {
		return toMCPToolErr(ctx, err)
	}

	// Step 4: Verify PprofHostIP is present.
	if strings.TrimSpace(target.PprofHostIP) == "" {
		return toMCPToolErr(ctx, gwerr.Validation(
			"无法解析目标主机 IP（实例 %s workspace=%s）", input.Instance, input.Workspace))
	}

	// Step 5: Derive pprof port.
	port, err := pprofx.DerivePort(cfg.PprofPortBases, target.Service, target.ServerIDNum)
	if err != nil {
		return toMCPToolErr(ctx, err)
	}

	// Step 6: Collect raw profile bytes via HTTP GET.
	data, err := pprofx.Collect(ctx, target.PprofHostIP, port, input.Profile, input.Seconds)
	if err != nil {
		return toMCPToolErr(ctx, err)
	}

	// Step 7: Redact cmdline before saving — never store unredacted cmdline on disk.
	if input.Profile == "cmdline" {
		data, err = pprofx.RedactCmdline(data)
		if err != nil {
			return toMCPToolErr(ctx, err)
		}
	}

	// Step 8: Save to filestore.
	id, saveErr := fs.Save(data)
	if saveErr != nil {
		// Log internally; do not surface filesystem details to caller.
		return toMCPToolErr(ctx, saveErr)
	}

	// Step 9: Build and return the download payload.
	base := strings.TrimRight(cfg.Server.PublicURL, "/")
	downloadURL := fmt.Sprintf("%s/files/%s.prof", base, id)
	filename := fmt.Sprintf("%s_%s.prof", input.Instance, input.Profile)

	res := pprofSaveResult{
		Instance:    input.Instance,
		Profile:     input.Profile,
		SizeBytes:   len(data),
		DownloadURL: downloadURL,
		Curl:        fmt.Sprintf("curl -o %s '%s'", filename, downloadURL),
		ExpiresIn:   "5m",
	}
	b, _ := json.Marshal(res)
	return &mcp.CallToolResult{
		Content: []mcp.Content{&mcp.TextContent{Text: string(b)}},
	}
}
