package resolver

import (
	"strconv"
	"strings"

	"game-mcp/internal/gwerr"
	"game-mcp/internal/secret"
)

// MongoConnInfo holds the topology information extracted from a DBURL that is
// needed to build a target connection URI. It carries no credentials
// (Requirement 4.8, 9.7).
//
//   - Hosts is one or more "host:port" seed entries with credentials stripped.
//   - DBName is the database name (query string removed).
//   - ReplicaSet is the value of the ?replicaSet= query parameter, or "" when
//     the DBURL does not specify a replica set.
type MongoConnInfo struct {
	Hosts      []string
	DBName     string
	ReplicaSet string
}

// ParseDBURL extracts the first host:port and the database name from a DBURL.
// It is a thin wrapper over ParseDBURLConn kept for backward compatibility with
// callers/tests that only need a single host:port.
//
// Embedded credentials (user:pass) are discarded and never appear in the
// return values (Requirement 4.8, 9.7).
//
// On any parse failure a gwerr.Validation error is returned.
func ParseDBURL(dburl string) (hostPort, dbName string, err error) {
	info, err := ParseDBURLConn(dburl)
	if err != nil {
		return "", "", err
	}
	return info.Hosts[0], info.DBName, nil
}

// ParseDBURLConn parses a DBURL into its topology components, preserving the
// full replica-set seed list and replica-set name so callers can route reads to
// secondaries. Supported forms:
//
//	user:pass@host:port/dbname[?...]                             (single host)
//	user:pass@h1:port1,h2:port2/dbname?replicaSet=NAME[&...]     (replica set seed list)
//	user:pass@ip1:port,ip2:port/dbname                          (legacy: port derived from last IP octet)
//
// The presence of a ?replicaSet= parameter distinguishes a standard replica-set
// seed list (hosts/ports preserved verbatim) from the legacy comma format
// (where the port is encoded in the last octet of the second host's IP).
//
// Embedded credentials are discarded and never appear in the result.
func ParseDBURLConn(dburl string) (MongoConnInfo, error) {
	var info MongoConnInfo

	// ── Strip credentials: everything before the first '@' ───────────────────
	atIdx := strings.Index(dburl, "@")
	if atIdx < 0 {
		return info, gwerr.Validation("DBURL 格式错误，缺少 @: %s", secret.MaskDBURL(dburl))
	}
	after := dburl[atIdx+1:] // host[:port][,...]/dbname[?...]

	// ── Split off the database name (path after '/') ──────────────────────────
	slashIdx := strings.Index(after, "/")
	if slashIdx < 0 {
		return info, gwerr.Validation("DBURL 格式错误，缺少数据库路径 /dbname: %s", secret.MaskDBURL(dburl))
	}
	hostSection := after[:slashIdx]
	dbPart := after[slashIdx+1:]

	// Separate the query string from the db name (e.g. "mydb?authSource=admin").
	var query string
	if qIdx := strings.Index(dbPart, "?"); qIdx >= 0 {
		query = dbPart[qIdx+1:]
		dbPart = dbPart[:qIdx]
	}
	if dbPart == "" {
		return info, gwerr.Validation("DBURL 格式错误，数据库名为空: %s", secret.MaskDBURL(dburl))
	}
	info.DBName = dbPart
	info.ReplicaSet = queryParam(query, "replicaSet")

	// ── Derive host(s) ────────────────────────────────────────────────────────
	if strings.Contains(hostSection, ",") {
		// A real replica-set seed list is signalled by the replicaSet parameter:
		// preserve every host:port entry verbatim.
		if info.ReplicaSet != "" {
			entries := strings.Split(hostSection, ",")
			hosts := make([]string, 0, len(entries))
			for _, e := range entries {
				hp, err := validateHostPort(strings.TrimSpace(e))
				if err != nil {
					return MongoConnInfo{}, err
				}
				hosts = append(hosts, hp)
			}
			info.Hosts = hosts
			return info, nil
		}

		// Legacy format: port encoded in the last octet of the second host's IP.
		//   192.168.50.1:20001,192.168.50.29:20001 → 192.168.50.1:20029
		parts := strings.SplitN(hostSection, ",", 2)
		second := parts[1]
		ipPart := strings.SplitN(second, ":", 2)[0]
		octets := strings.Split(ipPart, ".")
		last, e := strconv.Atoi(octets[len(octets)-1])
		if e != nil {
			return MongoConnInfo{}, gwerr.ValidationWithCause(e,
				"DBURL 旧格式端口解析失败（末段八位组非整数）: %s", hostSection)
		}
		firstIP := strings.SplitN(parts[0], ":", 2)[0]
		info.Hosts = []string{firstIP + ":" + strconv.Itoa(20000+last)}
		return info, nil
	}

	// Single host:port.
	hp, err := validateHostPort(hostSection)
	if err != nil {
		return MongoConnInfo{}, err
	}
	info.Hosts = []string{hp}
	return info, nil
}

// validateHostPort verifies that s is a "host:port" pair with a non-empty host
// and a numeric port, returning it unchanged on success.
func validateHostPort(s string) (string, error) {
	colonIdx := strings.LastIndex(s, ":")
	if colonIdx < 0 {
		return "", gwerr.Validation("DBURL 缺少端口 (host:port): %s", s)
	}
	host := s[:colonIdx]
	portStr := s[colonIdx+1:]
	if host == "" {
		return "", gwerr.Validation("DBURL 主机名为空: %s", s)
	}
	if _, e := strconv.Atoi(portStr); e != nil {
		return "", gwerr.ValidationWithCause(e, "DBURL 端口不是数字: %s", portStr)
	}
	return s, nil
}

// queryParam returns the value of the named parameter from a raw URL query
// string (e.g. "replicaSet=foo&authSource=admin"). It returns "" when the
// parameter is absent. Parsing is intentionally lightweight and does not
// percent-decode, which is sufficient for replica-set names.
func queryParam(query, name string) string {
	for _, kv := range strings.Split(query, "&") {
		if kv == "" {
			continue
		}
		eq := strings.IndexByte(kv, '=')
		if eq < 0 {
			continue
		}
		if kv[:eq] == name {
			return kv[eq+1:]
		}
	}
	return ""
}
