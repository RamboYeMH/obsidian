// Feature: pprof-redis-proxy, Property 14: pprof 主机 IP 提取
package resolver

// Validates: Requirements 7.7, 7.9

import (
	"fmt"
	"testing"

	"pgregory.net/rapid"
)

// TestExtractHostIP_Property14_ValidAddr verifies that for any well-formed
// "<ip>:<port>" address, ExtractHostIP returns exactly the IP part with no
// error, and the returned value equals the IP used to construct the address.
//
// ≥100 iterations.
func TestExtractHostIP_Property14_ValidAddr(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		// Generate a realistic IPv4 address component (dotted-quad).
		a := rapid.IntRange(1, 254).Draw(t, "a")
		b := rapid.IntRange(0, 255).Draw(t, "b")
		c := rapid.IntRange(0, 255).Draw(t, "c")
		d := rapid.IntRange(1, 254).Draw(t, "d")
		ip := fmt.Sprintf("%d.%d.%d.%d", a, b, c, d)
		port := rapid.IntRange(1, 65535).Draw(t, "port")
		addr := fmt.Sprintf("%s:%d", ip, port)

		gotIP, err := ExtractHostIP(addr)

		if err != nil {
			t.Fatalf("ExtractHostIP(%q) unexpected error: %v", addr, err)
		}
		if gotIP != ip {
			t.Fatalf("ExtractHostIP(%q) = %q, want %q", addr, gotIP, ip)
		}
	})
}

// TestExtractHostIP_Property14_EmptyAddrReturnsError verifies that an empty
// addr string always returns an error (requirement 7.7: addr 缺失 → 报错).
func TestExtractHostIP_Property14_EmptyAddrReturnsError(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		gotIP, err := ExtractHostIP("")

		if err == nil {
			t.Fatalf("ExtractHostIP(\"\") expected error, got nil (ip=%q)", gotIP)
		}
		if gotIP != "" {
			t.Fatalf("ExtractHostIP(\"\") expected empty IP on error, got %q", gotIP)
		}
	})
}

// TestExtractHostIP_Property14_MalformedAddrReturnsError verifies that
// addresses which cannot be split into a non-empty host and port always
// return an error and an empty IP string.
//
// Covers: no colon at all, colon-only (":"), empty-host forms (":8080"), and
// other strings that net.SplitHostPort would reject or that yield an empty host.
func TestExtractHostIP_Property14_MalformedAddrReturnsError(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		addr := drawMalformedAddr(t)

		gotIP, err := ExtractHostIP(addr)

		if err == nil {
			// An empty host triggers the "IP 部分为空" branch — still an error.
			// If the implementation somehow returned without error, the IP must
			// be non-empty; that would be a bug.
			t.Fatalf("ExtractHostIP(%q) expected error, got nil (ip=%q)", addr, gotIP)
		}
		if gotIP != "" {
			t.Fatalf("ExtractHostIP(%q) expected empty IP on error, got %q", addr, gotIP)
		}
	})
}

// TestExtractHostIP_Property14_HostNameAddr verifies that well-formed
// "<hostname>:<port>" strings (non-numeric hosts) also work correctly —
// ExtractHostIP must return the hostname part unchanged.
func TestExtractHostIP_Property14_HostNameAddr(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		hostname := rapid.StringMatching(`[a-zA-Z][a-zA-Z0-9\-]{0,19}`).Draw(t, "hostname")
		port := rapid.IntRange(1, 65535).Draw(t, "port")
		addr := fmt.Sprintf("%s:%d", hostname, port)

		gotHost, err := ExtractHostIP(addr)

		if err != nil {
			t.Fatalf("ExtractHostIP(%q) unexpected error: %v", addr, err)
		}
		if gotHost != hostname {
			t.Fatalf("ExtractHostIP(%q) = %q, want %q", addr, gotHost, hostname)
		}
	})
}

// drawMalformedAddr returns an addr string that should always cause
// ExtractHostIP to return an error — either because it cannot be parsed by
// net.SplitHostPort, or because the host portion is empty.
func drawMalformedAddr(t *rapid.T) string {
	strategy := rapid.IntRange(0, 3).Draw(t, "strategy")
	switch strategy {
	case 0:
		// No colon at all — net.SplitHostPort will error.
		return rapid.StringMatching(`[a-zA-Z0-9]{1,20}`).Draw(t, "no_colon")
	case 1:
		// Colon only, or ":port" — host is empty.
		port := rapid.IntRange(1, 65535).Draw(t, "port")
		return fmt.Sprintf(":%d", port)
	case 2:
		// Just a colon with nothing — both host and port are empty.
		return ":"
	default:
		// Multiple colons without brackets (not a valid IPv6 literal) —
		// e.g. "1.2.3.4:5:6" which net.SplitHostPort rejects.
		a := rapid.IntRange(1, 254).Draw(t, "a")
		b := rapid.IntRange(0, 255).Draw(t, "b")
		p1 := rapid.IntRange(1, 65535).Draw(t, "p1")
		p2 := rapid.IntRange(1, 65535).Draw(t, "p2")
		return fmt.Sprintf("%d.%d:%d:%d", a, b, p1, p2)
	}
}
