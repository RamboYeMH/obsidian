// Feature: pprof-redis-proxy, Property 3: DBURL 路由解析仅取 host:port 与库名
package resolver

// Validates: Requirements 4.8

import (
	"fmt"
	"strings"
	"testing"

	"pgregory.net/rapid"
)

// safeComponent generates a non-empty alphanumeric string (1-20 chars) that
// contains no ":", "@", "/", "?", "#", or whitespace — safe to embed in any
// position of a user:pass@host:port/db URL without confusing the parser.
var safeComponent = rapid.StringMatching(`[a-zA-Z0-9]{1,20}`)

// TestParseDBURL_Property3_NewFormat verifies Property 3 for new-format DBURLs
// of the form user:pass@host:port/db.
//
// For any randomly constructed new-format DBURL:
//   1. ParseDBURL must succeed (no error).
//   2. The returned hostPort must equal the constructed "host:port".
//   3. The returned dbName must equal the constructed db name.
//   4. Neither hostPort nor dbName contains the embedded credentials (user or pass).
//
// ≥100 iterations.
func TestParseDBURL_Property3_NewFormat(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		user := safeComponent.Draw(t, "user")
		pass := safeComponent.Draw(t, "pass")
		host := safeComponent.Draw(t, "host")
		port := rapid.IntRange(1, 65535).Draw(t, "port")
		db := safeComponent.Draw(t, "db")

		dburl := fmt.Sprintf("%s:%s@%s:%d/%s", user, pass, host, port, db)
		expectedHostPort := fmt.Sprintf("%s:%d", host, port)

		gotHostPort, gotDB, err := ParseDBURL(dburl)
		if err != nil {
			t.Fatalf("ParseDBURL(%q) returned unexpected error: %v", dburl, err)
		}

		// 3a: host:port must match construction.
		if gotHostPort != expectedHostPort {
			t.Fatalf("hostPort mismatch: got %q, want %q (input: %q)",
				gotHostPort, expectedHostPort, dburl)
		}

		// 3b: dbName must match construction.
		if gotDB != db {
			t.Fatalf("dbName mismatch: got %q, want %q (input: %q)",
				gotDB, db, dburl)
		}

		// 3c: credentials must NOT appear in either return value.
		for _, field := range []struct {
			label string
			value string
		}{
			{"hostPort", gotHostPort},
			{"dbName", gotDB},
		} {
			if strings.Contains(field.value, user+":"+pass) {
				t.Fatalf("%s contains plain-text credentials %q (input: %q)",
					field.label, user+":"+pass, dburl)
			}
			// pass alone might coincidentally equal the host or port digit;
			// the important invariant is that the combined "user:pass@" token
			// never leaks.
			plainCred := fmt.Sprintf("%s:%s@", user, pass)
			if strings.Contains(field.value, plainCred) {
				t.Fatalf("%s contains credential substring %q (input: %q)",
					field.label, plainCred, dburl)
			}
		}
	})
}

// TestParseDBURL_Property3_QueryStringStripped verifies that query parameters
// appended to the db name are stripped, while host:port and db are still correct.
func TestParseDBURL_Property3_QueryStringStripped(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		user := safeComponent.Draw(t, "user")
		pass := safeComponent.Draw(t, "pass")
		host := safeComponent.Draw(t, "host")
		port := rapid.IntRange(1, 65535).Draw(t, "port")
		db := safeComponent.Draw(t, "db")
		queryKey := safeComponent.Draw(t, "queryKey")
		queryVal := safeComponent.Draw(t, "queryVal")

		dburl := fmt.Sprintf("%s:%s@%s:%d/%s?%s=%s", user, pass, host, port, db, queryKey, queryVal)
		expectedHostPort := fmt.Sprintf("%s:%d", host, port)

		gotHostPort, gotDB, err := ParseDBURL(dburl)
		if err != nil {
			t.Fatalf("ParseDBURL(%q) returned unexpected error: %v", dburl, err)
		}

		if gotHostPort != expectedHostPort {
			t.Fatalf("hostPort mismatch: got %q, want %q (input: %q)",
				gotHostPort, expectedHostPort, dburl)
		}

		// The db name must not include the query string.
		if gotDB != db {
			t.Fatalf("dbName mismatch: got %q, want %q (query string must be stripped, input: %q)",
				gotDB, db, dburl)
		}

		// Credentials must not appear in either return value.
		plainCred := fmt.Sprintf("%s:%s@", user, pass)
		if strings.Contains(gotHostPort, plainCred) || strings.Contains(gotDB, plainCred) {
			t.Fatalf("credentials leaked in output (hostPort=%q, dbName=%q, input: %q)",
				gotHostPort, gotDB, dburl)
		}
	})
}

// TestParseDBURL_Property3_CredentialsNeverInOutput is a focused invariant:
// for any valid new-format DBURL the concatenation of both return values
// must never contain the raw "user:pass@" substring.
func TestParseDBURL_Property3_CredentialsNeverInOutput(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		user := safeComponent.Draw(t, "user")
		pass := safeComponent.Draw(t, "pass")
		host := safeComponent.Draw(t, "host")
		port := rapid.IntRange(1, 65535).Draw(t, "port")
		db := safeComponent.Draw(t, "db")

		dburl := fmt.Sprintf("%s:%s@%s:%d/%s", user, pass, host, port, db)

		gotHostPort, gotDB, err := ParseDBURL(dburl)
		if err != nil {
			t.Fatalf("ParseDBURL(%q) returned unexpected error: %v", dburl, err)
		}

		combined := gotHostPort + gotDB
		plainCred := fmt.Sprintf("%s:%s@", user, pass)
		if strings.Contains(combined, plainCred) {
			t.Fatalf("combined output %q contains credential %q (input: %q)",
				combined, plainCred, dburl)
		}
	})
}
