package resolver

import (
	"fmt"
	"strings"

	"game-mcp/internal/gwerr"
)

// BuildEtcdKey constructs the full etcd key for a given instance.
//
// When namespace is true (the common case), the key is:
//
//	{env}/{project}/gs/{service}/{serverid}
//
// When namespace is false (legacy deployments without env prefix), the key is:
//
//	{project}/gs/{service}/{serverid}
//
// Example (namespace=true):  "h5dev2/h5/gs/actv/1"
// Example (namespace=false): "ice/gs/actv/1"
func BuildEtcdKey(project, env, service, serverid string, namespace bool) string {
	if namespace {
		return fmt.Sprintf("%s/%s/gs/%s/%s", env, project, service, serverid)
	}
	return fmt.Sprintf("%s/gs/%s/%s", project, service, serverid)
}

// BuildEtcdPrefix constructs the etcd key prefix used to enumerate all instances
// under a (project, env) pair.
//
// When namespace is true:  {env}/{project}/gs/
// When namespace is false: {project}/gs/
func BuildEtcdPrefix(project, env string, namespace bool) string {
	if namespace {
		return fmt.Sprintf("%s/%s/gs/", env, project)
	}
	return fmt.Sprintf("%s/gs/", project)
}

// InstanceFromEtcdKey recovers the instance name from a full etcd key given its
// prefix.
//
// It strips the prefix from key to obtain the suffix, then splits the suffix by
// "/" expecting exactly two segments: service and serverid. The returned instance
// name is service+serverid (e.g. "actv1").
//
// Returns a validation error if:
//   - the key does not start with prefix, or
//   - the suffix is not of the form "service/serverid" (exactly two non-empty
//     segments separated by a single "/").
func InstanceFromEtcdKey(prefix, key string) (instanceName string, err error) {
	if !strings.HasPrefix(key, prefix) {
		return "", gwerr.Validation(
			"etcd key %q 不以期望前缀 %q 开头", key, prefix)
	}

	suffix := key[len(prefix):]

	// suffix must be exactly "service/serverid" — two non-empty parts
	parts := strings.SplitN(suffix, "/", 3)
	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
		return "", gwerr.Validation(
			"etcd key %q 的后缀 %q 格式不符（期望 service/serverid）", key, suffix)
	}

	service := parts[0]
	serverid := parts[1]
	return service + serverid, nil
}
