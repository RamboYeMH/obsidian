package resolver

// Feature: pprof-redis-proxy, Property 1: 实例名解析往返与拒绝
// Validates: Requirements 4.1, 4.2

import (
	"strconv"
	"strings"
	"testing"

	"pgregory.net/rapid"
)

// nonAlnumRunes contains printable non-alphanumeric ASCII characters suitable for
// injecting into instance names to make them invalid.
var nonAlnumRunes = []rune{
	'-', '_', '.', '/', '\\', ' ', '!', '@', '#', '$', '%', '^', '&', '*',
	'(', ')', '+', '=', '[', ']', '{', '}', '|', ';', ':', '\'', '"', ',',
	'<', '>', '?', '~', '`',
}

// TestParseInstance_ValidRoundTrip verifies Property 1 (valid path):
// For any name composed of ASCII letters followed by decimal digits,
// ParseInstance returns service==letters (exact casing) and serverid==digits.
func TestParseInstance_ValidRoundTrip(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		service := rapid.StringMatching(`[A-Za-z]+`).Draw(t, "service")
		// Use a bounded integer for the server ID to stay within int range (realistic serverids
		// are small integers used as port offsets, e.g. game421 -> port 27421).
		n := rapid.IntRange(1, 100000).Draw(t, "serverid_num")
		serverID := strconv.Itoa(n)
		name := service + serverID

		gotService, gotServerID, gotNum, err := ParseInstance(name)

		// Must succeed (requirement 4.1)
		if err != nil {
			t.Fatalf("ParseInstance(%q) unexpected error: %v", name, err)
		}
		// service must be preserved verbatim including original casing (requirement 4.1)
		if gotService != service {
			t.Fatalf("service casing not preserved: want %q got %q", service, gotService)
		}
		// serverID string must match digits exactly
		if gotServerID != serverID {
			t.Fatalf("serverID mismatch: want %q got %q", serverID, gotServerID)
		}
		// num must equal the integer value of serverID
		if gotNum != n {
			t.Fatalf("num mismatch: want %d got %d (serverID=%q)", n, gotNum, serverID)
		}
		// Outputs must be non-empty
		if gotService == "" || gotServerID == "" {
			t.Fatalf("unexpected empty output: service=%q serverID=%q", gotService, gotServerID)
		}
	})
}

// TestParseInstance_InvalidRejected verifies Property 1 (rejection path):
// For any string that does NOT match ^[A-Za-z]+\d+$, ParseInstance returns
// a validation error and zero values for all outputs (requirement 4.2).
func TestParseInstance_InvalidRejected(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		name := drawInvalidName(t)

		gotService, gotServerID, gotNum, err := ParseInstance(name)

		// Must return an error (requirement 4.2)
		if err == nil {
			t.Fatalf("ParseInstance(%q) expected error, got nil (service=%q serverID=%q num=%d)",
				name, gotService, gotServerID, gotNum)
		}
		// All outputs must be zero values (requirement 4.2: "不产出目标")
		if gotService != "" {
			t.Fatalf("expected empty service on error for %q, got %q", name, gotService)
		}
		if gotServerID != "" {
			t.Fatalf("expected empty serverID on error for %q, got %q", name, gotServerID)
		}
		if gotNum != 0 {
			t.Fatalf("expected zero num on error for %q, got %d", name, gotNum)
		}
	})
}

// TestParseInstance_CasingPreserved verifies that service-type letter casing is
// preserved verbatim across many mixed-case combinations (requirement 4.1).
func TestParseInstance_CasingPreserved(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		service := rapid.StringMatching(`[A-Za-z]+`).Draw(t, "service")
		n := rapid.IntRange(1, 100000).Draw(t, "serverid_num")
		serverID := strconv.Itoa(n)
		name := service + serverID

		gotService, _, _, err := ParseInstance(name)
		if err != nil {
			t.Fatalf("unexpected error for valid name %q: %v", name, err)
		}
		if gotService != service {
			t.Fatalf("casing not preserved: want %q got %q", service, gotService)
		}
		// Sanity check: lower-casing both should still match
		if strings.ToLower(gotService) != strings.ToLower(service) {
			t.Fatalf("unexpected casing transformation: %q -> %q", service, gotService)
		}
	})
}

// drawInvalidName returns a string that is guaranteed NOT to match ^[A-Za-z]+\d+$.
// It covers: empty string, digits-only, letters-only, names with non-alnum characters,
// and names where digits precede letters.
func drawInvalidName(t *rapid.T) string {
	strategy := rapid.IntRange(0, 4).Draw(t, "strategy")
	switch strategy {
	case 0:
		// Empty string is always invalid
		return ""
	case 1:
		// Digits only — no leading letters
		return rapid.StringMatching(`[0-9]+`).Draw(t, "digits_only")
	case 2:
		// Letters only — no trailing digits
		return rapid.StringMatching(`[A-Za-z]+`).Draw(t, "letters_only")
	case 3:
		// Inject a non-alnum character somewhere into an otherwise alnum string
		base := rapid.StringMatching(`[A-Za-z0-9]+`).Draw(t, "alnum_base")
		badRune := rapid.SampledFrom(nonAlnumRunes).Draw(t, "bad_rune")
		pos := rapid.IntRange(0, len(base)).Draw(t, "inject_pos")
		return base[:pos] + string(badRune) + base[pos:]
	default:
		// Digits before letters (e.g. "123game") — invalid because regex requires letters first
		digits := rapid.StringMatching(`[0-9]+`).Draw(t, "leading_digits")
		letters := rapid.StringMatching(`[A-Za-z]+`).Draw(t, "trailing_letters")
		return digits + letters
	}
}
