// Package resolver implements the etcd-first dual-backend service resolver
// that translates (project, env, instance) into concrete backend targets.
package resolver

import _ "go.etcd.io/etcd/client/v3"
