// Feature: pprof-redis-proxy, Property 4: 库名前缀规则
package resolver

import (
	"testing"

	"pgregory.net/rapid"
)

// TestApplyDBNameGroup_Property4 verifies the db_name_group prefix rule:
//   - dbNameGroup=true  → env + "_" + db
//   - dbNameGroup=false → db (unchanged)
//
// Validates: Requirements 4.9
func TestApplyDBNameGroup_Property4(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		env := rapid.StringMatching(`[a-zA-Z0-9_-]{1,20}`).Draw(t, "env")
		db := rapid.StringMatching(`[a-zA-Z0-9_-]{1,30}`).Draw(t, "db")
		flag := rapid.Bool().Draw(t, "dbNameGroup")

		result := ApplyDBNameGroup(env, db, flag)

		if flag {
			expected := env + "_" + db
			if result != expected {
				t.Fatalf("dbNameGroup=true: got %q, want %q", result, expected)
			}
		} else {
			if result != db {
				t.Fatalf("dbNameGroup=false: got %q, want %q (unchanged)", result, db)
			}
		}
	})
}
