package resolver

import (
	"context"
	"encoding/json"
	"fmt"
	"net/url"
	"strings"
	"sync"
	"time"

	clientv3 "go.etcd.io/etcd/client/v3"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"

	"game-mcp/internal/config"
	"game-mcp/internal/gwerr"
	"game-mcp/internal/secret"
)

// Backend identifies which resolution path was used.
type Backend int

const (
	// BackendEtcd means the instance was resolved via etcd.
	BackendEtcd Backend = iota
	// BackendMongoFallback means the instance was resolved via mongo autoops.
	BackendMongoFallback
)

// ResolvedTarget is the unified output of the Service Resolver. It contains
// all routing information needed by the MCP tool handlers. It intentionally
// carries no credentials (requirement 4.14, 9.1, 9.8).
type ResolvedTarget struct {
	// Workspace is the caller-supplied workspace identifier.
	// etcd model:          the env key in cfg.Etcd[project][env] (e.g. "h5dev2")
	// mongo fallback model: the value of processes.project (e.g. "h5dev-zaza")
	Workspace string
	// etcdProject is the internal project key used for etcd routing only.
	// It is intentionally unexported to prevent leaking internal topology.
	etcdProject string
	Service  string  // service-type, original casing preserved
	ServerID string  // serverid as decimal string
	ServerIDNum int  // serverid as integer (for port derivation)
	Backend  Backend

	// Mongo routing (no credentials — caller injects mongo.readonly at connect time)
	MongoHostPort string // host:port (comma-joined seed list for replica sets), credentials stripped
	MongoDBName   string // already has {env}_ prefix applied when db_name_group=true
	// MongoReplicaSet is the replica-set name parsed from the DBURL (empty for
	// standalone deployments). It is required so the driver recognises a
	// replica-set topology and can honour readPreference=secondary.
	MongoReplicaSet string

	// pprof
	PprofHostIP string // etcd: IP from Addr; mongo fallback: hosts.lanip

	// Redis address (credentials are resolved separately via config priority)
	RedisAddr string // etcd model: from config; mongo fallback: vars.redis
}

// instanceInfo is an internal list entry used while collecting raw results from
// the etcd / mongo backends before grouping. It deliberately contains no
// credentials (requirement 8.6, 9.8).
type instanceInfo struct {
	service  string // service type, original casing preserved
	serverID int    // numeric server id
}

// InstanceGroup is a single entry in the list returned by ListInstances.
// Instances are grouped by service type so that callers (including LLM agents)
// can see at a glance which types exist and which IDs are available, without
// needing to parse individual "<service><id>" strings.
// Combine Type + any element of IDs to form a valid instance name, e.g. "game1".
// No credentials, host addresses, or internal topology are included
// (requirements 8.6, 9.8).
type InstanceGroup struct {
	Type string `json:"type"` // service type, e.g. "game", "gate", "cross"
	IDs  []int  `json:"ids"`  // sorted server IDs belonging to this service type
}

// EtcdValue is the JSON structure stored as the etcd value for each instance.
type EtcdValue struct {
	Name   string `json:"Name"`
	Addr   string `json:"Addr"`   // <ip>:<port>; pprof IP comes from IP part
	Label  string `json:"Label"`
	Weight int    `json:"Weight"`
	DBURL  string `json:"DBURL"`  // credentials discarded; only host:port+db used
}

// connectionTimeout is applied uniformly to etcd/mongo dial and query operations.
const connectionTimeout = 10 * time.Second

// Resolver is the etcd-first dual-backend service resolver.
// It pools etcd clients per (project+env) and holds a single autoops mongo client.
type Resolver struct {
	cfg *config.Config

	// etcd client pool: key is "<project>\x00<env>" → *clientv3.Client
	etcdClients sync.Map

	// autoops mongo client (lazy-initialised, process-level singleton)
	autoopsMu     sync.Mutex
	autoopsClient *mongo.Client
}

// NewResolver creates a new Resolver with the supplied configuration.
// The resolver does not eagerly connect to any backend; connections are
// established on first use and then pooled.
func NewResolver(cfg *config.Config) (*Resolver, error) {
	if cfg == nil {
		return nil, fmt.Errorf("resolver: config must not be nil")
	}
	return &Resolver{cfg: cfg}, nil
}

// ─────────────────────────────────────────────────────────────────────────────
// Resolve
// ─────────────────────────────────────────────────────────────────────────────

// Resolve translates (workspace, instance) into a ResolvedTarget.
//
// Decision tree:
//  1. Parse the instance name into service + serverid.
//  2. Search cfg.Etcd for any project whose env key equals workspace → etcd path.
//  3. Otherwise → mongo autoops fallback path (workspace == processes.project).
func (r *Resolver) Resolve(ctx context.Context, workspace, instance string) (*ResolvedTarget, error) {
	// Step 1: parse instance name
	service, serverID, serverIDNum, err := ParseInstance(instance)
	if err != nil {
		return nil, err
	}

	// Step 2: choose backend
	if project, cluster, ok := r.findEtcdCluster(workspace); ok {
		return r.resolveViaEtcd(ctx, workspace, project, service, serverID, serverIDNum, cluster)
	}
	return r.resolveViaMongo(ctx, workspace, service, serverID, serverIDNum)
}

// ─────────────────────────────────────────────────────────────────────────────
// ListInstances
// ─────────────────────────────────────────────────────────────────────────────

// ListInstances returns available instances for the given workspace, grouped by
// service type.  Results contain no credentials.
//
// Optional filters:
//   - service: when non-empty only the group matching that service type is returned.
//   - instance: when non-empty (<service><id> format) the response contains at
//     most one group with one ID (the named instance) if it exists, or an empty
//     slice if it does not. Takes precedence over service when both are supplied.
func (r *Resolver) ListInstances(ctx context.Context, workspace, service, instance string) ([]InstanceGroup, error) {
	var (
		raw []instanceInfo
		err error
	)
	if project, cluster, ok := r.findEtcdCluster(workspace); ok {
		raw, err = r.listViaEtcd(ctx, workspace, project, cluster)
	} else {
		raw, err = r.listViaMongo(ctx, workspace)
	}
	if err != nil {
		return nil, err
	}

	// Apply filters before grouping.
	if instance != "" {
		svc, _, num, parseErr := ParseInstance(instance)
		if parseErr != nil {
			return []InstanceGroup{}, nil
		}
		for _, info := range raw {
			if strings.EqualFold(info.service, svc) && info.serverID == num {
				return []InstanceGroup{{Type: svc, IDs: []int{num}}}, nil
			}
		}
		return []InstanceGroup{}, nil
	}
	if service != "" {
		filtered := raw[:0]
		for _, info := range raw {
			if strings.EqualFold(info.service, service) {
				filtered = append(filtered, info)
			}
		}
		raw = filtered
	}

	return groupInstances(raw), nil
}

// groupInstances converts a flat []instanceInfo slice into []InstanceGroup,
// preserving insertion order of service types and sorting IDs within each group.
func groupInstances(raw []instanceInfo) []InstanceGroup {
	order := make([]string, 0)
	groups := make(map[string][]int)
	for _, info := range raw {
		key := info.service
		if _, seen := groups[key]; !seen {
			order = append(order, key)
		}
		groups[key] = append(groups[key], info.serverID)
	}
	result := make([]InstanceGroup, 0, len(order))
	for _, svc := range order {
		ids := groups[svc]
		// Sort IDs for deterministic output.
		sortInts(ids)
		result = append(result, InstanceGroup{Type: svc, IDs: ids})
	}
	return result
}

// sortInts sorts a slice of ints in ascending order (avoids importing sort for a trivial case).
func sortInts(s []int) {
	for i := 1; i < len(s); i++ {
		for j := i; j > 0 && s[j] < s[j-1]; j-- {
			s[j], s[j-1] = s[j-1], s[j]
		}
	}
}

// WorkspaceInfo is a single entry returned by ListWorkspaces.
type WorkspaceInfo struct {
	Workspace string `json:"workspace"` // value to pass as workspace to other tools
	Backend   string `json:"backend"`   // "etcd" or "mongo"
}

// ListWorkspaces returns all known workspace identifiers.
//
// etcd model:          every env key across all configured etcd clusters.
// mongo fallback:      distinct values of processes.project in the autoops DB.
// Both sources are merged and deduplicated.
func (r *Resolver) ListWorkspaces(ctx context.Context) ([]WorkspaceInfo, error) {
	seen := make(map[string]bool)
	var infos []WorkspaceInfo

	// ── etcd: enumerate all configured (project, env) pairs ──────────────────
	if r.cfg.Etcd != nil {
		for _, envMap := range r.cfg.Etcd {
			for env := range envMap {
				if !seen[env] {
					seen[env] = true
					infos = append(infos, WorkspaceInfo{Workspace: env, Backend: "etcd"})
				}
			}
		}
	}

	// ── mongo fallback: distinct processes.project values ────────────────────
	mongoInfos, err := r.listWorkspacesViaMongo(ctx)
	if err != nil {
		// If etcd already returned results, mongo failure is non-fatal.
		if len(infos) == 0 {
			return nil, err
		}
	}
	for _, info := range mongoInfos {
		if !seen[info.Workspace] {
			seen[info.Workspace] = true
			infos = append(infos, info)
		}
	}

	return infos, nil
}

// ─────────────────────────────────────────────────────────────────────────────
// etcd helpers
// ─────────────────────────────────────────────────────────────────────────────

// findEtcdCluster searches cfg.Etcd for a (project, env) pair where the env
// key equals workspace. workspace uniquely identifies an environment; the
// internal project key is an implementation detail not exposed to callers.
//
// Returns (project, cluster, true) on match, or ("", zero, false) if not found.
func (r *Resolver) findEtcdCluster(workspace string) (project string, cluster config.EtcdCluster, ok bool) {
	if r.cfg.Etcd == nil {
		return "", config.EtcdCluster{}, false
	}
	for proj, envMap := range r.cfg.Etcd {
		if c, found := envMap[workspace]; found {
			return proj, c, true
		}
	}
	return "", config.EtcdCluster{}, false
}

// etcdCluster returns the EtcdCluster for (project, env) if one is configured.
// Kept for internal use by tests and getEtcdClient.
func (r *Resolver) etcdCluster(project, env string) (config.EtcdCluster, bool) {
	if r.cfg.Etcd == nil {
		return config.EtcdCluster{}, false
	}
	envMap, ok := r.cfg.Etcd[project]
	if !ok {
		return config.EtcdCluster{}, false
	}
	cluster, ok := envMap[env]
	return cluster, ok
}

// namespaceFlag returns the namespace flag value, defaulting to true.
func namespaceFlag(cluster config.EtcdCluster) bool {
	if cluster.Namespace == nil {
		return true
	}
	return *cluster.Namespace
}

// dbNameGroupFlag returns the db_name_group flag value, defaulting to false.
func dbNameGroupFlag(cluster config.EtcdCluster) bool {
	if cluster.DBNameGroup == nil {
		return false
	}
	return *cluster.DBNameGroup
}

// getEtcdClient returns a cached (or newly created) etcd client for the cluster.
// The client is stored in the sync.Map under key "<project>\x00<env>".
func (r *Resolver) getEtcdClient(project, env string, cluster config.EtcdCluster) (*clientv3.Client, error) {
	key := project + "\x00" + env

	if v, loaded := r.etcdClients.Load(key); loaded {
		return v.(*clientv3.Client), nil
	}

	cli, err := clientv3.New(clientv3.Config{
		Endpoints:   cluster.Endpoints,
		DialTimeout: connectionTimeout,
	})
	if err != nil {
		return nil, gwerr.ConnectionWithCause(err,
			"无法连接 etcd 集群（project=%s env=%s）", project, env)
	}

	// Store only if not already present (another goroutine may have raced us).
	actual, loaded := r.etcdClients.LoadOrStore(key, cli)
	if loaded {
		// We lost the race; close the client we just created.
		_ = cli.Close()
		return actual.(*clientv3.Client), nil
	}
	return cli, nil
}

// resolveViaEtcd performs resolution using the etcd backend.
func (r *Resolver) resolveViaEtcd(
	ctx context.Context,
	workspace, project, service, serverID string, serverIDNum int,
	cluster config.EtcdCluster,
) (*ResolvedTarget, error) {
	namespace := namespaceFlag(cluster)
	key := BuildEtcdKey(project, workspace, service, serverID, namespace)

	cli, err := r.getEtcdClient(project, workspace, cluster)
	if err != nil {
		return nil, err
	}

	// Use a child context with the connection timeout for the get operation.
	getCtx, cancel := context.WithTimeout(ctx, connectionTimeout)
	defer cancel()

	resp, err := cli.Get(getCtx, key)
	if err != nil {
		return nil, gwerr.ConnectionWithCause(err,
			"etcd Get 失败（key=%s）", key)
	}
	if len(resp.Kvs) == 0 {
		return nil, gwerr.NotFound(
			"实例 %q 在 etcd 中不存在（workspace=%s key=%s）",
			service+serverID, workspace, key)
	}

	var val EtcdValue
	if jsonErr := json.Unmarshal(resp.Kvs[0].Value, &val); jsonErr != nil {
		return nil, gwerr.UpstreamWithCause(jsonErr,
			"etcd value JSON 解析失败（key=%s）", key)
	}

	// Extract host(s) and db from DBURL (credentials discarded — requirement 4.8, 9.7).
	// Preserve the full replica-set seed list and replica-set name so reads can
	// be routed to a secondary.
	connInfo, err := ParseDBURLConn(val.DBURL)
	if err != nil {
		maskedURL := secret.MaskDBURL(val.DBURL)
		return nil, gwerr.UpstreamWithCause(err,
			"无法解析 etcd DBURL（masked=%s）", maskedURL)
	}

	// Apply db_name_group prefix (requirement 4.9).
	dbName := ApplyDBNameGroup(workspace, connInfo.DBName, dbNameGroupFlag(cluster))

	// Extract pprof IP from Addr (requirement 7.7).
	pprofIP, err := ExtractHostIP(val.Addr)
	if err != nil {
		return nil, err
	}

	return &ResolvedTarget{
		Workspace:   workspace,
		etcdProject: project,
		Service:     service,
		ServerID:    serverID,
		ServerIDNum: serverIDNum,
		Backend:     BackendEtcd,
		MongoHostPort: strings.Join(connInfo.Hosts, ","),
		MongoDBName:   dbName,
		MongoReplicaSet: connInfo.ReplicaSet,
		PprofHostIP:   pprofIP,
		// Redis address for etcd model comes from config (resolved by caller via
		// config.ResolveRedisCredentials), not stored here.
		RedisAddr: "",
	}, nil
}

// listViaEtcd returns all instances for workspace using an etcd prefix scan.
func (r *Resolver) listViaEtcd(
	ctx context.Context,
	workspace, project string,
	cluster config.EtcdCluster,
) ([]instanceInfo, error) {
	namespace := namespaceFlag(cluster)
	prefix := BuildEtcdPrefix(project, workspace, namespace)

	cli, err := r.getEtcdClient(project, workspace, cluster)
	if err != nil {
		return nil, err
	}

	getCtx, cancel := context.WithTimeout(ctx, connectionTimeout)
	defer cancel()

	resp, err := cli.Get(getCtx, prefix, clientv3.WithPrefix())
	if err != nil {
		return nil, gwerr.ConnectionWithCause(err,
			"etcd GetWithPrefix 失败（prefix=%s）", prefix)
	}

	infos := make([]instanceInfo, 0, len(resp.Kvs))
	for _, kv := range resp.Kvs {
		instanceName, parseErr := InstanceFromEtcdKey(prefix, string(kv.Key))
		if parseErr != nil {
			continue
		}
		svc, _, num, parseErr := ParseInstance(instanceName)
		if parseErr != nil {
			continue
		}
		infos = append(infos, instanceInfo{service: svc, serverID: num})
	}
	return infos, nil
}

// ─────────────────────────────────────────────────────────────────────────────
// mongo fallback helpers
// ─────────────────────────────────────────────────────────────────────────────

// getAutoopsClient returns the process-level mongo client for the autoops
// management database, creating it on first call.
//
// The account used is cfg.Mongo.Autoops.Account when present; otherwise
// cfg.Mongo.Readonly (requirement 4.11, 9.1).
func (r *Resolver) getAutoopsClient() (*mongo.Client, error) {
	r.autoopsMu.Lock()
	defer r.autoopsMu.Unlock()

	if r.autoopsClient != nil {
		return r.autoopsClient, nil
	}

	cred := r.cfg.Mongo.Readonly
	if r.cfg.Mongo.Autoops.Account != nil {
		cred = *r.cfg.Mongo.Autoops.Account
	}

	uri := buildMongoURI(cred, r.cfg.Mongo.Autoops.Host, r.cfg.Mongo.Autoops.Port, r.cfg.Mongo.Autoops.DB, r.cfg.Mongo.Autoops.AuthSource)

	ctx, cancel := context.WithTimeout(context.Background(), connectionTimeout)
	defer cancel()

	cli, err := mongo.Connect(ctx, options.Client().ApplyURI(uri))
	if err != nil {
		return nil, gwerr.ConnectionWithCause(err,
			"无法连接 autoops MongoDB（host=%s port=%d）",
			r.cfg.Mongo.Autoops.Host, r.cfg.Mongo.Autoops.Port)
	}
	r.autoopsClient = cli
	return cli, nil
}

// buildMongoURI constructs a MongoDB connection URI injecting the supplied
// credential. The resulting URI never contains internal details that should be
// hidden; callers may mask it before logging.
//
// When cred.User is empty the connection is treated as anonymous (no-auth):
// no "user:pass@" segment and no authSource are emitted.
//
// Format (authenticated): mongodb://user:pass@host:port/db?authSource=<authSource>
// Format (anonymous):      mongodb://host:port/db
func buildMongoURI(cred config.Credential, host string, port int, db, authSource string) string {
	if cred.User == "" {
		return fmt.Sprintf("mongodb://%s:%d/%s", host, port, db)
	}
	if authSource == "" {
		authSource = "admin"
	}
	encodedUser := url.PathEscape(cred.User)
	encodedPass := url.PathEscape(cred.Pass)
	return fmt.Sprintf("mongodb://%s:%s@%s:%d/%s?authSource=%s",
		encodedUser, encodedPass, host, port, db, authSource)
}

// processDoc represents a subset of a processes collection document used
// internally during resolution. All string fields come directly from BSON
// values; credential fields are never populated.
//
// In the mongo fallback model processes.project stores the env name
// (e.g. "h5dev-zaza"), not a separate project identifier.
// ServiceParam captures the per-service launch-param string
// (e.g. vars.gameparam, vars.gateparam) used to detect --dbnameGroup 1.
type processDoc struct {
	HostID interface{} `bson:"host_id"`
	Vars   struct {
		DBURL        string `bson:"dburl"`
		CSV          string `bson:"csv"`
		ID           string `bson:"id"`
		Redis        string `bson:"redis"`
		// Per-service launch-param fields; only the one matching the resolved
		// service type will be non-empty for any given document.
		GameParam   string `bson:"gameparam"`
		GateParam   string `bson:"gateparam"`
		CrossParam  string `bson:"crossparam"`
		AcParam     string `bson:"actvparam"`
		DoorParam   string `bson:"doorparam"`
		PlatParam   string `bson:"platparam"`
		GlobalParam string `bson:"globalparam"`
		ChatParam   string `bson:"chatparam"`
		MailParam   string `bson:"mailparam"`
		PayParam    string `bson:"payparam"`
		WebParam    string `bson:"webparam"`
	} `bson:"vars"`
}

// serviceParam returns the launch-param string for the given service type from
// a processDoc.  If the service type is not explicitly listed the empty string
// is returned (which HasDBNameGroup treats as false).
func (d *processDoc) serviceParam(service string) string {
	switch strings.ToLower(service) {
	case "game":
		return d.Vars.GameParam
	case "gate":
		return d.Vars.GateParam
	case "cross":
		return d.Vars.CrossParam
	case "actv":
		return d.Vars.AcParam
	case "door":
		return d.Vars.DoorParam
	case "plat":
		return d.Vars.PlatParam
	case "global":
		return d.Vars.GlobalParam
	case "chat":
		return d.Vars.ChatParam
	case "mail":
		return d.Vars.MailParam
	case "pay":
		return d.Vars.PayParam
	case "web", "webserver":
		return d.Vars.WebParam
	default:
		return ""
	}
}

// resolveViaMongo performs resolution using the mongo autoops backend.
//
// workspace equals processes.project in the mongo fallback model (e.g. "h5dev-zaza").
func (r *Resolver) resolveViaMongo(
	ctx context.Context,
	workspace, service, serverID string, serverIDNum int,
) (*ResolvedTarget, error) {
	cli, err := r.getAutoopsClient()
	if err != nil {
		return nil, err
	}

	db := cli.Database(r.cfg.Mongo.Autoops.DB)
	coll := db.Collection("processes")

	// processes.project stores the workspace name in the mongo fallback model.
	filter := bson.M{
		"project":    workspace,
		"serverName": service,
		"vars.id":    serverID,
	}

	queryCtx, cancel := context.WithTimeout(ctx, connectionTimeout)
	defer cancel()

	cursor, err := coll.Find(queryCtx, filter)
	if err != nil {
		return nil, gwerr.ConnectionWithCause(err,
			"processes.find 失败（workspace=%s service=%s id=%s）", workspace, service, serverID)
	}
	defer cursor.Close(ctx)

	var docs []processDoc
	if decodeErr := cursor.All(queryCtx, &docs); decodeErr != nil {
		return nil, gwerr.UpstreamWithCause(decodeErr,
			"processes 文档解码失败（workspace=%s service=%s id=%s）", workspace, service, serverID)
	}

	switch len(docs) {
	case 0:
		return nil, gwerr.NotFound(
			"实例 %q 不存在（workspace=%s）", service+serverID, workspace)
	default:
		if len(docs) > 1 {
			return nil, gwerr.Ambiguous(
				"实例 %q 不唯一：找到 %d 条记录（workspace=%s）",
				service+serverID, len(docs), workspace)
		}
	}

	doc := docs[0]

	// Extract host:port from vars.dburl (credentials discarded).
	if doc.Vars.DBURL == "" {
		return nil, gwerr.Upstream(
			"实例 %q 的 vars.dburl 为空（workspace=%s）", service+serverID, workspace)
	}
	connInfo, err := ParseDBURLConn(doc.Vars.DBURL)
	if err != nil {
		maskedURL := secret.MaskDBURL(doc.Vars.DBURL)
		return nil, gwerr.UpstreamWithCause(err,
			"无法解析 vars.dburl（masked=%s）", maskedURL)
	}

	// Derive db name, then apply --dbnameGroup prefix if the service param
	// contains "--dbnameGroup 1" (mongo fallback equivalent of etcd db_name_group).
	rawDBName := BuildDBName(service, serverID, doc.Vars.CSV)
	dbNameGroup := HasDBNameGroup(doc.serviceParam(service))
	dbName := ApplyDBNameGroup(workspace, rawDBName, dbNameGroup)

	// Resolve pprof IP via host_id → hosts.lanip (requirement 7.8).
	pprofIP, err := r.resolveHostLanIP(ctx, cli, doc.HostID)
	if err != nil {
		return nil, err
	}

	// Redis address from vars.redis (requirement 6.3).
	redisAddr := strings.TrimSpace(doc.Vars.Redis)

	return &ResolvedTarget{
		Workspace:   workspace,
		Service:     service,
		ServerID:    serverID,
		ServerIDNum: serverIDNum,
		Backend:     BackendMongoFallback,
		MongoHostPort: strings.Join(connInfo.Hosts, ","),
		MongoDBName:   dbName,
		MongoReplicaSet: connInfo.ReplicaSet,
		PprofHostIP:   pprofIP,
		RedisAddr:     redisAddr,
	}, nil
}

// hostDoc holds the fields we need from the hosts collection.
type hostDoc struct {
	LanIP string `bson:"lanip"`
}

// resolveHostLanIP looks up hosts.lanip by host_id (requirement 7.8).
func (r *Resolver) resolveHostLanIP(ctx context.Context, cli *mongo.Client, hostID interface{}) (string, error) {
	if hostID == nil {
		return "", gwerr.Upstream("实例缺少 host_id 字段，无法解析 pprof 主机 IP")
	}

	coll := cli.Database(r.cfg.Mongo.Autoops.DB).Collection("hosts")

	var filter bson.M
	// host_id may arrive as an ObjectID or a string; handle both.
	switch v := hostID.(type) {
	case primitive.ObjectID:
		filter = bson.M{"_id": v}
	case string:
		oid, err := primitive.ObjectIDFromHex(v)
		if err == nil {
			filter = bson.M{"_id": oid}
		} else {
			filter = bson.M{"_id": v}
		}
	default:
		filter = bson.M{"_id": hostID}
	}

	queryCtx, cancel := context.WithTimeout(ctx, connectionTimeout)
	defer cancel()

	var doc hostDoc
	err := coll.FindOne(queryCtx, filter).Decode(&doc)
	if err != nil {
		if err == mongo.ErrNoDocuments {
			return "", gwerr.Upstream(
				"无法解析目标主机：hosts 集合中未找到 host_id=%v 对应的文档", hostID)
		}
		return "", gwerr.UpstreamWithCause(err,
			"hosts.findOne 失败（host_id=%v）", hostID)
	}

	lanIP := strings.TrimSpace(doc.LanIP)
	if lanIP == "" {
		return "", gwerr.Upstream(
			"无法解析目标主机：hosts 文档中 lanip 为空（host_id=%v）", hostID)
	}
	return lanIP, nil
}

// listViaMongo returns all instances for the workspace by querying the processes
// collection. workspace == processes.project in the mongo fallback model.
func (r *Resolver) listViaMongo(ctx context.Context, workspace string) ([]instanceInfo, error) {
	cli, err := r.getAutoopsClient()
	if err != nil {
		return nil, err
	}

	coll := cli.Database(r.cfg.Mongo.Autoops.DB).Collection("processes")

	queryCtx, cancel := context.WithTimeout(ctx, connectionTimeout)
	defer cancel()

	type listDoc struct {
		ServerName string `bson:"serverName"`
		Vars       struct {
			ID string `bson:"id"`
		} `bson:"vars"`
	}

	cursor, err := coll.Find(queryCtx, bson.M{"project": workspace},
		options.Find().SetProjection(bson.M{
			"serverName": 1,
			"vars.id":    1,
		}),
	)
	if err != nil {
		return nil, gwerr.ConnectionWithCause(err,
			"processes.find 列举失败（workspace=%s）", workspace)
	}
	defer cursor.Close(ctx)

	var docs []listDoc
	if decodeErr := cursor.All(queryCtx, &docs); decodeErr != nil {
		return nil, gwerr.UpstreamWithCause(decodeErr,
			"processes 文档解码失败（workspace=%s）", workspace)
	}

	infos := make([]instanceInfo, 0, len(docs))
	for _, d := range docs {
		if d.ServerName == "" || d.Vars.ID == "" {
			continue
		}
		_, _, num, parseErr := ParseInstance(d.ServerName + d.Vars.ID)
		if parseErr != nil {
			continue
		}
		infos = append(infos, instanceInfo{service: d.ServerName, serverID: num})
	}
	return infos, nil
}

// listWorkspacesViaMongo returns distinct processes.project values as
// WorkspaceInfo entries with Backend="mongo".
func (r *Resolver) listWorkspacesViaMongo(ctx context.Context) ([]WorkspaceInfo, error) {
	cli, err := r.getAutoopsClient()
	if err != nil {
		return nil, err
	}

	coll := cli.Database(r.cfg.Mongo.Autoops.DB).Collection("processes")

	queryCtx, cancel := context.WithTimeout(ctx, connectionTimeout)
	defer cancel()

	raw, err := coll.Distinct(queryCtx, "project", bson.M{})
	if err != nil {
		return nil, gwerr.ConnectionWithCause(err, "processes.distinct(project) 失败")
	}

	infos := make([]WorkspaceInfo, 0, len(raw))
	for _, v := range raw {
		if s, ok := v.(string); ok && s != "" {
			infos = append(infos, WorkspaceInfo{Workspace: s, Backend: "mongo"})
		}
	}
	return infos, nil
}
