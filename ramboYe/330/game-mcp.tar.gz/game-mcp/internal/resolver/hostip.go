package resolver

import (
	"net"

	"game-mcp/internal/gwerr"
)

// ExtractHostIP splits an "ip:port" address and returns the IP part.
// If addr is empty or the IP portion is empty after splitting,
// a gwerr.Validation error is returned so callers get a structured
// "cannot resolve target host" error without having to repeat the logic.
//
// This is the single point of encapsulation for the pprof host-IP extraction
// decision (Requirements 7.7, 7.9), making it easy to change the behaviour
// in one place if the "待确认" (to-be-confirmed) decision is revisited.
func ExtractHostIP(addr string) (string, error) {
	if addr == "" {
		return "", gwerr.Validation("无法解析目标主机：addr 为空")
	}
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return "", gwerr.ValidationWithCause(err, "无法解析目标主机：addr 格式错误（期望 <ip>:<port>）")
	}
	if host == "" {
		return "", gwerr.Validation("无法解析目标主机：IP 部分为空")
	}
	return host, nil
}
