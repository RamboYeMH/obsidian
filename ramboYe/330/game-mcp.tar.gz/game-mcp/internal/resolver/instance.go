package resolver

import (
	"regexp"
	"strconv"

	"game-mcp/internal/gwerr"
)

var instanceRe = regexp.MustCompile(`^([a-zA-Z]+)(\d+)$`)

// ParseInstance parses an instance name of the form <service><id> (e.g. "game1",
// "cross1008") into its constituent parts.
//
// service preserves the original letter casing (requirement 4.1).
// Non-conforming names (empty string, no leading letters, no trailing digits,
// or characters outside [A-Za-z0-9]) return a gwerr.Validation error and zero
// values for all outputs (requirement 4.2).
func ParseInstance(name string) (service string, serverID string, num int, err error) {
	m := instanceRe.FindStringSubmatch(name)
	if m == nil {
		return "", "", 0, gwerr.Validation(
			"实例名格式错误：应为 <service><id>（前导字母为 service-type，结尾数字为 serverid），例如 game1")
	}
	service = m[1]  // preserve original casing (requirement 4.1)
	serverID = m[2]
	num, _ = strconv.Atoi(serverID)
	return
}
