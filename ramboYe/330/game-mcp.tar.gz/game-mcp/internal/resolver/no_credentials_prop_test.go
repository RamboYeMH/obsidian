// Feature: pprof-redis-proxy, Property 17: 对外输出绝不含凭据
package resolver

// Validates: Requirements 8.6, 9.8

import (
	"fmt"
	"reflect"
	"strings"
	"testing"

	"pgregory.net/rapid"
)

// credentialFieldNames is the set of field names that would indicate a
// credential is being exposed in an exported struct.
var credentialFieldNames = []string{
	"Password", "Pass", "Passwd", "Secret", "Token", "Key",
	"Credential", "Credentials", "Auth", "Authorization",
	"DBPassword", "MongoPass", "RedisPass",
	"User", "Username",   // user alone with pass would expose credentials
	"DBURL",              // raw DBURL with embedded credentials must not appear
}

// hasCredentialField uses reflection to check whether a struct type contains
// any field whose name suggests it stores credential data.
// It returns the list of suspicious field names found (empty means clean).
func hasCredentialField(t reflect.Type) []string {
	if t.Kind() == reflect.Ptr {
		t = t.Elem()
	}
	if t.Kind() != reflect.Struct {
		return nil
	}
	var found []string
	for i := 0; i < t.NumField(); i++ {
		name := t.Field(i).Name
		for _, cred := range credentialFieldNames {
			if strings.EqualFold(name, cred) {
				found = append(found, name)
			}
		}
	}
	return found
}

// credSafeComponent generates a non-empty alphanumeric string that is safe to
// embed in any URL position without confusing parsers.
var credSafeComponent = rapid.StringMatching(`[a-zA-Z0-9]{1,20}`)

// credSafePassword generates a password that is clearly distinct from other
// fields (has a prefix "pw_") to make credential leaks easy to detect.
var credSafePassword = rapid.Custom(func(t *rapid.T) string {
	return "pw_" + credSafeComponent.Draw(t, "pwBody")
})

// TestProperty17_InstanceInfoHasNoCredentialFields checks via reflection that
// InstanceGroup carries no fields whose name implies credential storage.
//
// ≥100 iterations (rapid default; since this is a structural check the same
// result is asserted on every iteration, but rapid still runs ≥100 checks
// to confirm the invariant is stable across the test run).
func TestProperty17_InstanceInfoHasNoCredentialFields(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		typ := reflect.TypeOf(InstanceGroup{})
		leaked := hasCredentialField(typ)
		if len(leaked) > 0 {
			t.Fatalf("InstanceGroup exposes credential field(s) %v — requirement 8.6, 9.8", leaked)
		}
	})
}

// TestProperty17_ResolvedTargetHasNoCredentialFields checks via reflection that
// ResolvedTarget carries no fields whose name implies credential storage.
func TestProperty17_ResolvedTargetHasNoCredentialFields(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		typ := reflect.TypeOf(ResolvedTarget{})
		leaked := hasCredentialField(typ)
		if len(leaked) > 0 {
			t.Fatalf("ResolvedTarget exposes credential field(s) %v — requirement 8.6, 9.8", leaked)
		}
	})
}

// TestProperty17_ParseDBURLPasswordNeverInOutput verifies that ParseDBURL strips
// embedded credentials from every DBURL it accepts: neither the returned
// hostPort nor the dbName ever contains the raw password substring.
//
// ≥100 iterations.
func TestProperty17_ParseDBURLPasswordNeverInOutput(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		user := credSafeComponent.Draw(t, "user")
		pass := credSafePassword.Draw(t, "pass")
		host := credSafeComponent.Draw(t, "host")
		port := rapid.IntRange(1, 65535).Draw(t, "port")
		db := credSafeComponent.Draw(t, "db")

		dburl := fmt.Sprintf("%s:%s@%s:%d/%s", user, pass, host, port, db)

		gotHostPort, gotDB, err := ParseDBURL(dburl)
		if err != nil {
			t.Fatalf("ParseDBURL(%q) returned unexpected error: %v", dburl, err)
		}

		// 17a: the password must not appear in either return value.
		if strings.Contains(gotHostPort, pass) {
			t.Fatalf("ParseDBURL: password %q leaked into hostPort %q (input: %q)",
				pass, gotHostPort, dburl)
		}
		if strings.Contains(gotDB, pass) {
			t.Fatalf("ParseDBURL: password %q leaked into dbName %q (input: %q)",
				pass, gotDB, dburl)
		}

		// 17b: the combined "user:pass@" credential token must never appear.
		plainCred := fmt.Sprintf("%s:%s@", user, pass)
		combined := gotHostPort + gotDB
		if strings.Contains(combined, plainCred) {
			t.Fatalf("ParseDBURL: combined output %q contains credential token %q (input: %q)",
				combined, plainCred, dburl)
		}
	})
}

// TestProperty17_EtcdValuePasswordNeverInInstanceInfo builds InstanceGroup
// values the same way listViaEtcd does (reading only the instance name from
// key + EtcdValue) and verifies the result contains no embedded password from
// the DBURL.
//
// This simulates the etcd listing path without requiring a live etcd connection.
// ≥100 iterations.
func TestProperty17_EtcdValuePasswordNeverInInstanceInfo(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		service := credSafeComponent.Draw(t, "service")
		serverid := rapid.IntRange(1, 9999).Draw(t, "serverid")
		user := credSafeComponent.Draw(t, "user")
		pass := credSafePassword.Draw(t, "pass")
		host := credSafeComponent.Draw(t, "host")
		port := rapid.IntRange(1, 65535).Draw(t, "port")
		db := credSafeComponent.Draw(t, "db")

		val := EtcdValue{
			Name:   fmt.Sprintf("%s%d", service, serverid),
			Addr:   fmt.Sprintf("10.0.0.1:%d", port),
			Label:  "irrelevant",
			Weight: 1,
			DBURL:  fmt.Sprintf("%s:%s@%s:%d/%s", user, pass, host, port, db),
		}

		// Replicate what listViaEtcd does: group by service type, collect ids.
		group := InstanceGroup{
			Type: service,
			IDs:  []int{serverid},
		}

		// 17c: the password must not appear in the Type field of InstanceGroup.
		if strings.Contains(group.Type, pass) {
			t.Fatalf("InstanceGroup.Type %q contains password %q (DBURL: %q)",
				group.Type, pass, val.DBURL)
		}

		// 17d: stringify the whole struct and check no credential token appears.
		repr := fmt.Sprintf("%+v", group)
		if strings.Contains(repr, pass) {
			t.Fatalf("InstanceGroup repr %q contains password %q (DBURL: %q)",
				repr, pass, val.DBURL)
		}
	})
}

// TestProperty17_ParseDBURLOutputContainsNoPasswordForOldFormat checks that
// the old-format DBURL (comma-separated replica set) also strips the password
// from both return values.
//
// Old format: user:pass@ip1:port,ip2:port/db
// ≥100 iterations.
func TestProperty17_ParseDBURLOutputContainsNoPasswordForOldFormat(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		user := credSafeComponent.Draw(t, "user")
		pass := credSafePassword.Draw(t, "pass")
		db := credSafeComponent.Draw(t, "db")

		// Build a valid old-format replica-set URL.
		// Last octet of second IP drives the derived port: 20000 + lastOctet.
		octet1 := rapid.IntRange(1, 254).Draw(t, "octet1")
		octet2 := rapid.IntRange(1, 254).Draw(t, "octet2")
		lastOctet := rapid.IntRange(1, 535).Draw(t, "lastOctet") // keep 20000+n in valid range
		basePort := rapid.IntRange(1, 9999).Draw(t, "basePort")

		ip1 := fmt.Sprintf("192.168.%d.%d", octet1, octet2)
		ip2 := fmt.Sprintf("192.168.%d.%d", octet1, lastOctet)

		oldFmtURL := fmt.Sprintf("%s:%s@%s:%d,%s:%d/%s",
			user, pass, ip1, basePort, ip2, basePort, db)

		gotHostPort, gotDB, err := ParseDBURL(oldFmtURL)
		if err != nil {
			// Old-format parsing may fail on some edge cases (e.g. port > 65535);
			// errors are acceptable — the key invariant is "no leak on success".
			return
		}

		// 17e: password must not appear in either return value.
		if strings.Contains(gotHostPort, pass) {
			t.Fatalf("ParseDBURL (old fmt): password %q leaked into hostPort %q (input: %q)",
				pass, gotHostPort, oldFmtURL)
		}
		if strings.Contains(gotDB, pass) {
			t.Fatalf("ParseDBURL (old fmt): password %q leaked into dbName %q (input: %q)",
				pass, gotDB, oldFmtURL)
		}
	})
}

// TestProperty17_InstanceInfoFieldsAreOnlyAllowed is a whitelist check:
// InstanceGroup must expose exactly the fields that carry no sensitive data
// (Type and IDs). Any new field added to the struct is flagged until
// explicitly allow-listed here.
//
// ≥100 iterations (structural property).
func TestProperty17_InstanceInfoFieldsAreOnlyAllowed(t *testing.T) {
	allowedFields := map[string]bool{
		"Type": true,
		"IDs":  true,
	}

	rapid.Check(t, func(t *rapid.T) {
		typ := reflect.TypeOf(InstanceGroup{})
		for i := 0; i < typ.NumField(); i++ {
			name := typ.Field(i).Name
			if !allowedFields[name] {
				t.Fatalf("InstanceGroup has unexpected field %q — "+
					"all fields must be explicitly allow-listed to ensure no credential leaks "+
					"(requirement 8.6, 9.8)", name)
			}
		}
	})
}
