// Package resolver_test contains unit and integration tests for the
// Service Resolver.
//
// Test organisation:
//  1. Routing-decision unit tests — verify that etcdCluster() returns the
//     correct backend choice based purely on the config (no network I/O).
//  2. Credential-free output tests — compile-time and runtime assertions that
//     ResolvedTarget and InstanceInfo carry no credential fields.
//  3. Integration tests — these contact real backends and are guarded by
//     environment variables:
//     - ETCD_ENDPOINTS (comma-separated) — enables etcd-path tests
//     - MONGO_URI — enables mongo-fallback-path tests
//     Tests that require a missing backend call t.Skip().
//
// Requirements: 4.4, 4.10, 4.12, 4.13
package resolver

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"reflect"
	"strings"
	"testing"

	clientv3 "go.etcd.io/etcd/client/v3"

	"game-mcp/internal/config"
	"game-mcp/internal/gwerr"
)

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

// boolPtr returns a pointer to the given bool value.
func boolPtr(b bool) *bool { return &b }

// cfgWithEtcd builds a minimal Config that has an etcd cluster for
// (project, env) but a usable mongo fallback section.
func cfgWithEtcd(project, env string, endpoints []string) *config.Config {
	return &config.Config{
		Etcd: map[string]map[string]config.EtcdCluster{
			project: {
				env: {
					Endpoints:   endpoints,
					Namespace:   boolPtr(true),
					DBNameGroup: boolPtr(false),
				},
			},
		},
		Mongo: config.MongoConfig{
			Readonly: config.Credential{User: "ro_user", Pass: "ro_pass"},
			Autoops: config.AutoopsConfig{
				Host: "localhost",
				Port: 27017,
				DB:   "autoops_v2",
			},
		},
	}
}

// cfgMongoOnly builds a minimal Config that has NO etcd cluster configured.
func cfgMongoOnly() *config.Config {
	return &config.Config{
		Mongo: config.MongoConfig{
			Readonly: config.Credential{User: "ro_user", Pass: "ro_pass"},
			Autoops: config.AutoopsConfig{
				Host: "localhost",
				Port: 27017,
				DB:   "autoops_v2",
			},
		},
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// 1. Routing-decision unit tests (no network I/O)
// ─────────────────────────────────────────────────────────────────────────────

// TestEtcdCluster_ReturnsCluster verifies that etcdCluster returns the correct
// cluster when one is configured for the (project, env) pair.
// Requirements: 4.4
func TestEtcdCluster_ReturnsCluster(t *testing.T) {
	endpoints := []string{"127.0.0.1:2379"}
	r, err := NewResolver(cfgWithEtcd("h5", "h5dev2", endpoints))
	if err != nil {
		t.Fatalf("NewResolver: %v", err)
	}

	cluster, ok := r.etcdCluster("h5", "h5dev2")
	if !ok {
		t.Fatal("expected etcdCluster to return true for configured (project, env)")
	}
	if len(cluster.Endpoints) == 0 || cluster.Endpoints[0] != endpoints[0] {
		t.Errorf("got endpoints %v, want %v", cluster.Endpoints, endpoints)
	}
}

// TestEtcdCluster_NotConfigured verifies that etcdCluster returns (_, false)
// when the project is not configured at all.
// Requirements: 4.4
func TestEtcdCluster_NotConfigured(t *testing.T) {
	r, err := NewResolver(cfgMongoOnly())
	if err != nil {
		t.Fatalf("NewResolver: %v", err)
	}

	_, ok := r.etcdCluster("unknown_project", "some_env")
	if ok {
		t.Error("expected etcdCluster to return false when project is not configured")
	}
}

// TestEtcdCluster_ProjectExistsButEnvMissing verifies that etcdCluster returns
// false when the project is configured but the requested env is not.
// Requirements: 4.4
func TestEtcdCluster_ProjectExistsButEnvMissing(t *testing.T) {
	r, err := NewResolver(cfgWithEtcd("h5", "h5dev2", []string{"127.0.0.1:2379"}))
	if err != nil {
		t.Fatalf("NewResolver: %v", err)
	}

	_, ok := r.etcdCluster("h5", "h5prod") // env differs
	if ok {
		t.Error("expected etcdCluster to return false for unconfigured env")
	}
}

// TestEtcdCluster_NilEtcdMap verifies that etcdCluster handles a nil Etcd map
// gracefully (no panic, returns false).
// Requirements: 4.4
func TestEtcdCluster_NilEtcdMap(t *testing.T) {
	r, err := NewResolver(cfgMongoOnly()) // Etcd field is nil
	if err != nil {
		t.Fatalf("NewResolver: %v", err)
	}

	_, ok := r.etcdCluster("any", "any")
	if ok {
		t.Error("expected etcdCluster to return false when Etcd map is nil")
	}
}

// TestNewResolver_NilConfigReturnsError verifies that NewResolver rejects nil.
func TestNewResolver_NilConfigReturnsError(t *testing.T) {
	_, err := NewResolver(nil)
	if err == nil {
		t.Fatal("expected error for nil config, got nil")
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. Credential-free output tests
// ─────────────────────────────────────────────────────────────────────────────

// TestResolvedTarget_NoCredentialFields asserts at runtime that ResolvedTarget
// contains no fields whose names hint at credentials.
// Requirements: 4.13, 4.14 (no credentials in output)
func TestResolvedTarget_NoCredentialFields(t *testing.T) {
	sensitiveNames := []string{
		"pass", "password", "secret", "cred", "credential",
		"token", "auth",
	}

	rt := reflect.TypeOf(ResolvedTarget{})
	for i := 0; i < rt.NumField(); i++ {
		name := strings.ToLower(rt.Field(i).Name)
		for _, s := range sensitiveNames {
			if strings.Contains(name, s) {
				t.Errorf("ResolvedTarget has field %q which appears to be a credential field", rt.Field(i).Name)
			}
		}
	}
}

// TestInstanceInfo_NoCredentialFields asserts at runtime that InstanceGroup
// contains no fields whose names hint at credentials.
// Requirements: 4.13
func TestInstanceInfo_NoCredentialFields(t *testing.T) {
	sensitiveNames := []string{
		"pass", "password", "secret", "cred", "credential",
		"token", "auth", "dburl", "url",
	}

	rt := reflect.TypeOf(InstanceGroup{})
	for i := 0; i < rt.NumField(); i++ {
		name := strings.ToLower(rt.Field(i).Name)
		for _, s := range sensitiveNames {
			if strings.Contains(name, s) {
				t.Errorf("InstanceGroup has field %q which appears to be a credential field", rt.Field(i).Name)
			}
		}
	}
}

// TestResolvedTarget_CredentialsNotInValues verifies that when a ResolvedTarget
// is populated, the raw credential values from config do not appear in any
// string-valued fields.
// Requirements: 4.13, 4.14
func TestResolvedTarget_CredentialsNotInValues(t *testing.T) {
	sensitiveValues := []string{"ro_pass", "secret_password", "admin123"}

	rt := ResolvedTarget{
		Workspace:     "h5dev2",
		Service:       "game",
		ServerID:      "1",
		ServerIDNum:   1,
		Backend:       BackendEtcd,
		MongoHostPort: "192.168.1.10:27017",
		MongoDBName:   "gs_game_1",
		PprofHostIP:   "192.168.1.10",
		RedisAddr:     "192.168.1.20:6379",
	}

	v := reflect.ValueOf(rt)
	for i := 0; i < v.NumField(); i++ {
		field := v.Field(i)
		if field.Kind() != reflect.String {
			continue
		}
		fieldStr := field.String()
		for _, secret := range sensitiveValues {
			if strings.Contains(fieldStr, secret) {
				t.Errorf("ResolvedTarget field %q contains credential value %q",
					v.Type().Field(i).Name, secret)
			}
		}
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// 3. etcd-path integration tests (requires ETCD_ENDPOINTS env var)
// ─────────────────────────────────────────────────────────────────────────────

// getEtcdEndpoints returns the etcd endpoints from the environment, or skips
// the test if they are not set.
func getEtcdEndpoints(t *testing.T) []string {
	t.Helper()
	raw := os.Getenv("ETCD_ENDPOINTS")
	if raw == "" {
		t.Skip("ETCD_ENDPOINTS not set; skipping etcd integration test")
	}
	return strings.Split(raw, ",")
}

// startTestEtcd starts an etcd client connected to the given endpoints and
// registers cleanup.
func startTestEtcd(t *testing.T, endpoints []string) *clientv3.Client {
	t.Helper()
	cli, err := clientv3.New(clientv3.Config{
		Endpoints:   endpoints,
		DialTimeout: connectionTimeout,
	})
	if err != nil {
		t.Skipf("cannot connect to etcd at %v: %v", endpoints, err)
	}
	t.Cleanup(func() { _ = cli.Close() })
	return cli
}

// putEtcdValue writes a JSON EtcdValue under the given key, returning cleanup.
func putEtcdValue(t *testing.T, cli *clientv3.Client, key string, val EtcdValue) {
	t.Helper()
	data, err := json.Marshal(val)
	if err != nil {
		t.Fatalf("marshal etcd value: %v", err)
	}
	_, err = cli.Put(context.Background(), key, string(data))
	if err != nil {
		t.Fatalf("etcd Put(%s): %v", key, err)
	}
	t.Cleanup(func() { _, _ = cli.Delete(context.Background(), key) })
}

// TestResolve_EtcdPriority_DoesNotFallBackToMongo verifies that when an etcd
// cluster is configured for (project, env), Resolve uses etcd exclusively and
// does NOT fall back to mongo — even when the instance exists in both.
//
// This is the "etcd priority" requirement: IF etcd is configured THEN only etcd
// is tried; mongo autoops is never contacted.
// Requirements: 4.4
func TestResolve_EtcdPriority_DoesNotFallBackToMongo(t *testing.T) {
	endpoints := getEtcdEndpoints(t)
	cli := startTestEtcd(t, endpoints)

	const (
		project  = "testproj"
		env      = "testenv"
		service  = "game"
		serverID = "99"
	)

	// Build the etcd key (namespace=true by default).
	key := BuildEtcdKey(project, env, service, serverID, true)
	val := EtcdValue{
		Name:  service + serverID,
		Addr:  "192.168.5.99:22099",
		Label: "test instance",
		DBURL: "admin:etcd_secret@192.168.5.99:27017/testdb",
	}
	putEtcdValue(t, cli, key, val)

	// Configure resolver with etcd but pointing mongo at a port that is NOT
	// listening — if mongo were contacted the dial would fail and expose the
	// fallback attempt.
	cfg := &config.Config{
		Etcd: map[string]map[string]config.EtcdCluster{
			project: {
				env: {
					Endpoints:   endpoints,
					Namespace:   boolPtr(true),
					DBNameGroup: boolPtr(false),
				},
			},
		},
		Mongo: config.MongoConfig{
			Readonly: config.Credential{User: "ro_user", Pass: "ro_pass"},
			Autoops: config.AutoopsConfig{
				// Unreachable port — any mongo dial would fail.
				Host: "127.0.0.1",
				Port: 19999,
				DB:   "autoops_v2",
			},
		},
	}

	r, err := NewResolver(cfg)
	if err != nil {
		t.Fatalf("NewResolver: %v", err)
	}

	rt, err := r.Resolve(context.Background(), project+env, service+serverID)
	if err != nil {
		t.Fatalf("Resolve returned unexpected error: %v", err)
	}

	// Must have come from etcd, not mongo.
	if rt.Backend != BackendEtcd {
		t.Errorf("Backend = %v, want BackendEtcd", rt.Backend)
	}
	if rt.Service != service {
		t.Errorf("Service = %q, want %q", rt.Service, service)
	}
	if rt.ServerID != serverID {
		t.Errorf("ServerID = %q, want %q", rt.ServerID, serverID)
	}
	// Credentials must not appear in the output.
	if strings.Contains(rt.MongoHostPort, "etcd_secret") {
		t.Errorf("MongoHostPort %q contains credential from etcd DBURL", rt.MongoHostPort)
	}
	if strings.Contains(rt.MongoHostPort, "admin:") {
		t.Errorf("MongoHostPort %q contains username:password", rt.MongoHostPort)
	}
}

// TestResolve_EtcdNotFound verifies that when etcd is configured but the
// requested instance key is absent, Resolve returns a KindNotFound error.
// Requirements: 4.10
func TestResolve_EtcdNotFound(t *testing.T) {
	endpoints := getEtcdEndpoints(t)

	const (
		project  = "testproj_nf"
		env      = "testenv_nf"
		service  = "actv"
		serverID = "404"
	)

	// Do NOT write any key — the instance does not exist.
	cfg := cfgWithEtcd(project, env, endpoints)
	r, err := NewResolver(cfg)
	if err != nil {
		t.Fatalf("NewResolver: %v", err)
	}

	_, resolveErr := r.Resolve(context.Background(), env, service+serverID)
	if resolveErr == nil {
		t.Fatal("expected error for missing etcd key, got nil")
	}

	var gwErr *gwerr.GatewayError
	if !errors.As(resolveErr, &gwErr) {
		t.Fatalf("expected *gwerr.GatewayError, got %T: %v", resolveErr, resolveErr)
	}
	if gwErr.Kind != gwerr.KindNotFound {
		t.Errorf("Kind = %v, want KindNotFound", gwErr.Kind)
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// 4. Fake-etcd path tests (using httptest to simulate etcd v3 API)
// ─────────────────────────────────────────────────────────────────────────────

// NOTE: clientv3 speaks gRPC, not plain HTTP, so we cannot easily intercept it
// with httptest. Instead, the following tests use a valid-but-unreachable etcd
// endpoint to confirm the resolver attempts the etcd path (and fails with a
// KindConnection error rather than a mongo error), proving the routing decision
// is correct without needing a real etcd instance.

// TestResolve_EtcdConfigured_UsesEtcdPath confirms that when etcd is configured,
// the resolver attempts the etcd path (resulting in a KindConnection error due
// to the unreachable endpoint) rather than falling back to mongo.
// Requirements: 4.4
func TestResolve_EtcdConfigured_UsesEtcdPath(t *testing.T) {
	// Unreachable etcd endpoint — connection will time out quickly for tests.
	// We use a very short dial timeout by passing our own custom config via a
	// one-off client to prove the path is taken.
	cfg := &config.Config{
		Etcd: map[string]map[string]config.EtcdCluster{
			"h5": {
				"h5dev2": {
					Endpoints:   []string{"127.0.0.1:12379"}, // nothing listening here
					Namespace:   boolPtr(true),
					DBNameGroup: boolPtr(false),
				},
			},
		},
		Mongo: config.MongoConfig{
			Readonly: config.Credential{User: "ro_user", Pass: "ro_pass"},
			Autoops: config.AutoopsConfig{
				Host: "127.0.0.1",
				Port: 27017,
				DB:   "autoops_v2",
			},
		},
	}

	r, err := NewResolver(cfg)
	if err != nil {
		t.Fatalf("NewResolver: %v", err)
	}

	// This will fail because the etcd endpoint is unreachable, but the failure
	// must be a KindConnection error — not a mongo-path error, and not a
	// KindNotFound (which would imply mongo was tried and the instance not found).
	//
	// We cap the timeout to connectionTimeout so the test takes at most 10s.
	ctx, cancel := context.WithTimeout(context.Background(), connectionTimeout)
	defer cancel()

	_, resolveErr := r.Resolve(ctx, "h5dev2", "game1")
	if resolveErr == nil {
		t.Fatal("expected error when etcd is unreachable, got nil")
	}

	var gwErr *gwerr.GatewayError
	if !errors.As(resolveErr, &gwErr) {
		t.Fatalf("expected *gwerr.GatewayError, got %T: %v", resolveErr, resolveErr)
	}
	if gwErr.Kind != gwerr.KindConnection {
		t.Errorf("Kind = %v, want KindConnection — etcd path should have been attempted, not mongo fallback", gwErr.Kind)
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// 5. Fake HTTP server tests for etcd-JSON parsing logic
// ─────────────────────────────────────────────────────────────────────────────

// These tests exercise the etcd-value JSON parsing and credential-stripping
// logic independently of a live etcd cluster, by calling the internal helpers
// directly.

// TestResolveViaEtcd_CredentialsStrippedFromDBURL verifies that when an etcd
// value contains a DBURL with embedded credentials, the resolved target's
// MongoHostPort does not contain any credential material.
// Requirements: 4.13 (credentials never in ResolvedTarget)
func TestResolveViaEtcd_CredentialsStrippedFromDBURL(t *testing.T) {
	cases := []struct {
		name    string
		dburl   string
		wantHP  string
		wantDB  string
	}{
		{
			name:   "new format",
			dburl:  "admin:super_secret@192.168.1.10:27017/mydb",
			wantHP: "192.168.1.10:27017",
			wantDB: "mydb",
		},
		{
			name:   "with query string",
			dburl:  "user:pass123@10.0.0.5:27017/gamedb?authSource=admin",
			wantHP: "10.0.0.5:27017",
			wantDB: "gamedb",
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			hostPort, dbName, err := ParseDBURL(tc.dburl)
			if err != nil {
				t.Fatalf("ParseDBURL(%q): %v", tc.dburl, err)
			}
			if hostPort != tc.wantHP {
				t.Errorf("hostPort = %q, want %q", hostPort, tc.wantHP)
			}
			if dbName != tc.wantDB {
				t.Errorf("dbName = %q, want %q", dbName, tc.wantDB)
			}
			// Core assertion: credentials must not appear in either output.
			if strings.Contains(hostPort, "admin") || strings.Contains(hostPort, "super_secret") ||
				strings.Contains(hostPort, "user") || strings.Contains(hostPort, "pass") {
				t.Errorf("hostPort %q contains credential material", hostPort)
			}
			if strings.Contains(dbName, "admin") || strings.Contains(dbName, "super_secret") ||
				strings.Contains(dbName, "pass") {
				t.Errorf("dbName %q contains credential material", dbName)
			}
		})
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// 6. Mongo fallback path tests (requires MONGO_URI env var)
// ─────────────────────────────────────────────────────────────────────────────

// getMongoURI returns the mongo URI from the environment, or skips.
func getMongoURI(t *testing.T) string {
	t.Helper()
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		t.Skip("MONGO_URI not set; skipping mongo fallback integration test")
	}
	return uri
}

// TestResolve_MongoFallback_InstanceNotFound verifies that when etcd is NOT
// configured and the instance does not exist in the mongo processes collection,
// Resolve returns a KindNotFound error.
// Requirements: 4.12
func TestResolve_MongoFallback_InstanceNotFound(t *testing.T) {
	_ = getMongoURI(t) // skip if MONGO_URI not set

	// Parse HOST:PORT from MONGO_URI (simple split, no driver needed).
	mongoURI := os.Getenv("MONGO_URI")
	host, port := parseMongoURIHostPort(t, mongoURI)

	cfg := &config.Config{
		// No Etcd configured — forces mongo fallback path.
		Mongo: config.MongoConfig{
			Readonly: config.Credential{User: "ro_user", Pass: "ro_pass"},
			Autoops: config.AutoopsConfig{
				Host: host,
				Port: port,
				DB:   "autoops_v2",
			},
		},
	}

	r, err := NewResolver(cfg)
	if err != nil {
		t.Fatalf("NewResolver: %v", err)
	}

	// Use a project/instance that almost certainly does not exist.
	_, resolveErr := r.Resolve(context.Background(),
		"nonexistent_workspace_xyz", "game999999")
	if resolveErr == nil {
		t.Fatal("expected error for missing instance, got nil")
	}

	var gwErr *gwerr.GatewayError
	if !errors.As(resolveErr, &gwErr) {
		t.Fatalf("expected *gwerr.GatewayError, got %T: %v", resolveErr, resolveErr)
	}
	if gwErr.Kind != gwerr.KindNotFound {
		t.Errorf("Kind = %v, want KindNotFound", gwErr.Kind)
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// 7. Error-classification unit tests
//    These test the error types returned by the resolver helpers in isolation.
// ─────────────────────────────────────────────────────────────────────────────

// TestInstanceParse_InvalidFormatsReturnValidation checks that invalid instance
// names return KindValidation errors, which means the resolver never reaches
// the etcd/mongo path.
// Requirements: 4.2
func TestInstanceParse_InvalidFormatsReturnValidation(t *testing.T) {
	cases := []string{
		"",          // empty
		"123",       // no leading letters
		"game",      // no trailing digits
		"game-1",    // hyphen not in [A-Za-z0-9]
		"game 1",    // space
		"@game1",    // special char
	}

	for _, name := range cases {
		t.Run(fmt.Sprintf("name=%q", name), func(t *testing.T) {
			_, _, _, err := ParseInstance(name)
			if err == nil {
				t.Fatalf("ParseInstance(%q): expected error, got nil", name)
			}
			var gwErr *gwerr.GatewayError
			if !errors.As(err, &gwErr) {
				t.Fatalf("expected *gwerr.GatewayError, got %T: %v", err, err)
			}
			if gwErr.Kind != gwerr.KindValidation {
				t.Errorf("Kind = %v, want KindValidation", gwErr.Kind)
			}
		})
	}
}

// TestResolve_InvalidInstance_ReturnsValidationError verifies that Resolve
// returns a KindValidation error for bad instance names without touching any
// backend.
// Requirements: 4.2
func TestResolve_InvalidInstance_ReturnsValidationError(t *testing.T) {
	// Use a config with etcd set up to detect if the backend is ever touched
	// (if it were, the unreachable endpoint would return KindConnection, not
	// KindValidation).
	cfg := cfgWithEtcd("h5", "h5dev2", []string{"127.0.0.1:12379"})
	r, err := NewResolver(cfg)
	if err != nil {
		t.Fatalf("NewResolver: %v", err)
	}

	_, resolveErr := r.Resolve(context.Background(), "h5dev2", "badname!")
	if resolveErr == nil {
		t.Fatal("expected error for invalid instance name, got nil")
	}

	var gwErr *gwerr.GatewayError
	if !errors.As(resolveErr, &gwErr) {
		t.Fatalf("expected *gwerr.GatewayError, got %T: %v", resolveErr, resolveErr)
	}
	if gwErr.Kind != gwerr.KindValidation {
		t.Errorf("Kind = %v, want KindValidation — instance parse happens before backend contact", gwErr.Kind)
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// 8. Mongo-ambiguous error simulation
// ─────────────────────────────────────────────────────────────────────────────

// TestAmbiguousError_KindAmbiguous verifies the gwerr.Ambiguous constructor
// produces the correct kind and that the error message includes the count and
// instance name.  This validates the error returned by resolveViaMongo when
// multiple documents match (requirement 4.13).
// Requirements: 4.13
func TestAmbiguousError_KindAmbiguous(t *testing.T) {
	err := gwerr.Ambiguous(
		"实例 %q 不唯一：找到 %d 条记录（project=%s env=%s）",
		"game1", 3, "h5", "h5dev2",
	)

	var gwErr *gwerr.GatewayError
	if !errors.As(err, &gwErr) {
		t.Fatalf("expected *gwerr.GatewayError, got %T", err)
	}
	if gwErr.Kind != gwerr.KindAmbiguous {
		t.Errorf("Kind = %v, want KindAmbiguous", gwErr.Kind)
	}
	if !strings.Contains(gwErr.Msg, "game1") {
		t.Errorf("error message %q does not contain instance name", gwErr.Msg)
	}
	if !strings.Contains(gwErr.Msg, "3") {
		t.Errorf("error message %q does not contain count", gwErr.Msg)
	}
}

// TestNotFoundError_KindNotFound verifies that gwerr.NotFound produces the
// correct kind with the instance name embedded in the message.
// Requirements: 4.10, 4.12
func TestNotFoundError_KindNotFound(t *testing.T) {
	err := gwerr.NotFound(
		"实例 %q 不存在（project=%s env=%s）", "actv1", "ice", "iceprod",
	)

	var gwErr *gwerr.GatewayError
	if !errors.As(err, &gwErr) {
		t.Fatalf("expected *gwerr.GatewayError, got %T", err)
	}
	if gwErr.Kind != gwerr.KindNotFound {
		t.Errorf("Kind = %v, want KindNotFound", gwErr.Kind)
	}
	if !strings.Contains(gwErr.Msg, "actv1") {
		t.Errorf("error message %q does not contain instance name", gwErr.Msg)
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// 9. Fake etcd-over-HTTP mock — exercises resolveViaEtcd JSON parsing path
//    without a real etcd cluster by bypassing getEtcdClient and injecting a
//    pre-built client pointed at a mock gRPC-less server.
//
//    Since clientv3 speaks gRPC we cannot use httptest.Server directly for
//    the full Resolve path.  Instead we test the sub-functions that parse the
//    etcd response to ensure credentials are stripped from output.
// ─────────────────────────────────────────────────────────────────────────────

// TestEtcdValue_CredentialsStripped_ViaParseDBURL exercises the exact code path
// used inside resolveViaEtcd to verify that DBURL credentials are discarded.
// Requirements: 4.13, 4.14
func TestEtcdValue_CredentialsStripped_ViaParseDBURL(t *testing.T) {
	// Simulate an EtcdValue as it would arrive from the etcd backend.
	val := EtcdValue{
		Name:  "game1",
		Addr:  "192.168.5.1:22001",
		Label: "test",
		DBURL: "admin:very_secret_password@192.168.5.1:27017/gs_game_1?authSource=admin",
	}

	hostPort, dbName, err := ParseDBURL(val.DBURL)
	if err != nil {
		t.Fatalf("ParseDBURL: %v", err)
	}

	pprofIP, err := ExtractHostIP(val.Addr)
	if err != nil {
		t.Fatalf("ExtractHostIP: %v", err)
	}

	// Simulate what resolveViaEtcd builds into ResolvedTarget.
	rt := ResolvedTarget{
		Workspace:     "h5dev2",
		Service:       "game",
		ServerID:      "1",
		ServerIDNum:   1,
		Backend:       BackendEtcd,
		MongoHostPort: hostPort,
		MongoDBName:   dbName,
		PprofHostIP:   pprofIP,
	}

	// Verify no credential appears in any string field.
	sensitiveSubstrings := []string{
		"very_secret_password",
		"admin:",          // user:pass form
		"admin:very",
	}

	v := reflect.ValueOf(rt)
	for i := 0; i < v.NumField(); i++ {
		f := v.Field(i)
		if f.Kind() != reflect.String {
			continue
		}
		for _, secret := range sensitiveSubstrings {
			if strings.Contains(f.String(), secret) {
				t.Errorf("ResolvedTarget.%s = %q contains credential %q",
					v.Type().Field(i).Name, f.String(), secret)
			}
		}
	}

	// Sanity-check that expected non-secret data survived.
	if rt.MongoHostPort != "192.168.5.1:27017" {
		t.Errorf("MongoHostPort = %q, want %q", rt.MongoHostPort, "192.168.5.1:27017")
	}
	if rt.MongoDBName != "gs_game_1" {
		t.Errorf("MongoDBName = %q, want %q", rt.MongoDBName, "gs_game_1")
	}
	if rt.PprofHostIP != "192.168.5.1" {
		t.Errorf("PprofHostIP = %q, want %q", rt.PprofHostIP, "192.168.5.1")
	}
}

// TestListInstances_EtcdCredentialsNotInOutput verifies that InstanceInfo
// items produced from an EtcdValue contain no credential material from the
// DBURL embedded in the etcd value.
// Requirements: 4.13
func TestListInstances_EtcdCredentialsNotInOutput(t *testing.T) {
	// Simulate listing: InstanceFromEtcdKey + EtcdValue.Label.
	prefix := "h5dev2/h5/gs/"
	key := prefix + "game/1"
	val := EtcdValue{
		Name:  "game1",
		Addr:  "10.0.0.1:22001",
		Label: "dev instance",
		// DBURL has embedded credentials — they must not appear in InstanceInfo.
		DBURL: "admin:dbsecret@10.0.0.1:27017/mydb",
	}

	instanceName, err := InstanceFromEtcdKey(prefix, key)
	if err != nil {
		t.Fatalf("InstanceFromEtcdKey: %v", err)
	}
	// val.DBURL has embedded credentials — verify they don't appear in the group output.
	_ = val

	info := InstanceGroup{
		Type: instanceName,
		IDs:  []int{},
	}

	// Confirm no DBURL credential leaks into InstanceGroup.
	if strings.Contains(info.Type, "dbsecret") {
		t.Errorf("InstanceGroup.Type contains DBURL credential: %+v", info)
	}
	if strings.Contains(info.Type, "admin:") {
		t.Errorf("InstanceGroup.Type contains username:password material: %+v", info)
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers for integration tests
// ─────────────────────────────────────────────────────────────────────────────

// parseMongoURIHostPort extracts host and port (as int) from a mongo URI of the
// form mongodb://user:pass@host:port/db or mongodb://host:port/db.
func parseMongoURIHostPort(t *testing.T, uri string) (string, int) {
	t.Helper()
	// Strip "mongodb://" prefix.
	s := strings.TrimPrefix(uri, "mongodb://")
	// Strip credentials if present.
	if idx := strings.LastIndex(s, "@"); idx >= 0 {
		s = s[idx+1:]
	}
	// Strip database path.
	if idx := strings.Index(s, "/"); idx >= 0 {
		s = s[:idx]
	}
	// s is now "host:port".
	var host string
	var port int
	if _, err := fmt.Sscanf(s, "%s", &host); err != nil {
		t.Fatalf("cannot parse mongo URI %q: %v", uri, err)
	}
	colonIdx := strings.LastIndex(s, ":")
	if colonIdx < 0 {
		t.Fatalf("no port in mongo URI %q", uri)
	}
	host = s[:colonIdx]
	portStr := s[colonIdx+1:]
	if _, err := fmt.Sscanf(portStr, "%d", &port); err != nil {
		t.Fatalf("cannot parse port in mongo URI %q: %v", uri, err)
	}
	return host, port
}

// ─────────────────────────────────────────────────────────────────────────────
// 10. Sanity: Resolver struct type checks
// ─────────────────────────────────────────────────────────────────────────────

// TestResolver_NotHTTPClient is a smoke-test verifying that the Resolver struct
// does not accidentally embed a net/http.Client (which would indicate a
// structural regression).
func TestResolver_NotHTTPClient(t *testing.T) {
	rt := reflect.TypeOf(Resolver{})
	for i := 0; i < rt.NumField(); i++ {
		ft := rt.Field(i).Type
		if ft == reflect.TypeOf((*http.Client)(nil)) || ft == reflect.TypeOf(http.Client{}) {
			t.Errorf("Resolver field %q is http.Client — unexpected", rt.Field(i).Name)
		}
	}
}
