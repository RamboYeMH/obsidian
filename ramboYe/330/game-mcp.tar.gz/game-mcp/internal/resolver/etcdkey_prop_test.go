package resolver

// Feature: pprof-redis-proxy, Property 2: etcd key 模板与实例名往返

import (
	"strings"
	"testing"

	"pgregory.net/rapid"
)

// segmentGen generates a non-empty alphanumeric string suitable for use as a
// project, env, service, or serverid segment in an etcd key.  The character set
// deliberately excludes "/" to avoid polluting key structure.
var segmentGen = rapid.StringMatching(`[a-zA-Z0-9]{1,20}`)

// TestProperty2_EtcdKeyRoundTrip verifies Property 2:
//
//  1. BuildEtcdKey produces a key that matches the documented template.
//  2. The instance name recovered via InstanceFromEtcdKey equals service+serverid.
//
// Both the namespace=true and namespace=false variants are exercised.
//
// Validates: Requirements 4.5, 4.6, 8.2, 8.3
// ≥100 iterations (rapid default).
func TestProperty2_EtcdKeyRoundTrip(t *testing.T) {
	t.Run("namespace_true", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			project := segmentGen.Draw(t, "project")
			env := segmentGen.Draw(t, "env")
			service := segmentGen.Draw(t, "service")
			serverid := segmentGen.Draw(t, "serverid")

			// Build the key and the corresponding prefix.
			key := BuildEtcdKey(project, env, service, serverid, true)
			prefix := BuildEtcdPrefix(project, env, true)

			// 1. Key must start with the expected prefix.
			if !strings.HasPrefix(key, prefix) {
				t.Fatalf("key %q does not start with prefix %q", key, prefix)
			}

			// 2. Key template: {env}/{project}/gs/{service}/{serverid}
			expected := env + "/" + project + "/gs/" + service + "/" + serverid
			if key != expected {
				t.Fatalf("key %q != expected %q", key, expected)
			}

			// 3. Round-trip: instance name recovered from key == service+serverid.
			instance, err := InstanceFromEtcdKey(prefix, key)
			if err != nil {
				t.Fatalf("InstanceFromEtcdKey(%q, %q) returned error: %v", prefix, key, err)
			}
			want := service + serverid
			if instance != want {
				t.Fatalf("instance name %q != expected %q", instance, want)
			}
		})
	})

	t.Run("namespace_false", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			project := segmentGen.Draw(t, "project")
			env := segmentGen.Draw(t, "env") // present in inputs but not used when namespace=false
			service := segmentGen.Draw(t, "service")
			serverid := segmentGen.Draw(t, "serverid")

			// Build the key and the corresponding prefix.
			key := BuildEtcdKey(project, env, service, serverid, false)
			prefix := BuildEtcdPrefix(project, env, false)

			// 1. Key must start with the expected prefix.
			if !strings.HasPrefix(key, prefix) {
				t.Fatalf("key %q does not start with prefix %q", key, prefix)
			}

			// 2. Key template: {project}/gs/{service}/{serverid}
			expected := project + "/gs/" + service + "/" + serverid
			if key != expected {
				t.Fatalf("key %q != expected %q", key, expected)
			}

			// 3. Round-trip: instance name recovered from key == service+serverid.
			instance, err := InstanceFromEtcdKey(prefix, key)
			if err != nil {
				t.Fatalf("InstanceFromEtcdKey(%q, %q) returned error: %v", prefix, key, err)
			}
			want := service + serverid
			if instance != want {
				t.Fatalf("instance name %q != expected %q", instance, want)
			}
		})
	})
}
