package resolver

import "strings"

// BuildDBName derives the MongoDB database name from a service name, server ID,
// and CSV field, applying the same three-rule logic used in the original mgq CLI:
//
//  1. gdconfig → "gs_conf_" + csv
//  2. global / webserver / door → process name itself when id=="1", else process + "_" + id
//  3. default → "gs_" + process + "_" + id
//
// Requirements: 4.9, 4.11
func BuildDBName(process, id, csv string) string {
	switch process {
	case "gdconfig":
		return "gs_conf_" + csv
	case "global", "webserver", "door":
		if id == "1" {
			return process
		}
		return process + "_" + id
	default:
		return "gs_" + process + "_" + id
	}
}

// ApplyDBNameGroup applies the db_name_group prefix rule:
//   - dbNameGroup=true  → env + "_" + db
//   - dbNameGroup=false → db (unchanged)
//
// Requirements: 4.9, 4.11
func ApplyDBNameGroup(env, db string, dbNameGroup bool) string {
	if dbNameGroup {
		return env + "_" + db
	}
	return db
}

// HasDBNameGroup reports whether the given process launch-param string contains
// the flag "--dbnameGroup 1".
//
// In the mongo fallback model, each service-type has its own param field in
// processes.vars (e.g. gameparam, gateparam, crossparam).  The caller reads
// the relevant field and passes it here to determine whether the db_name_group
// prefix should be applied — the same role that the etcd cluster's
// db_name_group flag plays in the etcd model.
//
// The check is case-insensitive on the flag name and requires the value to be
// exactly "1".  Any of the following forms are recognised:
//
//	--dbnameGroup 1
//	--dbnamegroup 1   (case-insensitive)
func HasDBNameGroup(param string) bool {
	lower := strings.ToLower(param)
	idx := strings.Index(lower, "--dbnamegroup")
	if idx < 0 {
		return false
	}
	// Skip past the flag name and any whitespace.
	rest := strings.TrimLeft(param[idx+len("--dbnamegroup"):], " \t")
	// Value is "1" if the next token starts with "1" and is either the end of
	// the string or followed by a space/tab (i.e. not "--dbnamegroup 10").
	return strings.HasPrefix(rest, "1") &&
		(len(rest) == 1 || rest[1] == ' ' || rest[1] == '\t')
}
