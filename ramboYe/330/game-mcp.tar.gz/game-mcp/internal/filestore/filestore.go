// Package filestore provides a TTL-based temporary file store with an HTTP
// download handler. Files are stored under /tmp/game-mcp-files/ and expire
// after 5 minutes. The UUID file ID serves as an unguessable capability
// credential, so the /files/ route does not require Bearer auth.
package filestore

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"sync"
	"time"
)

const (
	storeDir      = "/tmp/game-mcp-files"
	ttl           = 5 * time.Minute
	sweepInterval = time.Minute
)

type entry struct {
	path    string
	expires time.Time
}

// Store is a TTL-based temporary file store backed by the local filesystem.
// Create one with New and mount its ServeHTTP at /files/.
type Store struct {
	mu      sync.Mutex
	entries map[string]entry
}

// New creates a Store, ensures the storage directory exists, and starts the
// background sweep goroutine that removes expired files every minute.
func New() *Store {
	_ = os.MkdirAll(storeDir, 0o700)
	s := &Store{entries: make(map[string]entry)}
	go s.sweep()
	return s
}

// Save writes data to a new temporary file and returns the file ID.
// The file expires after 5 minutes and is deleted by the sweep goroutine.
func (s *Store) Save(data []byte) (string, error) {
	id, err := newID()
	if err != nil {
		return "", err
	}
	path := filepath.Join(storeDir, id+".prof")
	if err := os.WriteFile(path, data, 0o600); err != nil {
		return "", fmt.Errorf("filestore: write %s: %w", path, err)
	}
	s.mu.Lock()
	s.entries[id] = entry{path: path, expires: time.Now().Add(ttl)}
	s.mu.Unlock()
	return id, nil
}

// ServeHTTP serves files by ID. Mount at /files/ — the last path segment is
// treated as the file ID (with or without the .prof extension).
// Returns 404 for unknown or expired IDs.
func (s *Store) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	id := filepath.Base(r.URL.Path)
	// Strip .prof extension if present.
	if len(id) > 5 && id[len(id)-5:] == ".prof" {
		id = id[:len(id)-5]
	}

	s.mu.Lock()
	e, ok := s.entries[id]
	s.mu.Unlock()

	if !ok || time.Now().After(e.expires) {
		http.Error(w, "not found or expired", http.StatusNotFound)
		return
	}

	f, err := os.Open(e.path)
	if err != nil {
		http.Error(w, "file unavailable", http.StatusNotFound)
		return
	}
	defer f.Close()

	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("Content-Disposition",
		fmt.Sprintf(`attachment; filename="%s.prof"`, id))
	_, _ = io.Copy(w, f)
}

func (s *Store) sweep() {
	ticker := time.NewTicker(sweepInterval)
	defer ticker.Stop()
	for range ticker.C {
		now := time.Now()
		s.mu.Lock()
		for id, e := range s.entries {
			if now.After(e.expires) {
				_ = os.Remove(e.path)
				delete(s.entries, id)
			}
		}
		s.mu.Unlock()
	}
}

func newID() (string, error) {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "", fmt.Errorf("filestore: generate ID: %w", err)
	}
	return hex.EncodeToString(b), nil
}
