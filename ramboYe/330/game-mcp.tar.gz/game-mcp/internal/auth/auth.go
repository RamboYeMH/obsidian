package auth

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"

	"game-mcp/internal/accesslog"
	"game-mcp/internal/config"
)

// contextKey is the unexported type used as context key to avoid collisions.
type contextKey int

const tokenNameKey contextKey = iota

// TokenNameFromContext returns the token name (audit label) stored by Middleware,
// or empty string when not present.
func TokenNameFromContext(ctx context.Context) string {
	if v, ok := ctx.Value(tokenNameKey).(string); ok {
		return v
	}
	return ""
}

// extractBearer extracts the token value from an "Authorization: Bearer <token>" header.
// Returns empty string if the header is absent or does not start with "Bearer ".
func extractBearer(authHeader string) string {
	const prefix = "Bearer "
	if !strings.HasPrefix(authHeader, prefix) {
		return ""
	}
	return authHeader[len(prefix):]
}

// writeAuthError writes an HTTP 401 response with a JSON error body.
func writeAuthError(w http.ResponseWriter) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusUnauthorized)
	// Ignore write error: nothing meaningful can be done after headers are sent.
	_ = json.NewEncoder(w).Encode(map[string]string{"error": "authentication required"})
}

// Middleware returns an HTTP middleware that enforces Bearer token authentication
// against the provided token whitelist. Only the token value is checked; the Name
// field of each TokenEntry does not participate in authentication (Requirements 2.3, 2.4).
//
// On success the token's Name (audit label) is stored in the request context and
// can be retrieved with TokenNameFromContext — used by the access-log middleware.
//
// Requests that are missing a valid token receive a 401 response and never reach
// the wrapped handler, ensuring no tool dispatch or intranet access occurs
// (Requirements 2.5).
func Middleware(tokens []config.TokenEntry) func(http.Handler) http.Handler {
	// Index by token value → name; name is for audit only (Requirement 2.3).
	type entry struct{ name string }
	allow := make(map[string]entry, len(tokens))
	for _, t := range tokens {
		allow[t.Token] = entry{name: t.Name}
	}

	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			tok := extractBearer(r.Header.Get("Authorization")) // Requirement 2.2
			e, ok := allow[tok]
			if tok == "" || !ok {
				writeAuthError(w) // 401, does not reach tool dispatch (Requirement 2.5)
				return
			}
			// Write the audit name into the accesslog fields so the log
			// middleware can read it after the full handler chain completes.
			accesslog.SetUser(r.Context(), e.name)
			// Also store in context for any downstream code that reads it.
			ctx := context.WithValue(r.Context(), tokenNameKey, e.name)
			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}
