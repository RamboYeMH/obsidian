// Package auth provides the Bearer token authentication middleware
// for the MCP Gateway HTTP server.
package auth
