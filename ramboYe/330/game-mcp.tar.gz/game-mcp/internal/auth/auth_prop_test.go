package auth

// Feature: pprof-redis-proxy, Property 6: 鉴权仅取决于 token 值且与 name 无关
//
// Validates: Requirements 2.3, 2.4

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"pgregory.net/rapid"

	"game-mcp/internal/config"
)

// tokenEntryGen generates a random TokenEntry with an alphanumeric name and
// token value, both non-empty.
var tokenEntryGen = rapid.Custom(func(t *rapid.T) config.TokenEntry {
	return config.TokenEntry{
		Name:  rapid.StringMatching(`[a-zA-Z0-9@._-]{1,30}`).Draw(t, "name"),
		Token: rapid.StringMatching(`[a-zA-Z0-9_-]{8,40}`).Draw(t, "token"),
	}
})

// tokenAllowlistGen generates a random non-empty slice of TokenEntry values
// (1..8 entries).
var tokenAllowlistGen = rapid.Custom(func(t *rapid.T) []config.TokenEntry {
	n := rapid.IntRange(1, 8).Draw(t, "n")
	entries := make([]config.TokenEntry, n)
	for i := range entries {
		entries[i] = tokenEntryGen.Draw(t, "entry")
	}
	return entries
})

// callMiddleware fires a single request through the auth middleware and returns
// true if the downstream handler was reached (auth passed) or false (401 / not reached).
func callMiddleware(tokens []config.TokenEntry, bearer string) bool {
	reached := false
	next := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		reached = true
		w.WriteHeader(http.StatusOK)
	})

	handler := Middleware(tokens)(next)

	req := httptest.NewRequest(http.MethodGet, "/", nil)
	if bearer != "" {
		req.Header.Set("Authorization", "Bearer "+bearer)
	}
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, req)
	return reached
}

// isTokenInAllowlist returns true iff tok matches any entry's Token field —
// the oracle that mirrors the expected behavior of Middleware.
func isTokenInAllowlist(tokens []config.TokenEntry, tok string) bool {
	for _, e := range tokens {
		if e.Token == tok {
			return true
		}
	}
	return false
}

// TestAuthMiddleware_Property6_TokenValueOnlyDeterminesAuth is the main
// property test.  It checks three related properties in a single rapid.Check:
//
//  1. Auth passes if and only if the submitted token matches some entry's Token
//     field value (name is irrelevant).
//  2. Mutating any Name field in the allowlist does not change the auth outcome
//     for the same token.
//  3. An empty/absent bearer token is always rejected.
//
// ≥100 iterations (rapid default = 100).
func TestAuthMiddleware_Property6_TokenValueOnlyDeterminesAuth(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		// ── Inputs ────────────────────────────────────────────────────────────
		allowlist := tokenAllowlistGen.Draw(t, "allowlist")

		// The token under test may or may not be in the allowlist.
		candidateToken := rapid.StringMatching(`[a-zA-Z0-9_-]{8,40}`).Draw(t, "candidateToken")

		// ── Property 6a: auth passes iff token is in the allowlist ────────────
		expectedPass := isTokenInAllowlist(allowlist, candidateToken)
		gotPass := callMiddleware(allowlist, candidateToken)

		if gotPass != expectedPass {
			t.Fatalf("Property 6a failed: token=%q, expectedPass=%v, gotPass=%v\n"+
				"allowlist tokens: %v",
				candidateToken, expectedPass, gotPass, tokenValues(allowlist))
		}

		// ── Property 6b: mutating every Name does not change the outcome ──────
		// Build a copy of the allowlist with all Names replaced by random values.
		renamed := make([]config.TokenEntry, len(allowlist))
		for i, e := range allowlist {
			renamed[i] = config.TokenEntry{
				Name:  rapid.StringMatching(`[a-zA-Z0-9@._-]{1,30}`).Draw(t, "newName"),
				Token: e.Token, // Token value unchanged
			}
		}

		gotPassAfterRename := callMiddleware(renamed, candidateToken)
		if gotPassAfterRename != expectedPass {
			t.Fatalf("Property 6b failed: renaming names changed auth outcome\n"+
				"token=%q expectedPass=%v, gotPassOriginal=%v, gotPassAfterRename=%v",
				candidateToken, expectedPass, gotPass, gotPassAfterRename)
		}
	})
}

// TestAuthMiddleware_Property6_EmptyTokenAlwaysRejected verifies that a
// request with an empty or absent Authorization header is always rejected,
// regardless of the allowlist contents.
//
// ≥100 iterations.
func TestAuthMiddleware_Property6_EmptyTokenAlwaysRejected(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		allowlist := tokenAllowlistGen.Draw(t, "allowlist")

		// No bearer token supplied (empty string → no Authorization header).
		gotPass := callMiddleware(allowlist, "")
		if gotPass {
			t.Fatalf("empty/absent bearer token must always be rejected, but middleware passed the request\n"+
				"allowlist tokens: %v", tokenValues(allowlist))
		}
	})
}

// TestAuthMiddleware_Property6_ExactTokenMatchRequired verifies that a token
// that is a substring (prefix or suffix) of an allowlist entry is not accepted.
//
// ≥100 iterations.
func TestAuthMiddleware_Property6_ExactTokenMatchRequired(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		// Generate an allowlist entry whose token is long enough to truncate.
		entry := config.TokenEntry{
			Name:  rapid.StringMatching(`[a-zA-Z0-9@._-]{1,20}`).Draw(t, "name"),
			Token: rapid.StringMatching(`[a-zA-Z0-9_-]{12,40}`).Draw(t, "token"),
		}
		allowlist := []config.TokenEntry{entry}

		// A strict prefix (all but the last char) must NOT pass.
		prefix := entry.Token[:len(entry.Token)-1]
		gotPassPrefix := callMiddleware(allowlist, prefix)
		if gotPassPrefix {
			t.Fatalf("Property 6c: prefix %q of token %q must not be accepted",
				prefix, entry.Token)
		}

		// A strict suffix (all but the first char) must NOT pass.
		suffix := entry.Token[1:]
		gotPassSuffix := callMiddleware(allowlist, suffix)
		if gotPassSuffix {
			t.Fatalf("Property 6c: suffix %q of token %q must not be accepted",
				suffix, entry.Token)
		}
	})
}

// TestAuthMiddleware_Property6_ValidTokenAlwaysPasses verifies that when a
// known-good token (drawn from the allowlist) is submitted, auth always passes,
// regardless of what Names are set.
//
// ≥100 iterations.
func TestAuthMiddleware_Property6_ValidTokenAlwaysPasses(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		allowlist := tokenAllowlistGen.Draw(t, "allowlist")

		// Pick one of the allowlist entries at random and use its Token.
		idx := rapid.IntRange(0, len(allowlist)-1).Draw(t, "idx")
		goodToken := allowlist[idx].Token

		gotPass := callMiddleware(allowlist, goodToken)
		if !gotPass {
			t.Fatalf("valid token %q must always pass, but middleware rejected the request\n"+
				"allowlist tokens: %v", goodToken, tokenValues(allowlist))
		}
	})
}

// tokenValues is a helper that extracts just the Token strings from an
// allowlist for use in failure messages.
func tokenValues(entries []config.TokenEntry) []string {
	vals := make([]string, len(entries))
	for i, e := range entries {
		vals[i] = e.Token
	}
	return vals
}
