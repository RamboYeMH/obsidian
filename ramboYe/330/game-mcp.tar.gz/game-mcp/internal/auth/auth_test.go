package auth

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"game-mcp/internal/config"
)

// helper: build a Middleware-wrapped handler that records whether it was called.
func newTestHandler(tokens []config.TokenEntry) (http.Handler, *bool) {
	called := false
	downstream := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		called = true
		w.WriteHeader(http.StatusOK)
	})
	return Middleware(tokens)(downstream), &called
}

// validTokens is a small whitelist used across the tests.
var validTokens = []config.TokenEntry{
	{Name: "alice", Token: "secret-token-alice"},
	{Name: "bob", Token: "secret-token-bob"},
}

// --- 1. Missing token (no Authorization header) → 401, downstream NOT called ---

func TestMissingTokenReturns401(t *testing.T) {
	handler, called := newTestHandler(validTokens)

	req := httptest.NewRequest(http.MethodGet, "/", nil)
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, req)

	if rr.Code != http.StatusUnauthorized {
		t.Errorf("expected 401, got %d", rr.Code)
	}
	if *called {
		t.Error("downstream handler must NOT be called when token is missing")
	}
}

func TestMissingTokenResponseBody(t *testing.T) {
	handler, _ := newTestHandler(validTokens)

	req := httptest.NewRequest(http.MethodGet, "/", nil)
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, req)

	var body map[string]string
	if err := json.NewDecoder(rr.Body).Decode(&body); err != nil {
		t.Fatalf("response body is not valid JSON: %v", err)
	}
	if _, ok := body["error"]; !ok {
		t.Error("expected JSON body with an 'error' key")
	}
}

// --- 2. Wrong token → 401, downstream NOT called ---

func TestWrongTokenReturns401(t *testing.T) {
	handler, called := newTestHandler(validTokens)

	req := httptest.NewRequest(http.MethodGet, "/", nil)
	req.Header.Set("Authorization", "Bearer wrong-token")
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, req)

	if rr.Code != http.StatusUnauthorized {
		t.Errorf("expected 401, got %d", rr.Code)
	}
	if *called {
		t.Error("downstream handler must NOT be called for a wrong token")
	}
}

func TestEmptyTokenValueReturns401(t *testing.T) {
	handler, called := newTestHandler(validTokens)

	req := httptest.NewRequest(http.MethodGet, "/", nil)
	req.Header.Set("Authorization", "Bearer ")
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, req)

	if rr.Code != http.StatusUnauthorized {
		t.Errorf("expected 401, got %d", rr.Code)
	}
	if *called {
		t.Error("downstream handler must NOT be called for an empty token value")
	}
}

// --- 3. Correct token → request passes through to downstream handler ---

func TestCorrectTokenPassesThrough(t *testing.T) {
	for _, entry := range validTokens {
		t.Run(entry.Name, func(t *testing.T) {
			handler, called := newTestHandler(validTokens)

			req := httptest.NewRequest(http.MethodGet, "/", nil)
			req.Header.Set("Authorization", "Bearer "+entry.Token)
			rr := httptest.NewRecorder()
			handler.ServeHTTP(rr, req)

			if rr.Code != http.StatusOK {
				t.Errorf("expected 200, got %d", rr.Code)
			}
			if !*called {
				t.Error("downstream handler MUST be called for a correct token")
			}
		})
	}
}

func TestCorrectTokenWithEmptyTokenList(t *testing.T) {
	// An empty whitelist should reject every token, including a well-formed one.
	handler, called := newTestHandler([]config.TokenEntry{})

	req := httptest.NewRequest(http.MethodGet, "/", nil)
	req.Header.Set("Authorization", "Bearer secret-token-alice")
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, req)

	if rr.Code != http.StatusUnauthorized {
		t.Errorf("expected 401 with empty whitelist, got %d", rr.Code)
	}
	if *called {
		t.Error("downstream handler must NOT be called when whitelist is empty")
	}
}

// --- 4. Bearer prefix handling (must have "Bearer " prefix) ---

func TestMissingBearerPrefixReturns401(t *testing.T) {
	handler, called := newTestHandler(validTokens)

	// Supply the correct token value but without the "Bearer " prefix.
	req := httptest.NewRequest(http.MethodGet, "/", nil)
	req.Header.Set("Authorization", "secret-token-alice")
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, req)

	if rr.Code != http.StatusUnauthorized {
		t.Errorf("expected 401 when 'Bearer ' prefix is absent, got %d", rr.Code)
	}
	if *called {
		t.Error("downstream handler must NOT be called without 'Bearer ' prefix")
	}
}

func TestWrongSchemeReturns401(t *testing.T) {
	cases := []struct {
		name   string
		header string
	}{
		{"Token scheme", "Token secret-token-alice"},
		{"Basic scheme", "Basic secret-token-alice"},
		{"lowercase bearer", "bearer secret-token-alice"},
		{"BEARER uppercase", "BEARER secret-token-alice"},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			handler, called := newTestHandler(validTokens)

			req := httptest.NewRequest(http.MethodGet, "/", nil)
			req.Header.Set("Authorization", tc.header)
			rr := httptest.NewRecorder()
			handler.ServeHTTP(rr, req)

			if rr.Code != http.StatusUnauthorized {
				t.Errorf("expected 401 for header %q, got %d", tc.header, rr.Code)
			}
			if *called {
				t.Errorf("downstream must NOT be called for header %q", tc.header)
			}
		})
	}
}
