package secret

// Feature: pprof-redis-proxy, Property 5: DBURL 密码掩码绝不泄露明文
//
// Validates: Requirements 4.15, 9.7, 9.9, 11.4

import (
	"fmt"
	"strings"
	"testing"

	"pgregory.net/rapid"
)

// componentGen generates a non-empty alphanumeric string (1-20 chars) that is
// safe to embed in any position of a user:pass@host:port/db URL — it contains
// no ":", "@", "/", "?", "#", or whitespace.
var componentGen = rapid.StringMatching(`[a-zA-Z0-9]{1,20}`)

// portGen generates a numeric string in the range 1..65535.
func portGen(t *rapid.T, label string) string {
	return fmt.Sprintf("%d", rapid.IntRange(1, 65535).Draw(t, label))
}

// TestMaskDBURL_Property5_PasswordNeverLeaked verifies that for any randomly
// generated DBURL of the form <user>:<pass>@<host>:<port>/<db>:
//
//  1. The raw password is NOT present in the masked output.
//  2. The "****" sentinel IS present.
//  3. Non-sensitive components (user, host, db) ARE preserved.
//
// ≥100 iterations (rapid default).
func TestMaskDBURL_Property5_PasswordNeverLeaked(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		user := componentGen.Draw(t, "user")
		pass := componentGen.Draw(t, "pass")
		host := componentGen.Draw(t, "host")
		port := portGen(t, "port")
		db := componentGen.Draw(t, "db")

		dburl := fmt.Sprintf("%s:%s@%s:%s/%s", user, pass, host, port, db)
		result := MaskDBURL(dburl)

		// 5a: the credential substring "user:pass@" must NOT appear in the output.
		// We check for the exact credential form rather than just "pass" alone,
		// because the password value may legitimately equal the username or host.
		plainCred := fmt.Sprintf("%s:%s@", user, pass)
		if strings.Contains(result, plainCred) {
			t.Fatalf("MaskDBURL leaked plain-text credential %q in output %q (input: %q)",
				plainCred, result, dburl)
		}

		// 5b: the masked credential "user:****@" must be present.
		maskedCred := fmt.Sprintf("%s:****@", user)
		if !strings.Contains(result, maskedCred) {
			t.Fatalf("MaskDBURL missing masked credential %q in output %q (input: %q)",
				maskedCred, result, dburl)
		}

		// 5c: non-sensitive fields (host, db, port) must be retained.
		if !strings.Contains(result, host) {
			t.Fatalf("MaskDBURL dropped host %q from output %q (input: %q)",
				host, result, dburl)
		}
		if !strings.Contains(result, db) {
			t.Fatalf("MaskDBURL dropped db %q from output %q (input: %q)",
				db, result, dburl)
		}
	})
}

// TestMaskDBURL_Property5_NoCredentialsUnchanged verifies that a URL without
// embedded credentials is returned unchanged by MaskDBURL.
//
// ≥100 iterations (rapid default).
func TestMaskDBURL_Property5_NoCredentialsUnchanged(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		host := componentGen.Draw(t, "host")
		port := portGen(t, "port")
		db := componentGen.Draw(t, "db")

		// host:port/db — no "user:pass@" prefix.
		dburl := fmt.Sprintf("%s:%s/%s", host, port, db)
		result := MaskDBURL(dburl)

		if result != dburl {
			t.Fatalf("MaskDBURL altered a credential-free URL: got %q, want %q", result, dburl)
		}
	})
}

// TestMaskDBURL_Property5_IdempotentMasking verifies that applying MaskDBURL
// twice yields the same result as once (idempotency).
//
// ≥100 iterations (rapid default).
func TestMaskDBURL_Property5_IdempotentMasking(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		user := componentGen.Draw(t, "user")
		pass := componentGen.Draw(t, "pass")
		host := componentGen.Draw(t, "host")
		port := portGen(t, "port")
		db := componentGen.Draw(t, "db")

		dburl := fmt.Sprintf("%s:%s@%s:%s/%s", user, pass, host, port, db)
		once := MaskDBURL(dburl)
		twice := MaskDBURL(once)

		if once != twice {
			t.Fatalf("MaskDBURL is not idempotent: first=%q second=%q (input: %q)",
				once, twice, dburl)
		}
	})
}
