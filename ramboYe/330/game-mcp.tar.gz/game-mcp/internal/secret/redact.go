package secret

import (
	"fmt"
	"regexp"
)

// Pre-compiled redaction patterns. All patterns are compiled at package init;
// if any compilation fails the process panics immediately rather than silently
// operating with incomplete protection.

var (
	// connStringRe matches "user:password@host" in connection strings.
	// This mirrors the MaskDBURL pattern so both use consistent logic.
	//
	// The user part must not be preceded by "/" (rules out "://") and must
	// not itself contain "://" so that scheme separators are not matched.
	//   (?:^|[\s,(\[{])  – anchored to a word boundary-ish position, OR
	//   we use a negative lookbehind via the "not preceded by /" approach:
	//   the user part is \w+ (word chars only) so "mongodb" in "mongodb://"
	//   would match BUT the separator after it is "//" not ":", so the colon
	//   rule filters it out naturally. We additionally require that the
	//   character before the match is NOT "/" to reject "://user" patterns.
	//
	// Capture group 1: user (word chars only, no slashes)
	// Capture group 2: password (non-empty, no "@" or whitespace)
	// Capture group 3: "@host" remainder
	//
	// We use a non-capturing prefix (?:^|[^/]) and put the whole thing in
	// a way that avoids the "://" false-positive: require that the char
	// immediately before "user" is NOT "/".
	connStringRe = regexp.MustCompile(`(?i)(?:^|([^/]))(\w+):([^@:/\s]{1,256})(@[^\s/?,]+)`)

	// flagEqRe matches --flag=VALUE or -f=VALUE for sensitive flag names.
	// Capture group 1: the flag portion (e.g. "--password=")
	// Capture group 2: the value
	// Covers both bare names (--password) and underscore-prefixed variants
	// (--redis_pass, --db_password, etc.).
	// Value terminator: whitespace, NUL byte (\x00, used in /proc/PID/cmdline),
	// or end of string.
	flagEqRe = regexp.MustCompile(
		`(?i)((?:--(?:\w+_)?(?:pass(?:word)?|token|secret|key)|-p)=)([^\s\x00]+)`,
	)

	// flagSpaceRe matches "--flag VALUE" (space-separated OR NUL-separated) for
	// sensitive flags.  /proc/PID/cmdline uses NUL bytes (\x00) as argument
	// separators instead of spaces, so both \s and \x00 must be accepted as
	// the separator between the flag name and its value.
	// Capture group 1: the flag name with trailing separator(s)
	// Capture group 2: the value (non-whitespace, non-NUL token)
	// Covers both bare names (--password) and underscore-prefixed variants
	// (--redis_pass, --db_password, etc.).
	flagSpaceRe = regexp.MustCompile(
		`(?i)((?:--(?:\w+_)?(?:pass(?:word)?|token|secret|key)|-p)[\s\x00]+)([^\s\x00]+)`,
	)

	// queryParamRe matches "name=VALUE" for sensitive URL query parameters.
	// Capture group 1: the parameter name + "="
	// Capture group 2: the value (up to "&", whitespace, or end)
	queryParamRe = regexp.MustCompile(
		`(?i)((?:password|token|secret|key)=)([^&\s\x00]+)`,
	)
)

const redactedValue = "****"

// RedactCmdline applies three categories of redaction to raw cmdline bytes:
//
//  1. Connection-string credentials: "user:pass@host" → "user:****@host"
//  2. Sensitive flag values: --pass/--password/--token/--secret/--key and the
//     short form -p, supporting both "--flag=VALUE" and "--flag VALUE".
//  3. Sensitive URL query-parameter values: password=/token=/secret=/key=.
//
// All patterns are pre-compiled at package init so this function never
// returns a partial result due to compilation errors. If an unexpected
// panic is recovered during redaction (e.g. a regex engine bug), the
// function returns an error rather than the potentially un-redacted text.
func RedactCmdline(input []byte) (out []byte, err error) {
	// Recover from any unexpected runtime panic so we never return partially
	// redacted content.
	defer func() {
		if r := recover(); r != nil {
			out = nil
			err = fmt.Errorf("secret.RedactCmdline: unexpected error during redaction: %v", r)
		}
	}()

	result := input

	// Pass 1: connection-string credentials  user:pass@host → user:****@host
	// The regex has up to 4 capture groups: optional preceding non-"/" char,
	// user, password, @host. Replace keeping groups 1+2, mask group 3.
	result = connStringRe.ReplaceAll(result, []byte("${1}${2}:"+redactedValue+"${4}"))

	// Pass 2: --flag=VALUE  and  -p=VALUE
	result = flagEqRe.ReplaceAll(result, []byte("${1}"+redactedValue))

	// Pass 3: --flag VALUE  and  -p VALUE  (space-separated)
	result = flagSpaceRe.ReplaceAll(result, []byte("${1}"+redactedValue))

	// Pass 4: URL query parameters  name=VALUE
	result = queryParamRe.ReplaceAll(result, []byte("${1}"+redactedValue))

	return result, nil
}

// RedactCmdlineString is a convenience wrapper around RedactCmdline for
// callers that work with strings instead of byte slices.
func RedactCmdlineString(input string) (string, error) {
	out, err := RedactCmdline([]byte(input))
	if err != nil {
		return "", err
	}
	return string(out), nil
}
