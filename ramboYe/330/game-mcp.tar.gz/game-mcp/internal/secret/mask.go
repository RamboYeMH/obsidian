package secret

import "regexp"

// credentialRe matches the user:password@ portion of a connection string.
// Capture groups: (1) user, (2) password.
var credentialRe = regexp.MustCompile(`([^:@]+):([^@]+)@`)

// MaskDBURL replaces the password portion of a MongoDB (or similar) connection
// string with "****", preserving the username, host, port, database name, and
// any query parameters.
//
// Examples:
//
//	"user:secret@host:27017/db?authSource=admin" → "user:****@host:27017/db?authSource=admin"
//	"host:27017/db"                              → "host:27017/db"  (no credentials, unchanged)
//	""                                           → ""
func MaskDBURL(dburl string) string {
	return credentialRe.ReplaceAllStringFunc(dburl, func(match string) string {
		// match is the full "user:password@" substring.
		// Re-run the regex on the match to extract the two capture groups.
		sub := credentialRe.FindStringSubmatch(match)
		if sub == nil {
			return match
		}
		user := sub[1]
		// Replace only the password with "****", keep the "@" suffix.
		return user + ":****@"
	})
}
