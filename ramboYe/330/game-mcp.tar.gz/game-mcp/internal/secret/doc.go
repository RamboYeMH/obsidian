// Package secret provides unified credential masking primitives:
// DBURL password masking and cmdline sensitive-value redaction.
package secret
