package secret

import (
	"strings"
	"testing"
)

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

func mustRedact(t *testing.T, input string) string {
	t.Helper()
	out, err := RedactCmdlineString(input)
	if err != nil {
		t.Fatalf("RedactCmdlineString(%q) returned unexpected error: %v", input, err)
	}
	return out
}

func assertContains(t *testing.T, got, want, label string) {
	t.Helper()
	if !strings.Contains(got, want) {
		t.Errorf("%s: expected output to contain %q, got: %q", label, want, got)
	}
}

func assertNotContains(t *testing.T, got, secret, label string) {
	t.Helper()
	if strings.Contains(got, secret) {
		t.Errorf("%s: output must not contain secret %q, got: %q", label, secret, got)
	}
}

// ---------------------------------------------------------------------------
// 1. Connection-string embedded credentials
// ---------------------------------------------------------------------------

func TestRedactCmdline_ConnString_TypicalUserPass(t *testing.T) {
	out := mustRedact(t, "user:s3cr3t@host:27017")
	assertNotContains(t, out, "s3cr3t", "conn-string basic")
	assertContains(t, out, "user:", "conn-string user preserved")
	assertContains(t, out, "@host:27017", "conn-string host preserved")
}

func TestRedactCmdline_ConnString_PreservesUser(t *testing.T) {
	out := mustRedact(t, "admin:hunter2@mongo.internal:27017/mydb")
	assertNotContains(t, out, "hunter2", "conn-string user+db")
	assertContains(t, out, "admin:", "user still present")
	assertContains(t, out, "@mongo.internal:27017", "host:port still present")
}

func TestRedactCmdline_ConnString_NoCredentials_Unchanged(t *testing.T) {
	in := "host:27017/db"
	out := mustRedact(t, in)
	if out != in {
		t.Errorf("no-credentials input should be unchanged; got %q", out)
	}
}

func TestRedactCmdline_ConnString_SpecialCharsInPassword(t *testing.T) {
	out := mustRedact(t, "user:p@ss!w0rd@host:5432")
	// password contains "@" so only the first segment is redacted
	assertNotContains(t, out, "p@ss!w0rd", "special-char password")
}

func TestRedactCmdline_ConnString_InsideFlag(t *testing.T) {
	// Embedded in a --uri flag
	out := mustRedact(t, "--uri user:topSecret@db.example.com/mydb")
	assertNotContains(t, out, "topSecret", "conn-string inside flag")
}

func TestRedactCmdline_ConnString_SchemeNotRedacted(t *testing.T) {
	// "mongodb://" must NOT be treated as user:pass@ – the "mongodb" part
	// is preceded by a "/" so the regex must leave it alone.
	out := mustRedact(t, "mongodb://host:27017/db")
	assertContains(t, out, "mongodb://", "scheme must survive redaction")
}

// ---------------------------------------------------------------------------
// 2. Sensitive flag values – --flag=value and --flag value forms
// ---------------------------------------------------------------------------

// 2a. --flag=value form

func TestRedactCmdline_Flag_PasswordEq(t *testing.T) {
	out := mustRedact(t, "--password=mySecret123")
	assertNotContains(t, out, "mySecret123", "--password=")
	assertContains(t, out, "--password=", "flag name preserved")
	assertContains(t, out, "****", "placeholder present")
}

func TestRedactCmdline_Flag_PassEq(t *testing.T) {
	out := mustRedact(t, "--pass=abc")
	assertNotContains(t, out, "abc", "--pass=")
	assertContains(t, out, "--pass=****", "--pass= placeholder")
}

func TestRedactCmdline_Flag_TokenEq(t *testing.T) {
	out := mustRedact(t, "--token=tok_live_xyz")
	assertNotContains(t, out, "tok_live_xyz", "--token=")
}

func TestRedactCmdline_Flag_SecretEq(t *testing.T) {
	out := mustRedact(t, "--secret=s3cr3t")
	assertNotContains(t, out, "s3cr3t", "--secret=")
}

func TestRedactCmdline_Flag_KeyEq(t *testing.T) {
	out := mustRedact(t, "--key=apiKey007")
	assertNotContains(t, out, "apiKey007", "--key=")
}

func TestRedactCmdline_Flag_ShortPEq(t *testing.T) {
	out := mustRedact(t, "-p=shortPass")
	assertNotContains(t, out, "shortPass", "-p=")
}

// 2b. --flag value (space-separated) form

func TestRedactCmdline_Flag_PasswordSpace(t *testing.T) {
	out := mustRedact(t, "--password mySecret123")
	assertNotContains(t, out, "mySecret123", "--password space")
	assertContains(t, out, "--password ", "flag name preserved (space)")
}

func TestRedactCmdline_Flag_PassSpace(t *testing.T) {
	out := mustRedact(t, "--pass abc")
	assertNotContains(t, out, "abc", "--pass space")
}

func TestRedactCmdline_Flag_TokenSpace(t *testing.T) {
	out := mustRedact(t, "--token tok_live_xyz")
	assertNotContains(t, out, "tok_live_xyz", "--token space")
}

func TestRedactCmdline_Flag_SecretSpace(t *testing.T) {
	out := mustRedact(t, "--secret s3cr3t")
	assertNotContains(t, out, "s3cr3t", "--secret space")
}

func TestRedactCmdline_Flag_KeySpace(t *testing.T) {
	out := mustRedact(t, "--key apiKey007")
	assertNotContains(t, out, "apiKey007", "--key space")
}

func TestRedactCmdline_Flag_ShortPSpace(t *testing.T) {
	out := mustRedact(t, "-p shortPass")
	assertNotContains(t, out, "shortPass", "-p space")
}

// 2c. Case-insensitivity

func TestRedactCmdline_Flag_CaseInsensitive(t *testing.T) {
	cases := []string{
		"--PASSWORD=secret",
		"--Token=secret",
		"--SECRET=secret",
		"--KEY=secret",
	}
	for _, c := range cases {
		out := mustRedact(t, c)
		assertNotContains(t, out, "secret", "case-insensitive flag: "+c)
	}
}

// 2d. Flag in the middle of a longer command line

func TestRedactCmdline_Flag_MidCmdline(t *testing.T) {
	out := mustRedact(t, "myapp connect --host db.example.com --password=hunter2 --port 5432")
	assertNotContains(t, out, "hunter2", "flag mid-cmdline")
	assertContains(t, out, "--host db.example.com", "non-sensitive parts preserved")
	assertContains(t, out, "--port 5432", "non-sensitive port preserved")
}

// ---------------------------------------------------------------------------
// 3. Sensitive URL query parameters
// ---------------------------------------------------------------------------

func TestRedactCmdline_Query_Password(t *testing.T) {
	out := mustRedact(t, "https://example.com/api?password=s3cr3t&other=val")
	assertNotContains(t, out, "s3cr3t", "query password=")
	assertContains(t, out, "password=****", "query placeholder")
	assertContains(t, out, "other=val", "non-sensitive param preserved")
}

func TestRedactCmdline_Query_Token(t *testing.T) {
	out := mustRedact(t, "https://api.example.com/cb?token=tok_abc123&user=me")
	assertNotContains(t, out, "tok_abc123", "query token=")
	assertContains(t, out, "user=me", "non-sensitive param preserved")
}

func TestRedactCmdline_Query_Secret(t *testing.T) {
	out := mustRedact(t, "endpoint?secret=shhhh")
	assertNotContains(t, out, "shhhh", "query secret=")
}

func TestRedactCmdline_Query_Key(t *testing.T) {
	out := mustRedact(t, "endpoint?key=apiKey007&format=json")
	assertNotContains(t, out, "apiKey007", "query key=")
	assertContains(t, out, "format=json", "format param preserved")
}

func TestRedactCmdline_Query_CaseInsensitive(t *testing.T) {
	cases := []string{
		"u?PASSWORD=x",
		"u?Token=x",
		"u?SECRET=x",
		"u?KEY=x",
	}
	for _, c := range cases {
		out := mustRedact(t, c)
		assertNotContains(t, out, "=x", "query case-insensitive: "+c)
	}
}

func TestRedactCmdline_Query_MultipleParams(t *testing.T) {
	out := mustRedact(t, "?password=p1&token=t2&other=keep")
	assertNotContains(t, out, "p1", "query multi password")
	assertNotContains(t, out, "t2", "query multi token")
	assertContains(t, out, "other=keep", "non-sensitive preserved")
}

// ---------------------------------------------------------------------------
// 4. Edge cases
// ---------------------------------------------------------------------------

func TestRedactCmdline_Empty(t *testing.T) {
	out := mustRedact(t, "")
	if out != "" {
		t.Errorf("empty input should produce empty output, got %q", out)
	}
}

func TestRedactCmdline_NoSensitiveData(t *testing.T) {
	in := "ls -la /tmp/data"
	out := mustRedact(t, in)
	if out != in {
		t.Errorf("no-sensitive input should be unchanged; got %q", out)
	}
}

func TestRedactCmdline_NoSensitiveData_WithURL(t *testing.T) {
	// A URL with only non-sensitive query params
	in := "curl https://example.com/api?format=json&limit=10"
	out := mustRedact(t, in)
	if out != in {
		t.Errorf("no-sensitive URL input should be unchanged; got %q", out)
	}
}

func TestRedactCmdline_MultipleSecrets_InOneString(t *testing.T) {
	// All three categories present simultaneously
	in := "myapp --password=pw1 user:pw2@host:27017 https://x.com?token=tk3"
	out := mustRedact(t, in)
	assertNotContains(t, out, "pw1", "multi: flag password")
	assertNotContains(t, out, "pw2", "multi: conn-string password")
	assertNotContains(t, out, "tk3", "multi: query token")
}

func TestRedactCmdline_ByteSlice_RoundTrip(t *testing.T) {
	// RedactCmdline (bytes API) and RedactCmdlineString must agree
	input := "--token=abc123 user:secret@host?key=k1"
	outStr, err := RedactCmdlineString(input)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	outBytes, err := RedactCmdline([]byte(input))
	if err != nil {
		t.Fatalf("unexpected error (bytes API): %v", err)
	}
	if outStr != string(outBytes) {
		t.Errorf("string and bytes APIs disagree:\n  string: %q\n  bytes:  %q", outStr, string(outBytes))
	}
	assertNotContains(t, outStr, "abc123", "roundtrip token")
	assertNotContains(t, outStr, "secret", "roundtrip conn-string password")
	assertNotContains(t, outStr, "k1", "roundtrip query key")
}

func TestRedactCmdline_PlaceholderIsStars(t *testing.T) {
	out := mustRedact(t, "--password=whatever")
	assertContains(t, out, "****", "placeholder must be ****")
}

func TestRedactCmdline_Flag_LongPassword(t *testing.T) {
	long := strings.Repeat("x", 200)
	out := mustRedact(t, "--password="+long)
	assertNotContains(t, out, long, "long password redacted")
	assertContains(t, out, "****", "long password placeholder")
}

// ---------------------------------------------------------------------------
// 5. Underscore-prefixed flag variants (e.g. --redis_pass, --db_password)
// ---------------------------------------------------------------------------

func TestRedactCmdline_Flag_RedisPassSpace(t *testing.T) {
	// --redis_pass VALUE form (space-separated), as seen in game server cmdline.
	out := mustRedact(t, "/go/src/gs/game --redis 192.168.5.29:6379 --redis_pass 111 --globalid 1")
	assertNotContains(t, out, "111", "--redis_pass space")
	assertContains(t, out, "--redis_pass ", "flag name preserved")
	assertContains(t, out, "--redis 192.168.5.29:6379", "non-sensitive redis addr preserved")
	assertContains(t, out, "--globalid 1", "non-sensitive globalid preserved")
}

func TestRedactCmdline_Flag_RedisPassAbsent(t *testing.T) {
	// --redis_pass may be absent entirely; redaction must not alter the line.
	in := "/go/src/gs/game --redis 192.168.5.29:6379 --globalid 1"
	out := mustRedact(t, in)
	if out != in {
		t.Errorf("absent --redis_pass: input should be unchanged; got %q", out)
	}
}

func TestRedactCmdline_Flag_RedisPassEq(t *testing.T) {
	out := mustRedact(t, "--redis_pass=mySecret")
	assertNotContains(t, out, "mySecret", "--redis_pass=")
	assertContains(t, out, "--redis_pass=****", "placeholder present")
}

func TestRedactCmdline_Flag_DbPasswordSpace(t *testing.T) {
	out := mustRedact(t, "--db_password secret123")
	assertNotContains(t, out, "secret123", "--db_password space")
}

func TestRedactCmdline_Flag_UnderscoreVariantsCaseInsensitive(t *testing.T) {
	cases := []struct {
		input  string
		secret string
	}{
		{"--REDIS_PASS 111", "111"},
		{"--db_token=tok123", "tok123"},
		{"--svc_secret=shhh", "shhh"},
		{"--api_key=k999", "k999"},
	}
	for _, c := range cases {
		out := mustRedact(t, c.input)
		assertNotContains(t, out, c.secret, "underscore variant: "+c.input)
	}
}

func TestRedactCmdline_FullGameCmdline(t *testing.T) {
	// Full game server cmdline as observed in production (game32), space-separated.
	in := "/go/src/gs/game --pfenv dev --serverid 32 --loglevel debug " +
		"--nats 192.168.5.29:4222 --logfile rfile:/go/src/gs/log//h5dev-zaza_game32.log " +
		"--namespace h5dev-zaza --doorid 1 --etcdcenter 192.168.5.29:2379" +
		"--dburl admin:****@192.168.5.29:27017/test?authSource=admin " +
		"--servername game32 --csv h5 --redis 192.168.5.29:6379 --redis_pass 111 " +
		"--globalid 1 --rankid 1"
	out := mustRedact(t, in)
	assertNotContains(t, out, "111", "full cmdline: redis_pass must be masked")
	// Non-sensitive flags must survive.
	assertContains(t, out, "--serverid 32", "serverid preserved")
	assertContains(t, out, "--redis 192.168.5.29:6379", "redis addr preserved")
	assertContains(t, out, "--globalid 1", "globalid preserved")
}

// ---------------------------------------------------------------------------
// 6. NUL-byte separated cmdline (/proc/PID/cmdline format)
// ---------------------------------------------------------------------------

// nulJoin joins args with NUL bytes, mirroring the /proc/PID/cmdline format.
func nulJoin(args ...string) string {
	return strings.Join(args, "\x00")
}

func TestRedactCmdline_NUL_RedisPassNotLeaked(t *testing.T) {
	// /proc/PID/cmdline uses NUL bytes between arguments.
	in := nulJoin("/go/src/gs/game",
		"--pfenv", "dev",
		"--serverid", "32",
		"--redis", "192.168.5.29:6379",
		"--redis_pass", "ogEUhZKM1SrOav760QOK",
		"--globalid", "1",
	)
	out := mustRedact(t, in)
	assertNotContains(t, out, "ogEUhZKM1SrOav760QOK", "NUL-sep redis_pass must be masked")
	// Non-sensitive arguments must survive as-is.
	if !strings.Contains(out, "192.168.5.29:6379") {
		t.Errorf("redis addr should be preserved, got: %q", strings.ReplaceAll(out, "\x00", "·"))
	}
}

func TestRedactCmdline_NUL_PasswordNotLeaked(t *testing.T) {
	in := nulJoin("/usr/bin/server", "--password", "s3cr3t", "--port", "8080")
	out := mustRedact(t, in)
	assertNotContains(t, out, "s3cr3t", "NUL-sep --password must be masked")
	assertContains(t, out, "****", "placeholder present")
}

func TestRedactCmdline_NUL_AbsentRedisPass(t *testing.T) {
	// --redis_pass absent: NUL-separated cmdline without any sensitive flag.
	in := nulJoin("/go/src/gs/game", "--redis", "192.168.5.29:6379", "--globalid", "1")
	out := mustRedact(t, in)
	if out != in {
		t.Errorf("absent --redis_pass NUL cmdline should be unchanged;\ngot (·=NUL): %s",
			strings.ReplaceAll(out, "\x00", "·"))
	}
}

func TestRedactCmdline_NUL_FullGameCmdline(t *testing.T) {
	// Full NUL-separated cmdline as returned by pprof cmdline endpoint for game32.
	in := nulJoin(
		"/go/src/gs/game",
		"--pfenv", "dev",
		"--serverid", "32",
		"--loglevel", "debug",
		"--nats", "192.168.5.29:4222",
		"--namespace", "h5dev-zaza",
		"--doorid", "1",
		"--etcdcenter", "192.168.5.29:2379",
		"--dburl", "admin:****@192.168.5.29:27017/test?authSource=admin",
		"--servername", "game32",
		"--redis", "192.168.5.29:6379",
		"--redis_pass", "ogEUhZKM1SrOav760QOK",
		"--globalid", "1",
		"--rankid", "1",
	)
	out := mustRedact(t, in)
	assertNotContains(t, out, "ogEUhZKM1SrOav760QOK", "full NUL cmdline: redis_pass masked")
	// Non-sensitive values must survive.
	if !strings.Contains(out, "192.168.5.29:6379") {
		t.Errorf("redis addr should survive: %s", strings.ReplaceAll(out, "\x00", "·"))
	}
	if !strings.Contains(out, "h5dev-zaza") {
		t.Errorf("namespace should survive: %s", strings.ReplaceAll(out, "\x00", "·"))
	}
}
