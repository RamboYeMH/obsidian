// Package accesslog provides an HTTP middleware that writes per-request access
// logs to daily-rotated files under a configurable directory.
//
// Log format (one JSON line per request):
//
//	{"time":"2006-01-02T15:04:05Z07:00","user":"alice@dev","remote":"1.2.3.4","method":"POST","path":"/mcp","status":200,"req_bytes":512,"resp_bytes":1024,"duration_ms":42}
//
// Files are named access.YYYYMMDD.log and are created (or appended to) inside
// the directory specified in config.LogConfig.Dir.
// Rotation happens automatically at the first request after UTC midnight.
package accesslog
