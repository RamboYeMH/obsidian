package accesslog

import (
	"context"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// ── Context fields ────────────────────────────────────────────────────────────

type ctxKey int

const fieldsKey ctxKey = iota

// fields holds per-request information that downstream handlers (tool handlers,
// auth middleware) can enrich before the log entry is written.
type fields struct {
	mu        sync.Mutex
	user      string // token name set by auth middleware
	tool      string // MCP tool name, set by SetTool
	db        string // resolved target database name (server-side only), set by SetDB
	mongoUser string // mongo account used to connect (server-side only), set by SetMongoUser
	redisUser string // redis account used to connect (server-side only), set by SetRedisUser
	role      string // replica-set role of the node actually read, set by SetRole
	setName   string // replica-set name (server-side only), set by SetRole
	node      string // node host:port actually read (server-side only), set by SetRole
	errMsg    string // caller-safe error text, set by SetError
	reason    string // short underlying failure reason (server-side only), set by SetReason
	toolErr   bool   // true when the tool returned IsError=true, set by SetError
}

// fieldsFromContext returns the *fields stored by Middleware; returns nil when
// not present (safe to call anywhere, Set* helpers guard against nil).
func fieldsFromContext(ctx context.Context) *fields {
	f, _ := ctx.Value(fieldsKey).(*fields)
	return f
}

// SetTool records the MCP tool name for the current request.
func SetTool(ctx context.Context, tool string) {
	if f := fieldsFromContext(ctx); f != nil {
		f.mu.Lock()
		f.tool = tool
		f.mu.Unlock()
	}
}

// SetDB records the resolved target database name for the current request.
// Written only to the server-side access-log file; never returned to the caller.
func SetDB(ctx context.Context, db string) {
	if f := fieldsFromContext(ctx); f != nil {
		f.mu.Lock()
		f.db = db
		f.mu.Unlock()
	}
}

// SetMongoUser records the mongo account name actually used to connect.
// Pass an empty string for anonymous (no-auth) connections — the log records it
// as "(anonymous)". Written only to the server-side access-log file.
func SetMongoUser(ctx context.Context, user string) {
	if f := fieldsFromContext(ctx); f != nil {
		f.mu.Lock()
		if user == "" {
			f.mongoUser = "(anonymous)"
		} else {
			f.mongoUser = user
		}
		f.mu.Unlock()
	}
}

// SetRedisUser records the Redis account name used to connect.
// Pass an empty string for no-auth connections — the log records it as "none".
// Written only to the server-side access-log file.
func SetRedisUser(ctx context.Context, user string) {
	if f := fieldsFromContext(ctx); f != nil {
		f.mu.Lock()
		if user == "" {
			f.redisUser = "none"
		} else {
			f.redisUser = user
		}
		f.mu.Unlock()
	}
}

// SetError records a tool-level error for the current request.
// msg must already be caller-safe (masked). It also flips the toolErr flag so
// the log entry writes ok=false. MCP tool failures return HTTP 200 with
// IsError=true, so without this the log cannot distinguish success from failure.
func SetError(ctx context.Context, msg string) {
	if f := fieldsFromContext(ctx); f != nil {
		f.mu.Lock()
		f.errMsg = msg
		f.toolErr = true
		f.mu.Unlock()
	}
}

// SetReason records a short underlying failure reason (e.g. "AuthenticationFailed",
// "timeout"). Written only to the server-side access-log file; never returned
// to the caller.
func SetReason(ctx context.Context, reason string) {
	if f := fieldsFromContext(ctx); f != nil {
		f.mu.Lock()
		f.reason = reason
		f.mu.Unlock()
	}
}

// SetRole records the replica-set routing diagnosis for the current request:
// role, replica-set name, and the node host:port actually read.
// Written only to the server-side access-log file.
func SetRole(ctx context.Context, role, setName, node string) {
	if f := fieldsFromContext(ctx); f != nil {
		f.mu.Lock()
		f.role = role
		f.setName = setName
		f.node = node
		f.mu.Unlock()
	}
}

// SetUser records the authenticated token-owner name for the current request.
// Called by the auth middleware after token validation.
func SetUser(ctx context.Context, user string) {
	if f := fieldsFromContext(ctx); f != nil {
		f.mu.Lock()
		f.user = user
		f.mu.Unlock()
	}
}

// ── Logger ────────────────────────────────────────────────────────────────────

// Logger writes access log entries to daily-rotated files.
// Use New to create one; it is safe for concurrent use.
type Logger struct {
	dir string

	mu      sync.Mutex
	file    *os.File // currently open log file (nil until first write)
	fileDay string   // YYYYMMDD tag of the open file
}

// New returns a Logger that writes to dir.
// The directory is created (with parents) on the first log write.
func New(dir string) *Logger {
	return &Logger{dir: dir}
}

// entry is the JSON shape written for every request.
type entry struct {
	Time       string `json:"time"`
	User       string `json:"user"`
	Remote     string `json:"remote"`
	Method     string `json:"method"`
	Path       string `json:"path"`
	Tool       string `json:"tool,omitempty"`        // MCP tool name; absent for non-tool requests
	DB         string `json:"db,omitempty"`          // resolved target DB name; server-side only
	MongoUser  string `json:"mongo_user,omitempty"`  // mongo account used; server-side only
	RedisUser  string `json:"redis_user,omitempty"`  // redis account used; server-side only
	Role       string `json:"role,omitempty"`        // replica-set role actually read
	SetName    string `json:"set_name,omitempty"`    // replica-set name; server-side only
	Node       string `json:"node,omitempty"`        // node host:port actually read; server-side only
	Status     int    `json:"status"`
	OK         bool   `json:"ok"`                    // false when the tool returned IsError=true
	ReqBytes   int64  `json:"req_bytes"`
	RespBytes  int64  `json:"resp_bytes"`
	DurationMs int64  `json:"duration_ms"`
	Error      string `json:"error,omitempty"`       // caller-safe error text; absent on success
	Reason     string `json:"reason,omitempty"`      // short underlying failure reason; server-side only
}

// Middleware returns an http.Handler that wraps next, injects a *fields into
// the request context, and writes one JSON log line per request after the
// handler returns.
func (l *Logger) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		reqBytes := r.ContentLength

		f := &fields{}
		ctx := context.WithValue(r.Context(), fieldsKey, f)
		r = r.WithContext(ctx)

		rw := &responseWriter{ResponseWriter: w, status: http.StatusOK}
		next.ServeHTTP(rw, r)

		dur := time.Since(start)

		f.mu.Lock()
		toolName := f.tool
		userName := f.user
		db := f.db
		mongoUser := f.mongoUser
		redisUser := f.redisUser
		role := f.role
		setName := f.setName
		node := f.node
		errMsg := f.errMsg
		reason := f.reason
		toolErr := f.toolErr
		f.mu.Unlock()

		if userName == "" {
			userName = remoteHost(r)
		}

		e := entry{
			Time:       start.UTC().Format(time.RFC3339),
			User:       userName,
			Remote:     remoteHost(r),
			Method:     r.Method,
			Path:       r.URL.Path,
			Tool:       toolName,
			DB:         db,
			MongoUser:  mongoUser,
			RedisUser:  redisUser,
			Role:       role,
			SetName:    setName,
			Node:       node,
			Status:     rw.status,
			OK:         !toolErr && rw.status < 400,
			ReqBytes:   reqBytes,
			RespBytes:  rw.written,
			DurationMs: dur.Milliseconds(),
			Error:      errMsg,
			Reason:     reason,
		}

		if err := l.write(start.UTC(), e); err != nil {
			fmt.Fprintf(os.Stderr, "accesslog: write error: %v\n", err)
		}
	})
}

// write serialises e as a JSON line and appends it to today's log file.
func (l *Logger) write(t time.Time, e entry) error {
	day := t.Format("20060102")

	l.mu.Lock()
	defer l.mu.Unlock()

	if err := l.rotate(day); err != nil {
		return err
	}

	b, err := json.Marshal(e)
	if err != nil {
		return fmt.Errorf("marshal: %w", err)
	}
	_, err = l.file.Write(append(b, '\n'))
	return err
}

// rotate opens (or creates) the log file for day. Must be called with l.mu held.
func (l *Logger) rotate(day string) error {
	if l.file != nil && l.fileDay == day {
		return nil
	}
	if l.file != nil {
		_ = l.file.Close()
		l.file = nil
	}
	if err := os.MkdirAll(l.dir, 0o755); err != nil {
		return fmt.Errorf("mkdir %s: %w", l.dir, err)
	}
	name := filepath.Join(l.dir, "access."+day+".log")
	f, err := os.OpenFile(name, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
	if err != nil {
		return fmt.Errorf("open %s: %w", name, err)
	}
	l.file = f
	l.fileDay = day
	return nil
}

// remoteHost extracts the client IP from r.RemoteAddr (or X-Forwarded-For).
func remoteHost(r *http.Request) string {
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		if h, _, err := net.SplitHostPort(xff); err == nil {
			return h
		}
		return xff
	}
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}

// responseWriter wraps http.ResponseWriter to capture status code and bytes written.
type responseWriter struct {
	http.ResponseWriter
	status  int
	written int64
}

func (rw *responseWriter) WriteHeader(code int) {
	rw.status = code
	rw.ResponseWriter.WriteHeader(code)
}

func (rw *responseWriter) Write(b []byte) (int, error) {
	n, err := rw.ResponseWriter.Write(b)
	rw.written += int64(n)
	return n, err
}
