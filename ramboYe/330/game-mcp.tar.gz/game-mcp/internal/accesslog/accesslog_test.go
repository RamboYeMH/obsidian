package accesslog

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

// newTestLogger returns a Logger writing into a temp dir with stderr captured.
func newTestLogger(t *testing.T) (*Logger, *bytes.Buffer) {
	t.Helper()
	dir := t.TempDir()
	var buf bytes.Buffer
	l := New(dir)
	l.stderr = &buf
	return l, &buf
}

func TestMiddlewareWritesJSONLine(t *testing.T) {
	l, _ := newTestLogger(t)

	inner := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		SetTool(r.Context(), "mongo_query")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("ok"))
	})

	req := httptest.NewRequest(http.MethodPost, "/mcp", strings.NewReader(`{}`))
	rec := httptest.NewRecorder()
	l.Middleware(inner).ServeHTTP(rec, req)

	files, err := filepath.Glob(filepath.Join(l.dir, "access.*.log"))
	if err != nil || len(files) != 1 {
		t.Fatalf("expected 1 log file, got %v (err=%v)", files, err)
	}

	b, err := os.ReadFile(files[0])
	if err != nil {
		t.Fatal(err)
	}
	var e entry
	if err := json.Unmarshal(bytes.TrimSpace(b), &e); err != nil {
		t.Fatalf("invalid JSON line: %v", err)
	}
	if e.Tool != "mongo_query" {
		t.Errorf("tool = %q, want mongo_query", e.Tool)
	}
	if e.Path != "/mcp" || e.Status != http.StatusOK || !e.OK {
		t.Errorf("unexpected entry: %+v", e)
	}
}

func TestWriteRotatesByDay(t *testing.T) {
	l, _ := newTestLogger(t)

	day1 := time.Date(2026, 7, 28, 23, 59, 0, 0, time.UTC)
	day2 := time.Date(2026, 7, 29, 0, 0, 1, 0, time.UTC)

	if err := l.write(day1, entry{User: "a"}); err != nil {
		t.Fatal(err)
	}
	if err := l.write(day2, entry{User: "b"}); err != nil {
		t.Fatal(err)
	}

	for _, f := range []string{"access.20260728.log", "access.20260729.log"} {
		if _, err := os.Stat(filepath.Join(l.dir, f)); err != nil {
			t.Errorf("expected %s to exist: %v", f, err)
		}
	}
}

func TestReportErrorThrottled(t *testing.T) {
	l, buf := newTestLogger(t)

	err := &os.PathError{Op: "open", Path: "/data/game-mcp/log/access.x.log", Err: os.ErrPermission}
	for i := 0; i < 100; i++ {
		l.reportError(err)
	}

	// Only the first failure is printed; the rest only bump the counter.
	if got := strings.Count(buf.String(), "accesslog: write error"); got != 1 {
		t.Fatalf("expected 1 stderr line, got %d:\n%s", got, buf.String())
	}
	if !strings.Contains(buf.String(), "attempt #1") {
		t.Errorf("stderr line should carry the attempt count, got: %s", buf.String())
	}

	last, count := l.LastError()
	if count != 100 {
		t.Errorf("errCount = %d, want 100", count)
	}
	if last == nil || !strings.Contains(last.Error(), "permission denied") {
		t.Errorf("lastErr = %v, want permission-denied error", last)
	}
}

func TestNoteSuccessReportsRecovery(t *testing.T) {
	l, buf := newTestLogger(t)

	err := &os.PathError{Op: "open", Path: "/data/game-mcp/log/access.x.log", Err: os.ErrPermission}
	l.reportError(err)
	l.reportError(err)

	l.noteSuccess()

	out := buf.String()
	if !strings.Contains(out, "recovered after 2 failed attempt") {
		t.Errorf("expected recovery line, got: %s", out)
	}
	if _, count := l.LastError(); count != 0 {
		t.Errorf("errCount after recovery = %d, want 0", count)
	}
}

// TestThrottleWindowExpiry verifies that a new error after throttleWindow has
// elapsed produces a second stderr line.
func TestThrottleWindowExpiry(t *testing.T) {
	l, buf := newTestLogger(t)

	err := &os.PathError{Op: "open", Path: "/x", Err: os.ErrPermission}
	l.reportError(err)
	l.lastErrShown = time.Now().Add(-throttleWindow - time.Second)
	l.reportError(err)

	if got := strings.Count(buf.String(), "accesslog: write error"); got != 2 {
		t.Fatalf("expected 2 stderr lines after window expiry, got %d:\n%s", got, buf.String())
	}
}

// TestConcurrentWrites ensures the logger is safe under parallel requests.
func TestConcurrentWrites(t *testing.T) {
	l, _ := newTestLogger(t)

	var wg sync.WaitGroup
	for i := 0; i < 50; i++ {
		wg.Add(1)
		go func(n int) {
			defer wg.Done()
			ts := time.Date(2026, 7, 28, 12, 0, 0, 0, time.UTC).Add(time.Duration(n) * time.Millisecond)
			if err := l.write(ts, entry{User: "u", Tool: "mongo_query"}); err != nil {
				t.Errorf("write: %v", err)
			}
		}(i)
	}
	wg.Wait()

	b, err := os.ReadFile(filepath.Join(l.dir, "access.20260728.log"))
	if err != nil {
		t.Fatal(err)
	}
	lines := bytes.Count(b, []byte("\n"))
	if lines != 50 {
		t.Errorf("expected 50 log lines, got %d", lines)
	}
}

// TestPermissionDeniedReportsError simulates a rotation failure on an
// unwritable log directory (skipped when running as root, where chmod 0555
// does not actually block writes).
func TestPermissionDeniedReportsError(t *testing.T) {
	if os.Geteuid() == 0 {
		t.Skip("running as root; chmod 0555 does not restrict writes")
	}

	dir := t.TempDir()
	if err := os.Chmod(dir, 0o555); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = os.Chmod(dir, 0o755) })

	var buf bytes.Buffer
	l := New(dir)
	l.stderr = &buf

	err := l.write(time.Now(), entry{User: "u"})
	if err == nil {
		t.Fatal("expected write error on read-only directory")
	}
	if !strings.Contains(err.Error(), "permission denied") {
		t.Errorf("expected permission-denied, got: %v", err)
	}
	l.reportError(err)
	if !strings.Contains(buf.String(), "accesslog: write error") {
		t.Errorf("expected stderr report, got: %s", buf.String())
	}
}
