package mongoq

import (
	"game-mcp/internal/gwerr"

	"go.mongodb.org/mongo-driver/bson"
)

// serverSideJSOps 是可在服务端执行任意 JS 的操作符集合，必须禁止。
var serverSideJSOps = map[string]bool{
	"$where": true, "$function": true, "$accumulator": true,
}

// AssertNoServerSideJS 递归扫描 filter/pipeline/任意嵌套结构，
// 发现任意层级的 server-side JS 操作符（$where/$function/$accumulator）即返回错误。
// 调用方应在执行查询之前调用此函数；错误类型为 gwerr.KindRejected。
func AssertNoServerSideJS(v any) error {
	return assertNoServerSideJS(v)
}

// assertNoServerSideJS 是 AssertNoServerSideJS 的内部递归实现。
func assertNoServerSideJS(v any) error {
	switch val := v.(type) {
	case bson.M:
		for k, nested := range val {
			if serverSideJSOps[k] {
				return gwerr.Rejected("禁止使用 server-side JS 操作符: %s", k)
			}
			if err := assertNoServerSideJS(nested); err != nil {
				return err
			}
		}
	case map[string]any:
		for k, nested := range val {
			if serverSideJSOps[k] {
				return gwerr.Rejected("禁止使用 server-side JS 操作符: %s", k)
			}
			if err := assertNoServerSideJS(nested); err != nil {
				return err
			}
		}
	case bson.A:
		for _, item := range val {
			if err := assertNoServerSideJS(item); err != nil {
				return err
			}
		}
	case []any:
		for _, item := range val {
			if err := assertNoServerSideJS(item); err != nil {
				return err
			}
		}
	case []bson.M:
		for _, item := range val {
			if err := assertNoServerSideJS(item); err != nil {
				return err
			}
		}
	}
	return nil
}

// blockedWriteStages 是 aggregate pipeline 中禁止使用的写阶段操作符。
// $out 和 $merge 会把查询结果写入数据库集合，属于写操作，在只读模式下必须拦截。
var blockedWriteStages = map[string]bool{
	"$out": true, "$merge": true,
}

// blockedDiagStages 是 aggregate pipeline 中禁止使用的诊断阶段操作符。
// 这些阶段会暴露服务器拓扑信息（host:port、localTime、ns 等），属于信息泄露风险。
var blockedDiagStages = map[string]bool{
	"$collStats": true, "$indexStats": true, "$planCacheStats": true,
}

// blockedSystemStages 是 aggregate pipeline 中禁止使用的系统级操作符。
// $currentOp、$listSessions、$listLocalSessions 暴露当前连接/会话信息，
// 可用于枚举服务端运行时状态，须予以拒绝。
var blockedSystemStages = map[string]bool{
	"$currentOp": true, "$listSessions": true, "$listLocalSessions": true,
}

// AssertNoWriteStage 检查 aggregate pipeline 是否包含禁止阶段：
//
//   - 写阶段（$out / $merge）：会向数据库写入数据
//   - 诊断阶段（$collStats / $indexStats / $planCacheStats）：暴露服务器拓扑信息
//   - 系统阶段（$currentOp / $listSessions / $listLocalSessions）：暴露运行时状态
//
// 同时对以下阶段的子 pipeline 做递归检查，防止嵌套绕过：
//   - $facet：每个命名子 pipeline 均被检查
//   - $lookup（带 pipeline 字段）：子 pipeline 被检查
//   - $unionWith（带 pipeline 字段）：子 pipeline 被检查
//
// 任一阶段命中即返回 gwerr.KindRejected 错误，调用方在执行前须调用此函数。
func AssertNoWriteStage(pipeline []bson.M) error {
	return assertNoWriteStage(pipeline)
}

// assertNoWriteStage 是 AssertNoWriteStage 的内部递归实现。
func assertNoWriteStage(pipeline []bson.M) error {
	for _, stage := range pipeline {
		for k, v := range stage {
			switch {
			case blockedWriteStages[k]:
				return gwerr.Rejected("aggregate 中禁止使用写阶段: %s", k)
			case blockedDiagStages[k]:
				return gwerr.Rejected(
					"aggregate 中禁止使用诊断阶段 %s：该阶段会暴露服务器拓扑信息（host/port/localTime 等）。",
					k,
				)
			case blockedSystemStages[k]:
				return gwerr.Rejected(
					"aggregate 中禁止使用系统阶段 %s：该阶段会暴露服务端运行时状态（连接/会话信息等）。",
					k,
				)

			// $facet 的值是 map[string][]stage，每个命名分支都是独立 pipeline，
			// 必须递归检查，否则攻击者可以把 $out/$merge 藏在子 pipeline 里绕过拦截。
			case k == "$facet":
				if err := assertNoWriteStageFacet(v); err != nil {
					return err
				}

			// $lookup 和 $unionWith 均支持带 pipeline 子字段，
			// 子 pipeline 同样需要递归检查。
			case k == "$lookup", k == "$unionWith":
				if err := assertNoWriteStageSubPipeline(v); err != nil {
					return err
				}
			}
		}
	}
	return nil
}

// assertNoWriteStageFacet 递归检查 $facet 阶段的值。
// $facet 值的结构为 {branchName: [stage, ...], ...}，每个分支都是独立 pipeline。
func assertNoWriteStageFacet(v any) error {
	switch facet := v.(type) {
	case bson.M:
		for branchName, subVal := range facet {
			sub, err := toBsonMSlice(subVal)
			if err != nil {
				// 无法解析的分支保守拒绝
				return gwerr.Rejected("$facet 分支 %q 的 pipeline 格式无效", branchName)
			}
			if err := assertNoWriteStage(sub); err != nil {
				return err
			}
		}
	case map[string]any:
		for branchName, subVal := range facet {
			sub, err := toBsonMSlice(subVal)
			if err != nil {
				return gwerr.Rejected("$facet 分支 %q 的 pipeline 格式无效", branchName)
			}
			if err := assertNoWriteStage(sub); err != nil {
				return err
			}
		}
	}
	return nil
}

// assertNoWriteStageSubPipeline 从 $lookup / $unionWith 的参数文档中提取
// pipeline 字段并递归检查。
func assertNoWriteStageSubPipeline(v any) error {
	var doc map[string]any
	switch d := v.(type) {
	case bson.M:
		doc = map[string]any(d)
	case map[string]any:
		doc = d
	default:
		return nil // 没有文档参数，无需检查
	}

	raw, ok := doc["pipeline"]
	if !ok {
		return nil // 没有 pipeline 子字段（如 $lookup 用 localField/foreignField 形式），无需检查
	}

	sub, err := toBsonMSlice(raw)
	if err != nil {
		// 格式无效，保守拒绝
		return gwerr.Rejected("$lookup/$unionWith 的 pipeline 字段格式无效")
	}
	return assertNoWriteStage(sub)
}

// toBsonMSlice 将 []bson.M、[]any 或 bson.A 统一转换为 []bson.M。
// 遇到无法转换的元素类型时返回错误。
func toBsonMSlice(v any) ([]bson.M, error) {
	switch arr := v.(type) {
	case []bson.M:
		return arr, nil
	case bson.A:
		out := make([]bson.M, 0, len(arr))
		for _, item := range arr {
			m, ok := item.(bson.M)
			if !ok {
				return nil, gwerr.Rejected("pipeline 元素类型无效: %T", item)
			}
			out = append(out, m)
		}
		return out, nil
	case []any:
		out := make([]bson.M, 0, len(arr))
		for _, item := range arr {
			m, ok := item.(bson.M)
			if !ok {
				return nil, gwerr.Rejected("pipeline 元素类型无效: %T", item)
			}
			out = append(out, m)
		}
		return out, nil
	default:
		return nil, gwerr.Rejected("pipeline 必须是数组类型，实际类型: %T", v)
	}
}
