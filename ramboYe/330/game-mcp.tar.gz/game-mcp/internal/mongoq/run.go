package mongoq

import (
	"context"
	"fmt"
	"strings"

	"game-mcp/internal/gwerr"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

// RunQuery 在 cli 指向的 MongoDB 实例上执行只读查询，返回结构化结果。
//
// 支持的形式：
//   - "show tables" / "show collections" → 返回 []string（集合名列表）
//   - db.<col>.find(...)         → 返回 []bson.M
//   - db.<col>.findOne(...)      → 返回 bson.M 或 nil（未找到时）
//   - db.<col>.count(...)        → 返回 int64
//   - db.<col>.countDocuments(…) → 返回 int64
//   - db.<col>.estimatedDocumentCount(…) → 返回 int64
//   - db.<col>.aggregate(…)     → 返回 []bson.M
//   - db.<col>.distinct(…)      → 返回 []any
//
// maxLimit > 0 时：find 若未指定 limit 或指定值超过 maxLimit，则收敛到 maxLimit。
// 所有校验/执行失败均返回 error（不再 die/os.Exit 或 fmt.Println）。
func RunQuery(ctx context.Context, cli *mongo.Client, dbName, query string, maxLimit int64) (any, error) {
	// ── 特殊指令：show tables / show collections ──────────────────────────
	switch strings.ToLower(strings.TrimSpace(query)) {
	case "show tables", "show collections":
		names, err := cli.Database(dbName).ListCollectionNames(ctx, bson.M{})
		if err != nil {
			return nil, gwerr.UpstreamWithCause(err, "列举集合失败")
		}
		return names, nil
	}

	// ── 解析查询语句 ──────────────────────────────────────────────────────
	pq, err := ParseQuery(query)
	if err != nil {
		return nil, err
	}
	col := cli.Database(dbName).Collection(pq.Collection)

	// 解析链式游标修饰（limit/skip/sort）
	mods, err := ParseCursorChain(pq.Chain)
	if err != nil {
		return nil, err
	}

	switch pq.Method {
	// ── find ──────────────────────────────────────────────────────────────
	case "find":
		parts := SplitTopLevel(pq.Args)
		filter, err := ParseDoc(SafeGet(parts, 0))
		if err != nil {
			return nil, gwerr.Validation("filter 解析失败: %v", err)
		}
		if err := AssertNoServerSideJS(filter); err != nil {
			return nil, err
		}

		opts := options.Find()
		if len(parts) > 1 {
			proj, err := ParseDoc(parts[1])
			if err != nil {
				return nil, gwerr.Validation("projection 解析失败: %v", err)
			}
			opts.SetProjection(proj)
		}

		// limit 上限保护
		effLimit := int64(0)
		if mods.Limit != nil {
			effLimit = *mods.Limit
		}
		if maxLimit > 0 {
			if effLimit <= 0 || effLimit > maxLimit {
				effLimit = maxLimit
			}
		}
		if effLimit > 0 {
			opts.SetLimit(effLimit)
		}
		if mods.Skip != nil {
			opts.SetSkip(*mods.Skip)
		}
		if mods.Sort != nil {
			opts.SetSort(mods.Sort)
		}

		cursor, err := col.Find(ctx, filter, opts)
		if err != nil {
			return nil, gwerr.UpstreamWithCause(err, "find 执行失败")
		}
		defer cursor.Close(ctx)

		var results []bson.M
		if err := cursor.All(ctx, &results); err != nil {
			return nil, gwerr.UpstreamWithCause(err, "读取 find 结果失败")
		}
		return results, nil

	// ── findOne ───────────────────────────────────────────────────────────
	case "findone":
		parts := SplitTopLevel(pq.Args)
		filter, err := ParseDoc(SafeGet(parts, 0))
		if err != nil {
			return nil, gwerr.Validation("filter 解析失败: %v", err)
		}
		if err := AssertNoServerSideJS(filter); err != nil {
			return nil, err
		}

		opts := options.FindOne()
		if len(parts) > 1 {
			proj, err := ParseDoc(parts[1])
			if err != nil {
				return nil, gwerr.Validation("projection 解析失败: %v", err)
			}
			opts.SetProjection(proj)
		}
		if mods.Skip != nil {
			opts.SetSkip(*mods.Skip)
		}
		if mods.Sort != nil {
			opts.SetSort(mods.Sort)
		}

		var result bson.M
		if err := col.FindOne(ctx, filter, opts).Decode(&result); err != nil {
			if err == mongo.ErrNoDocuments {
				return nil, nil
			}
			return nil, gwerr.UpstreamWithCause(err, "findOne 执行失败")
		}
		return result, nil

	// ── count / countDocuments ────────────────────────────────────────────
	case "count", "countdocuments":
		filter, err := ParseDoc(pq.Args)
		if err != nil {
			return nil, gwerr.Validation("filter 解析失败: %v", err)
		}
		if err := AssertNoServerSideJS(filter); err != nil {
			return nil, err
		}
		n, err := col.CountDocuments(ctx, filter)
		if err != nil {
			return nil, gwerr.UpstreamWithCause(err, "count 执行失败")
		}
		return n, nil

	// ── estimatedDocumentCount ────────────────────────────────────────────
	case "estimateddocumentcount":
		n, err := col.EstimatedDocumentCount(ctx)
		if err != nil {
			return nil, gwerr.UpstreamWithCause(err, "estimatedDocumentCount 执行失败")
		}
		return n, nil

	// ── aggregate ─────────────────────────────────────────────────────────
	case "aggregate":
		pipelineStr := NormalizeMongoJSON(strings.TrimSpace(pq.Args))
		var pipeline []bson.M
		if err := bson.UnmarshalExtJSON([]byte(pipelineStr), false, &pipeline); err != nil {
			return nil, gwerr.Validation("aggregate pipeline 解析失败: %v", err)
		}
		if err := AssertNoWriteStage(pipeline); err != nil {
			return nil, err
		}
		for _, stage := range pipeline {
			if err := AssertNoServerSideJS(stage); err != nil {
				return nil, err
			}
		}

		cursor, err := col.Aggregate(ctx, pipeline)
		if err != nil {
			return nil, gwerr.UpstreamWithCause(err, "aggregate 执行失败")
		}
		defer cursor.Close(ctx)

		var results []bson.M
		if err := cursor.All(ctx, &results); err != nil {
			return nil, gwerr.UpstreamWithCause(err, "读取 aggregate 结果失败")
		}
		return results, nil

	// ── distinct ──────────────────────────────────────────────────────────
	case "distinct":
		parts := SplitTopLevel(pq.Args)
		if len(parts) == 0 {
			return nil, gwerr.Validation("distinct 需要字段名")
		}
		field := strings.Trim(strings.TrimSpace(parts[0]), `"'`)
		filter := bson.M{}
		if len(parts) > 1 {
			filter, err = ParseDoc(parts[1])
			if err != nil {
				return nil, gwerr.Validation("filter 解析失败: %v", err)
			}
		}
		if err := AssertNoServerSideJS(filter); err != nil {
			return nil, err
		}
		vals, err := col.Distinct(ctx, field, filter)
		if err != nil {
			return nil, gwerr.UpstreamWithCause(err, "distinct 执行失败")
		}
		return vals, nil

	default:
		// ParseQuery 已做白名单校验，此处理论上不可达，保留作防御性断言
		return nil, gwerr.Rejected("不支持的方法: %s", fmt.Sprintf("%q", pq.Method))
	}
}
