package mongoq

import (
	"context"
	"errors"
	"testing"

	"game-mcp/internal/gwerr"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/integration/mtest"
)

// ── helpers ──────────────────────────────────────────────────────────────────

// mtestOpts returns the common mtest options used by all mock-based subtests.
func mtestOpts() *mtest.Options {
	return mtest.NewOptions().
		ClientType(mtest.Mock).
		DatabaseName("testdb")
}

// assertGwerrKind checks that err is a *gwerr.GatewayError of the expected kind.
func assertGwerrKind(t *testing.T, err error, kind gwerr.Kind, desc string) {
	t.Helper()
	if err == nil {
		t.Fatalf("%s: expected error of kind %v, got nil", desc, kind)
	}
	var ge *gwerr.GatewayError
	if !errors.As(err, &ge) {
		t.Fatalf("%s: expected *gwerr.GatewayError, got %T: %v", desc, err, err)
	}
	if ge.Kind != kind {
		t.Fatalf("%s: expected kind %v, got %v (msg=%s)", desc, kind, ge.Kind, ge.Msg)
	}
}

// ── Tests that need no MongoDB connection ────────────────────────────────────

// TestRunQuery_UnsupportedMethod verifies that an unsupported method is rejected
// by ParseQuery before any DB operation is attempted.
// Validates: Requirements 5.9, 5.10
func TestRunQuery_UnsupportedMethod(t *testing.T) {
	unsupported := []string{
		"insert", "update", "delete", "drop", "createIndex",
		"insertOne", "updateOne", "deleteOne", "replaceOne",
		"bulkWrite", "rename",
	}
	for _, method := range unsupported {
		method := method
		t.Run(method, func(t *testing.T) {
			query := "db.users." + method + "({name:\"alice\"})"
			// RunQuery with a nil client — ParseQuery must return an error
			// before the client is ever touched for unsupported methods.
			_, err := RunQuery(context.Background(), nil, "testdb", query, 100)
			assertGwerrKind(t, err, gwerr.KindRejected, "unsupported method "+method)
		})
	}
}

// TestRunQuery_ParseError verifies that malformed query strings yield a
// KindValidation error without touching the database.
// Validates: Requirements 5.9
func TestRunQuery_ParseError(t *testing.T) {
	malformed := []struct {
		name  string
		query string
	}{
		{"empty", ""},
		{"no_method", "db.users"},
		{"missing_paren", "db.users.find({name:\"a\""},
		{"bad_format", "users.find({})"},
		{"plain_text", "SELECT * FROM users"},
	}
	for _, tc := range malformed {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			_, err := RunQuery(context.Background(), nil, "testdb", tc.query, 100)
			assertGwerrKind(t, err, gwerr.KindValidation, "malformed query "+tc.name)
		})
	}
}

// TestRunQuery_CursorChainParseError verifies that bad cursor chain syntax
// (e.g. unsupported chain method) yields the expected error.
// Validates: Requirements 5.9
func TestRunQuery_CursorChainParseError(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	mt.Run("unsupported_chain_forEach", func(mt *mtest.T) {
		// .forEach is not in the allowed chain set (limit/skip/sort only).
		// The chain error is detected after ParseQuery succeeds, so we need
		// a real (mock) client to get past the col = cli.Database(...) call.
		query := `db.users.find({}).forEach(function(doc){})`
		_, err := RunQuery(context.Background(), mt.Client, "testdb", query, 100)
		if err == nil {
			mt.Fatal("expected error for unsupported chain method, got nil")
		}
		var ge *gwerr.GatewayError
		if !errors.As(err, &ge) {
			mt.Fatalf("expected *gwerr.GatewayError, got %T: %v", err, err)
		}
		// must be KindRejected (unsupported chain) or KindValidation (parse failure)
		if ge.Kind != gwerr.KindRejected && ge.Kind != gwerr.KindValidation {
			mt.Fatalf("expected KindRejected or KindValidation, got %v", ge.Kind)
		}
	})
}

// TestRunQuery_LimitConvergence_NoDB verifies that limit convergence logic is
// applied correctly by checking the parsed query — no MongoDB needed.
// Validates: Requirements 5.10
func TestRunQuery_LimitConvergence(t *testing.T) {
	mt := mtest.New(t, mtestOpts())

	// Sub-test: limit not specified → maxLimit is applied
	mt.Run("no_limit_uses_maxLimit", func(mt *mtest.T) {
		// Mock: first response is the find cursor, second is the getMore empty response.
		mt.AddMockResponses(
			mtest.CreateCursorResponse(0, "testdb.users", mtest.FirstBatch,
				bson.D{{"_id", "1"}, {"name", "alice"}},
			),
		)
		result, err := RunQuery(context.Background(), mt.Client, "testdb",
			`db.users.find({})`, 5)
		if err != nil {
			mt.Fatalf("unexpected error: %v", err)
		}
		docs, ok := result.([]bson.M)
		if !ok {
			mt.Fatalf("expected []bson.M, got %T", result)
		}
		if len(docs) != 1 {
			mt.Fatalf("expected 1 doc, got %d", len(docs))
		}
	})

	// Sub-test: requested limit exceeds maxLimit → maxLimit is used instead
	mt.Run("limit_exceeds_maxLimit_is_capped", func(mt *mtest.T) {
		mt.AddMockResponses(
			mtest.CreateCursorResponse(0, "testdb.users", mtest.FirstBatch,
				bson.D{{"_id", "1"}, {"name", "bob"}},
			),
		)
		// limit(1000) with maxLimit=5 — the driver should receive limit=5
		result, err := RunQuery(context.Background(), mt.Client, "testdb",
			`db.users.find({}).limit(1000)`, 5)
		if err != nil {
			mt.Fatalf("unexpected error: %v", err)
		}
		docs, ok := result.([]bson.M)
		if !ok {
			mt.Fatalf("expected []bson.M, got %T", result)
		}
		_ = docs // result shape verified; limit enforcement is at driver level
	})

	// Sub-test: maxLimit=0 (disabled) passes through whatever limit is requested
	mt.Run("maxLimit_zero_no_cap", func(mt *mtest.T) {
		mt.AddMockResponses(
			mtest.CreateCursorResponse(0, "testdb.users", mtest.FirstBatch,
				bson.D{{"_id", "1"}, {"name", "carol"}},
			),
		)
		_, err := RunQuery(context.Background(), mt.Client, "testdb",
			`db.users.find({}).limit(9999)`, 0)
		if err != nil {
			mt.Fatalf("unexpected error with maxLimit=0: %v", err)
		}
	})
}

// ── show tables / show collections ───────────────────────────────────────────

// TestRunQuery_ShowTables verifies that "show tables" returns a []string of
// collection names.
// Validates: Requirements 5.9
func TestRunQuery_ShowTables(t *testing.T) {
	mt := mtest.New(t, mtestOpts())

	// Both spellings must work.
	for _, query := range []string{"show tables", "show collections",
		"SHOW TABLES", "Show Collections"} {
		query := query
		mt.Run(query, func(mt *mtest.T) {
			// listCollections uses a cursor response.
			mt.AddMockResponses(
				mtest.CreateCursorResponse(0, "testdb.$cmd.listCollections",
					mtest.FirstBatch,
					bson.D{{"name", "alpha"}, {"type", "collection"}},
					bson.D{{"name", "beta"}, {"type", "collection"}},
				),
			)

			result, err := RunQuery(context.Background(), mt.Client, "testdb", query, 100)
			if err != nil {
				mt.Fatalf("show tables error: %v", err)
			}
			names, ok := result.([]string)
			if !ok {
				mt.Fatalf("expected []string, got %T", result)
			}
			if len(names) != 2 {
				mt.Fatalf("expected 2 names, got %d: %v", len(names), names)
			}
		})
	}
}

// TestRunQuery_ShowTables_Empty verifies that an empty collection list is
// returned as an empty (not nil) slice.
// Validates: Requirements 5.9
func TestRunQuery_ShowTables_Empty(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	mt.Run("empty", func(mt *mtest.T) {
		mt.AddMockResponses(
			mtest.CreateCursorResponse(0, "testdb.$cmd.listCollections",
				mtest.FirstBatch),
		)
		result, err := RunQuery(context.Background(), mt.Client, "testdb", "show tables", 100)
		if err != nil {
			mt.Fatalf("unexpected error: %v", err)
		}
		names, ok := result.([]string)
		if !ok {
			mt.Fatalf("expected []string, got %T", result)
		}
		if names == nil {
			mt.Fatal("expected non-nil empty slice, got nil")
		}
	})
}

// ── findOne ───────────────────────────────────────────────────────────────────

// TestRunQuery_FindOne_Hit verifies that a matching document is returned as bson.M.
// Validates: Requirements 5.9
func TestRunQuery_FindOne_Hit(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	mt.Run("hit", func(mt *mtest.T) {
		mt.AddMockResponses(
			mtest.CreateCursorResponse(0, "testdb.users", mtest.FirstBatch,
				bson.D{{"_id", "abc"}, {"name", "alice"}, {"age", int32(30)}},
			),
		)
		result, err := RunQuery(context.Background(), mt.Client, "testdb",
			`db.users.findOne({name:"alice"})`, 100)
		if err != nil {
			mt.Fatalf("unexpected error: %v", err)
		}
		if result == nil {
			mt.Fatal("expected non-nil document, got nil")
		}
		doc, ok := result.(bson.M)
		if !ok {
			mt.Fatalf("expected bson.M, got %T", result)
		}
		if doc["name"] != "alice" {
			mt.Fatalf("expected name=alice, got %v", doc["name"])
		}
	})
}

// TestRunQuery_FindOne_Miss verifies that a "no documents" response is returned
// as (nil, nil) — the canonical "not found" signal.
// Validates: Requirements 5.9
func TestRunQuery_FindOne_Miss(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	mt.Run("miss", func(mt *mtest.T) {
		// Empty cursor → mongo.ErrNoDocuments → RunQuery returns (nil, nil).
		mt.AddMockResponses(
			mtest.CreateCursorResponse(0, "testdb.users", mtest.FirstBatch),
		)
		result, err := RunQuery(context.Background(), mt.Client, "testdb",
			`db.users.findOne({name:"nobody"})`, 100)
		if err != nil {
			mt.Fatalf("expected (nil, nil) for no-document result, got err: %v", err)
		}
		if result != nil {
			mt.Fatalf("expected nil result for no-document findOne, got %v", result)
		}
	})
}

// ── count / countDocuments ───────────────────────────────────────────────────

// countCursorResponse builds the mock cursor response that CountDocuments
// expects. CountDocuments runs an aggregation pipeline with $count internally,
// so the driver expects a cursor batch containing one document {"n": <count>}.
func countCursorResponse(ns string, n int32) bson.D {
	return mtest.CreateCursorResponse(0, ns, mtest.FirstBatch,
		bson.D{{"n", n}},
	)
}

// TestRunQuery_Count verifies that count queries return an int64.
// Validates: Requirements 5.9
func TestRunQuery_Count(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	for _, method := range []string{"count", "countDocuments"} {
		method := method
		mt.Run(method, func(mt *mtest.T) {
			// CountDocuments uses an aggregation pipeline with $count internally,
			// so we must return a cursor response with an {n: <count>} document.
			mt.AddMockResponses(countCursorResponse("testdb.orders", 42))
			query := "db.orders." + method + "({status:\"paid\"})"
			result, err := RunQuery(context.Background(), mt.Client, "testdb", query, 100)
			if err != nil {
				mt.Fatalf("%s error: %v", method, err)
			}
			n, ok := result.(int64)
			if !ok {
				mt.Fatalf("expected int64, got %T (%v)", result, result)
			}
			if n != 42 {
				mt.Fatalf("expected n=42, got %d", n)
			}
		})
	}
}

// TestRunQuery_Count_EmptyFilter verifies count with no filter (empty args).
// Validates: Requirements 5.9
func TestRunQuery_Count_EmptyFilter(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	mt.Run("empty_filter", func(mt *mtest.T) {
		mt.AddMockResponses(countCursorResponse("testdb.items", 7))
		result, err := RunQuery(context.Background(), mt.Client, "testdb",
			`db.items.count()`, 100)
		if err != nil {
			mt.Fatalf("unexpected error: %v", err)
		}
		n, ok := result.(int64)
		if !ok {
			mt.Fatalf("expected int64, got %T", result)
		}
		if n != 7 {
			mt.Fatalf("expected 7, got %d", n)
		}
	})
}

// ── distinct ─────────────────────────────────────────────────────────────────

// TestRunQuery_Distinct verifies that distinct returns []any with the unique values.
// Validates: Requirements 5.9
func TestRunQuery_Distinct(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	mt.Run("basic", func(mt *mtest.T) {
		mt.AddMockResponses(
			mtest.CreateSuccessResponse(
				bson.E{Key: "values", Value: bson.A{"red", "green", "blue"}},
			),
		)
		result, err := RunQuery(context.Background(), mt.Client, "testdb",
			`db.products.distinct("color")`, 100)
		if err != nil {
			mt.Fatalf("distinct error: %v", err)
		}
		vals, ok := result.([]any)
		if !ok {
			mt.Fatalf("expected []any, got %T", result)
		}
		if len(vals) != 3 {
			mt.Fatalf("expected 3 values, got %d: %v", len(vals), vals)
		}
	})
}

// TestRunQuery_Distinct_WithFilter verifies distinct with a filter document.
// Validates: Requirements 5.9
func TestRunQuery_Distinct_WithFilter(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	mt.Run("with_filter", func(mt *mtest.T) {
		mt.AddMockResponses(
			mtest.CreateSuccessResponse(
				bson.E{Key: "values", Value: bson.A{"admin", "user"}},
			),
		)
		result, err := RunQuery(context.Background(), mt.Client, "testdb",
			`db.accounts.distinct("role", {active: true})`, 100)
		if err != nil {
			mt.Fatalf("distinct with filter error: %v", err)
		}
		vals, ok := result.([]any)
		if !ok {
			mt.Fatalf("expected []any, got %T", result)
		}
		if len(vals) != 2 {
			mt.Fatalf("expected 2 values, got %d", len(vals))
		}
	})
}

// TestRunQuery_Distinct_MissingField verifies that missing the field name returns
// a KindValidation error.
// Validates: Requirements 5.9
func TestRunQuery_Distinct_MissingField(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	mt.Run("missing_field", func(mt *mtest.T) {
		// No mock response needed — validation fires before hitting the wire.
		_, err := RunQuery(context.Background(), mt.Client, "testdb",
			`db.col.distinct()`, 100)
		assertGwerrKind(t, err, gwerr.KindValidation, "distinct without field name")
	})
}

// ── find (general) ───────────────────────────────────────────────────────────

// TestRunQuery_Find_ReturnsDocuments verifies that find returns []bson.M.
// Validates: Requirements 5.9
func TestRunQuery_Find_ReturnsDocuments(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	mt.Run("two_docs", func(mt *mtest.T) {
		mt.AddMockResponses(
			mtest.CreateCursorResponse(0, "testdb.logs", mtest.FirstBatch,
				bson.D{{"_id", "1"}, {"level", "info"}},
				bson.D{{"_id", "2"}, {"level", "warn"}},
			),
		)
		result, err := RunQuery(context.Background(), mt.Client, "testdb",
			`db.logs.find({})`, 100)
		if err != nil {
			mt.Fatalf("find error: %v", err)
		}
		docs, ok := result.([]bson.M)
		if !ok {
			mt.Fatalf("expected []bson.M, got %T", result)
		}
		if len(docs) != 2 {
			mt.Fatalf("expected 2 docs, got %d", len(docs))
		}
	})
}

// TestRunQuery_Find_EmptyResult verifies that a find returning no documents
// gives a nil or empty (non-nil) slice — both are valid for zero results.
// Validates: Requirements 5.9
func TestRunQuery_Find_EmptyResult(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	mt.Run("empty", func(mt *mtest.T) {
		mt.AddMockResponses(
			mtest.CreateCursorResponse(0, "testdb.empty_col", mtest.FirstBatch),
		)
		result, err := RunQuery(context.Background(), mt.Client, "testdb",
			`db.empty_col.find({})`, 100)
		if err != nil {
			mt.Fatalf("unexpected error: %v", err)
		}
		// The Go MongoDB driver returns a nil slice when cursor.All decodes
		// zero documents, which is acceptable for an empty result set.
		// A non-nil empty []bson.M is also valid — both are checked here.
		switch v := result.(type) {
		case []bson.M:
			// ok: nil or empty slice, both are valid
			_ = v
		case nil:
			// also acceptable
		default:
			mt.Fatalf("expected []bson.M or nil, got %T: %v", result, result)
		}
	})
}

// ── server-side JS rejection ──────────────────────────────────────────────────

// TestRunQuery_ServerSideJS_Rejected verifies that filters containing SSJS ops
// are rejected. The SSJS check happens after col is initialized, so a mock
// client is required to avoid a nil pointer dereference.
// Validates: Requirements 5.9
func TestRunQuery_ServerSideJS_Rejected(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	cases := []struct {
		name  string
		query string
	}{
		{"where_op", `db.users.find({$where: "this.age > 10"})`},
		{"findOne_where", `db.users.findOne({$where: "true"})`},
		{"count_where", `db.users.count({$where: "1"})`},
	}
	for _, tc := range cases {
		tc := tc
		mt.Run(tc.name, func(mt *mtest.T) {
			// No mock response needed — SSJS validation fires before the wire call.
			_, err := RunQuery(context.Background(), mt.Client, "testdb", tc.query, 100)
			assertGwerrKind(t, err, gwerr.KindRejected, "ssjs op "+tc.name)
		})
	}
}

// ── aggregate diagnostic-stage rejection ─────────────────────────────────────

// TestRunQuery_AggregateDiagnosticStages_Rejected verifies that aggregate
// pipelines containing $collStats, $indexStats, or $planCacheStats are
// rejected before any wire traffic is sent.
//
// These stages expose server topology information (host:port, localTime, ns,
// etc.) and are blocked alongside the write stages ($out/$merge).
// Validates: info-leak guard in AssertNoWriteStage
func TestRunQuery_AggregateDiagnosticStages_Rejected(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	cases := []struct {
		name  string
		query string
	}{
		{
			"collStats",
			`db.player.aggregate([{$collStats: {storageStats: {}}}])`,
		},
		{
			"indexStats",
			`db.player.aggregate([{$indexStats: {}}])`,
		},
		{
			"planCacheStats",
			`db.player.aggregate([{$planCacheStats: {}}])`,
		},
	}
	for _, tc := range cases {
		tc := tc
		mt.Run(tc.name, func(mt *mtest.T) {
			// Validation fires before the wire call — no mock response needed.
			_, err := RunQuery(context.Background(), mt.Client, "testdb", tc.query, 100)
			assertGwerrKind(t, err, gwerr.KindRejected, "diagnostic stage "+tc.name)
		})
	}
}

// ── Gap 1: $out/$merge nested inside $facet ───────────────────────────────────

// TestRunQuery_AggregateFacetNestedWriteStage_Rejected verifies that a write
// stage ($out or $merge) hidden inside a $facet sub-pipeline is caught and
// rejected before any wire traffic is sent.
//
// Previously AssertNoWriteStage only scanned top-level pipeline stages, so
// db.col.aggregate([{$facet:{x:[{$out:"evil"}]}}]) would slip through.
// Validates: Gap-1 fix in AssertNoWriteStage
func TestRunQuery_AggregateFacetNestedWriteStage_Rejected(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	cases := []struct {
		name  string
		query string
	}{
		{
			"facet_out",
			`db.col.aggregate([{$facet:{legit:[{$match:{}}],evil:[{$out:"target"}]}}])`,
		},
		{
			"facet_merge",
			`db.col.aggregate([{$facet:{a:[{$merge:{into:"target"}}]}}])`,
		},
		{
			"safe_prefix_then_facet_out",
			`db.col.aggregate([{$match:{}},{$facet:{x:[{$out:"t"}]}}])`,
		},
	}
	for _, tc := range cases {
		tc := tc
		mt.Run(tc.name, func(mt *mtest.T) {
			_, err := RunQuery(context.Background(), mt.Client, "testdb", tc.query, 100)
			assertGwerrKind(t, err, gwerr.KindRejected, "facet nested write "+tc.name)
		})
	}
}

// ── Gap 2: $currentOp/$listSessions in aggregate pipeline ────────────────────

// TestRunQuery_AggregateSystemStages_Rejected verifies that aggregate pipelines
// containing $currentOp, $listSessions, or $listLocalSessions are rejected.
//
// Previously these could slip past AssertNoWriteStage because only $out/$merge
// and the diagnostic trio were listed. An attacker could use
// db.col.aggregate([{$currentOp:{}}]) to enumerate active connections.
// Validates: Gap-2 fix in AssertNoWriteStage
func TestRunQuery_AggregateSystemStages_Rejected(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	cases := []struct {
		name  string
		query string
	}{
		{
			"currentOp",
			`db.col.aggregate([{$currentOp:{}}])`,
		},
		{
			"listSessions",
			`db.col.aggregate([{$listSessions:{}}])`,
		},
		{
			"listLocalSessions",
			`db.col.aggregate([{$listLocalSessions:{}}])`,
		},
		{
			"safe_prefix_then_currentOp",
			`db.col.aggregate([{$match:{}},{$currentOp:{}}])`,
		},
	}
	for _, tc := range cases {
		tc := tc
		mt.Run(tc.name, func(mt *mtest.T) {
			_, err := RunQuery(context.Background(), mt.Client, "testdb", tc.query, 100)
			assertGwerrKind(t, err, gwerr.KindRejected, "system stage "+tc.name)
		})
	}
}

// ── Gap 3: $out/$merge nested inside $lookup.pipeline / $unionWith.pipeline ──

// TestRunQuery_AggregateLookupNestedWriteStage_Rejected verifies that a write
// stage hidden inside a $lookup or $unionWith sub-pipeline is caught.
//
// A $lookup with a pipeline sub-field is a correlated sub-query; the sub-pipeline
// can itself contain $out/$merge. AssertNoWriteStage now recurses into it.
// Validates: Gap-3 fix in AssertNoWriteStage
func TestRunQuery_AggregateLookupNestedWriteStage_Rejected(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	cases := []struct {
		name  string
		query string
	}{
		{
			"lookup_pipeline_out",
			`db.col.aggregate([{$lookup:{from:"other",pipeline:[{$out:"evil"}],as:"r"}}])`,
		},
		{
			"lookup_pipeline_merge",
			`db.col.aggregate([{$lookup:{from:"other",pipeline:[{$match:{}},{$merge:{into:"t"}}],as:"r"}}])`,
		},
		{
			"unionWith_pipeline_out",
			`db.col.aggregate([{$unionWith:{coll:"other",pipeline:[{$out:"evil"}]}}])`,
		},
	}
	for _, tc := range cases {
		tc := tc
		mt.Run(tc.name, func(mt *mtest.T) {
			_, err := RunQuery(context.Background(), mt.Client, "testdb", tc.query, 100)
			assertGwerrKind(t, err, gwerr.KindRejected, "lookup nested write "+tc.name)
		})
	}
}

// TestRunQuery_AggregateLookupWithoutPipeline_Accepted verifies that a standard
// $lookup using localField/foreignField (no sub-pipeline) is still accepted.
// This guards against false positives from the Gap-3 fix.
// Validates: no regression from Gap-3 fix
func TestRunQuery_AggregateLookupWithoutPipeline_Accepted(t *testing.T) {
	mt := mtest.New(t, mtestOpts())
	mt.Run("standard_lookup", func(mt *mtest.T) {
		mt.AddMockResponses(
			mtest.CreateCursorResponse(0, "testdb.orders", mtest.FirstBatch,
				bson.D{{"_id", "1"}, {"item", "abc"}},
			),
		)
		_, err := RunQuery(context.Background(), mt.Client, "testdb",
			`db.orders.aggregate([{$lookup:{from:"items",localField:"item_id",foreignField:"_id",as:"item_docs"}}])`,
			100)
		if err != nil {
			mt.Fatalf("standard $lookup unexpectedly rejected: %v", err)
		}
	})
}
