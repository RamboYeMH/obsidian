package mongoq

// Feature: pprof-redis-proxy, Property 18: mongo shell 输入归一化往返

import (
	"fmt"
	"strings"
	"testing"

	"go.mongodb.org/mongo-driver/bson"
	"pgregory.net/rapid"
)

// ─── generators ──────────────────────────────────────────────────────────────

// bareKeyGen 生成合法的 bare key（字母/数字/$/_，首字符非数字）。
// 注意：key 内不允许出现 '.'，因为 quoteBareKeys 的 isIdentPart 虽然接受 '.'，
// 但 Extended JSON 解析器在 bson.M 中会把含 '.' 的 key 当作嵌套路径，
// 导致语义不等价，因此测试中只生成简单 key。
var bareKeyGen = rapid.StringMatching(`[A-Za-z_$][A-Za-z0-9_$]{0,15}`)

// quotedKeyGen 生成已用双引号包裹的 key。
var quotedKeyGen = rapid.Custom(func(t *rapid.T) string {
	k := bareKeyGen.Draw(t, "qk")
	return `"` + k + `"`
})

// scalarValueGen 生成简单标量 JSON 值（字符串/整数/bool/null）。
var scalarValueGen = rapid.OneOf(
	rapid.Custom(func(t *rapid.T) string {
		// 简单字符串（仅 ASCII 字母数字，避免需要转义的字符）
		s := rapid.StringMatching(`[a-zA-Z0-9_]{0,20}`).Draw(t, "sv_str")
		return `"` + s + `"`
	}),
	rapid.Custom(func(t *rapid.T) string {
		n := rapid.Int64Range(-1000, 1000).Draw(t, "sv_int")
		return fmt.Sprintf("%d", n)
	}),
	rapid.SampledFrom([]string{"true", "false", "null"}),
)

// hexIDGen 生成合法的 24 位 hex ObjectId 字符串。
var hexIDGen = rapid.StringMatching(`[0-9a-f]{24}`)

// objectIDGen 生成 mongo shell 风格 ObjectId(…) 表达式。
// 同时随机决定是否带引号（两种形式均合法）。
var objectIDGen = rapid.Custom(func(t *rapid.T) string {
	id := hexIDGen.Draw(t, "oid_hex")
	if rapid.Bool().Draw(t, "oid_quoted") {
		return fmt.Sprintf(`ObjectId("%s")`, id)
	}
	return fmt.Sprintf(`ObjectId(%s)`, id)
})

// isoDateGen 生成 ISODate("…") 表达式（使用已知合法的 RFC 3339 时间串子集）。
var isoDateGen = rapid.Custom(func(t *rapid.T) string {
	year := rapid.IntRange(2000, 2030).Draw(t, "year")
	mon := rapid.IntRange(1, 12).Draw(t, "mon")
	day := rapid.IntRange(1, 28).Draw(t, "day")
	return fmt.Sprintf(`ISODate("%04d-%02d-%02dT00:00:00Z")`, year, mon, day)
})

// numberLongGen 生成 NumberLong(…) 表达式（带或不带引号）。
var numberLongGen = rapid.Custom(func(t *rapid.T) string {
	n := rapid.Int64Range(-1<<53, 1<<53).Draw(t, "nl_n")
	if rapid.Bool().Draw(t, "nl_quoted") {
		return fmt.Sprintf(`NumberLong("%d")`, n)
	}
	return fmt.Sprintf(`NumberLong(%d)`, n)
})

// shellValueGen 生成一个"可归一化"的值：标量或 shell 类型包装。
var shellValueGen = rapid.OneOf(
	scalarValueGen,
	objectIDGen,
	isoDateGen,
	numberLongGen,
)

// fieldGen 生成单个字段，key 可以是 bare 或已加引号的形式，value 是 shellValueGen。
func fieldGen(keyQuoted bool) *rapid.Generator[string] {
	return rapid.Custom(func(t *rapid.T) string {
		var key string
		if keyQuoted {
			key = quotedKeyGen.Draw(t, "fk")
		} else {
			key = bareKeyGen.Draw(t, "fk")
		}
		val := shellValueGen.Draw(t, "fv")
		return key + ": " + val
	})
}

// shellDocGen 生成一个包含 1–6 个字段的 mongo shell 文档字符串。
// 每个字段的 key 随机决定是否带引号，value 可能含 shell 类型包装。
// key 通过集合去重，保证生成的 JSON 中不出现重复 key（bson 解析行为未定义）。
var shellDocGen = rapid.Custom(func(t *rapid.T) string {
	n := rapid.IntRange(1, 6).Draw(t, "field_count")
	seen := make(map[string]bool)
	var fields []string
	// 最多尝试 n*3 次以避免无限循环（key 空间足够大，一般几次即可凑够）
	attempts := 0
	for len(fields) < n && attempts < n*3 {
		attempts++
		keyQuoted := rapid.Bool().Draw(t, fmt.Sprintf("kq%d", attempts))
		// 生成 key（不含引号以便去重检查）
		rawKey := bareKeyGen.Draw(t, fmt.Sprintf("rk%d", attempts))
		if seen[rawKey] {
			continue
		}
		seen[rawKey] = true
		val := shellValueGen.Draw(t, fmt.Sprintf("fv%d", attempts))
		var key string
		if keyQuoted {
			key = `"` + rawKey + `"`
		} else {
			key = rawKey
		}
		fields = append(fields, key+": "+val)
	}
	if len(fields) == 0 {
		// 保底：至少一个字段
		fields = []string{`"x": 1`}
	}
	return "{" + strings.Join(fields, ", ") + "}"
})

// ─── property test ────────────────────────────────────────────────────────────

// TestProperty18_NormalizeMongoJSONRoundtrip 验证：
// 对于任意合法的 mongo shell 风格文档（含无引号 key、ObjectId/ISODate/NumberLong 包装），
// NormalizeMongoJSON 的输出都能被 Extended JSON 解析器成功解析为语义等价文档。
//
// Validates: Requirements 5.4
func TestProperty18_NormalizeMongoJSONRoundtrip(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		shellDoc := shellDocGen.Draw(t, "shell_doc")

		normalized := NormalizeMongoJSON(shellDoc)

		// 断言 1：输出必须能被 Extended JSON 解析器解析成功。
		var parsed bson.M
		if err := bson.UnmarshalExtJSON([]byte(normalized), false, &parsed); err != nil {
			t.Fatalf("NormalizeMongoJSON 输出无法被 ExtJSON 解析\n  输入: %s\n  输出: %s\n  错误: %v",
				shellDoc, normalized, err)
		}

		// 断言 2：解析后文档的字段数应与原始文档中唯一 key 数相等（语义等价基本检查）。
		// 注意：shellDocGen 已保证 key 无重复，所以 len(parsed) == 字段数。
		if len(parsed) == 0 {
			t.Fatalf("解析后文档为空，输入: %s", shellDoc)
		}

		// 断言 3：输出为合法 JSON 对象（以 '{' 开头、'}' 结尾）。
		trimmed := strings.TrimSpace(normalized)
		if !strings.HasPrefix(trimmed, "{") || !strings.HasSuffix(trimmed, "}") {
			t.Fatalf("归一化输出不是 JSON 对象: %s", normalized)
		}
	})
}
