package mongoq

// Feature: pprof-redis-proxy, Property 9: server-side JS 操作符在任意嵌套层被拒绝
// Validates: Requirements 5.7

import (
	"testing"

	"pgregory.net/rapid"
)

// ssjsOps 列举所有受禁止的 server-side JS 操作符，与 guard.go 中的 serverSideJSOps 保持一致。
var ssjsOps = []string{"$where", "$function", "$accumulator"}

// arbitraryKey 生成任意字符串 key（可能是普通键，也可能是 SSJS 操作符，由调用方控制）。
func arbitraryKey(t *rapid.T) string {
	return rapid.StringMatching(`[a-zA-Z_][a-zA-Z0-9_]*`).Draw(t, "key")
}

// safeKey 生成一定不是 SSJS 操作符的普通键。
func safeKey(t *rapid.T) string {
	key := rapid.StringMatching(`[a-zA-Z][a-zA-Z0-9_]*`).Draw(t, "safe_key")
	for _, op := range ssjsOps {
		if "$"+key == op || key == op {
			return "safeField"
		}
	}
	return key
}

// buildSafeDoc 递归构造一个不含任何 SSJS 操作符的嵌套文档（map[string]any）。
// depth 控制最大递归深度，避免无限嵌套。
func buildSafeDoc(t *rapid.T, depth int) map[string]any {
	doc := make(map[string]any)
	numFields := rapid.IntRange(0, 3).Draw(t, "num_fields")
	for i := 0; i < numFields; i++ {
		key := safeKey(t)
		var val any
		if depth > 0 && rapid.Bool().Draw(t, "nest") {
			val = buildSafeDoc(t, depth-1)
		} else {
			val = rapid.String().Draw(t, "leaf_val")
		}
		doc[key] = val
	}
	return doc
}

// injectSSJSOp 在文档的随机深度注入一个 SSJS 操作符。
// 返回注入后的文档及所注入的操作符名称。
func injectSSJSOp(t *rapid.T, base map[string]any, depth int) (map[string]any, string) {
	op := rapid.SampledFrom(ssjsOps).Draw(t, "ssjs_op")

	// 决定是在当前层还是嵌套层注入
	if depth == 0 || rapid.Bool().Draw(t, "inject_here") {
		// 直接在 base 这一层注入
		result := copyDoc(base)
		result[op] = "injected_value"
		return result, op
	}

	// 注入到某个嵌套子文档中
	// 先找到或创建一个嵌套 key
	nestKey := "nested_" + safeKey(t)
	inner := buildSafeDoc(t, 0)
	injected, injOp := injectSSJSOp(t, inner, depth-1)
	result := copyDoc(base)
	result[nestKey] = injected
	return result, injOp
}

// copyDoc 浅拷贝一个 map[string]any。
func copyDoc(src map[string]any) map[string]any {
	dst := make(map[string]any, len(src))
	for k, v := range src {
		dst[k] = v
	}
	return dst
}

// TestProperty9_ServerSideJSRejectedAtAnyDepth 验证 Property 9：
// server-side JS 操作符（$where/$function/$accumulator）无论嵌套在文档的哪一层，
// AssertNoServerSideJS 都应返回错误；不含则通过。
//
// ≥100 次迭代（rapid 默认 100 次，通过 rapid.WithNbRuns 设置更多）。
func TestProperty9_ServerSideJSRejectedAtAnyDepth(t *testing.T) {
	// 子测试 1：含 SSJS 操作符的文档 → 必须返回错误
	t.Run("with_ssjs_op_returns_error", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			// 构造一个不含 SSJS 的安全基础文档
			base := buildSafeDoc(t, 3)
			// 在随机深度注入一个 SSJS 操作符
			nestDepth := rapid.IntRange(0, 4).Draw(t, "nest_depth")
			doc, _ := injectSSJSOp(t, base, nestDepth)

			err := AssertNoServerSideJS(doc)
			if err == nil {
				t.Fatalf("expected error for document containing SSJS op, got nil; doc=%v", doc)
			}
		})
	})

	// 子测试 2：不含任何 SSJS 操作符的文档 → 必须通过（返回 nil）
	t.Run("without_ssjs_op_passes", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			// 构造一个不含 SSJS 的安全嵌套文档
			doc := buildSafeDoc(t, 4)

			err := AssertNoServerSideJS(doc)
			if err != nil {
				t.Fatalf("expected nil for document without SSJS op, got: %v; doc=%v", err, doc)
			}
		})
	})

	// 子测试 3：直接在顶层注入 SSJS 操作符
	t.Run("top_level_ssjs_op_returns_error", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			op := rapid.SampledFrom(ssjsOps).Draw(t, "op")
			doc := map[string]any{
				op: rapid.String().Draw(t, "val"),
			}
			err := AssertNoServerSideJS(doc)
			if err == nil {
				t.Fatalf("expected error for top-level SSJS op %q, got nil", op)
			}
		})
	})

	// 子测试 4：SSJS 操作符嵌套在数组中
	t.Run("ssjs_op_inside_array_returns_error", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			op := rapid.SampledFrom(ssjsOps).Draw(t, "op")
			// 构造 []any 中包含含有 SSJS 操作符的子文档
			innerDoc := map[string]any{
				op: "some_value",
			}
			outer := map[string]any{
				"pipeline": []any{
					buildSafeDoc(t, 1),
					innerDoc,
					buildSafeDoc(t, 1),
				},
			}
			err := AssertNoServerSideJS(outer)
			if err == nil {
				t.Fatalf("expected error when SSJS op %q is inside array, got nil", op)
			}
		})
	})

	// 子测试 5：每个 SSJS 操作符分别在深层嵌套结构中单独验证
	t.Run("each_ssjs_op_at_deep_nesting", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			op := rapid.SampledFrom(ssjsOps).Draw(t, "op")
			depth := rapid.IntRange(1, 5).Draw(t, "depth")

			// 构造深度为 depth 的嵌套文档，在最深层放置 SSJS 操作符
			var buildDeep func(d int) map[string]any
			buildDeep = func(d int) map[string]any {
				if d == 0 {
					return map[string]any{op: "leaf_value"}
				}
				return map[string]any{
					"level": buildDeep(d - 1),
				}
			}
			doc := buildDeep(depth)

			err := AssertNoServerSideJS(doc)
			if err == nil {
				t.Fatalf("expected error for SSJS op %q at depth %d, got nil", op, depth)
			}
		})
	})
}
