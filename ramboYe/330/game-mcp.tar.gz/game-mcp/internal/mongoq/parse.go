package mongoq

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"

	"game-mcp/internal/gwerr"

	"go.mongodb.org/mongo-driver/bson"
)

// ── 安全模型：白名单 ──────────────────────────────────────────────────────────
//
// 只有 allowedMethods 中列出的 7 个只读操作能执行，其它一切天然被拒绝。
// 在白名单之上对参数做结构化检查，防止通过查询参数夹带写语义：
//   1. aggregate 的 $out / $merge 写阶段
//   2. server-side JS 操作符 $where / $function / $accumulator

// 只读操作白名单（小写键）
var allowedMethods = map[string]bool{
	"find":                   true,
	"findone":                true,
	"count":                  true,
	"countdocuments":         true,
	"estimateddocumentcount": true,
	"aggregate":              true,
	"distinct":               true,
}

// 主调用头：db.<collection>.<method>(   collection 名放宽到字母数字 _ - .
var headRe = regexp.MustCompile(`(?i)^db\.([\w\-.]+)\.(\w+)\s*\(`)

// 数据库级命令：db.<method>(   只有一个点，如 db.runCommand( / db.eval(
var dbCmdRe = regexp.MustCompile(`(?i)^db\.(\w+)\s*\(`)

// 副本集 / 分片管理命令：rs.<method>( / sh.<method>(
var rsShRe = regexp.MustCompile(`(?i)^(rs|sh)\.(\w+)\s*\(`)

// 链式游标修饰：.limit( / .sort( / .skip(
var chainHeadRe = regexp.MustCompile(`^\.(\w+)\s*\(`)

// auxChainMethods 是「不影响只读安全性、但当前未实现」的辅助链式方法。
// 命中时给出更友好的提示，而不是笼统的「不支持的链式方法」。
var auxChainMethods = map[string]bool{
	"allowdiskuse": true,
	"hint":         true,
	"comment":      true,
	"maxtimems":    true,
	"max":          true,
	"min":          true,
	"batchsize":    true,
	"collation":    true,
	"readpref":     true,
	"readconcern":  true,
	"pretty":       true,
	"toarray":      true,
	"explain":      true,
	"count":        true,
	"size":         true,
	"hasnext":      true,
	"next":         true,
}

// shell 风格类型包装 → Extended JSON，便于按 mongo 习惯书写查询
var (
	reObjectId   = regexp.MustCompile(`ObjectId\(\s*"?([0-9a-fA-F]{24})"?\s*\)`)
	reISODate    = regexp.MustCompile(`ISODate\(\s*"([^"]*)"\s*\)`)
	reNumberLong = regexp.MustCompile(`NumberLong\(\s*"?(-?\d+)"?\s*\)`)
	reNumberInt  = regexp.MustCompile(`NumberInt\(\s*"?(-?\d+)"?\s*\)`)
)

func preprocessShell(s string) string {
	s = reObjectId.ReplaceAllString(s, `{"$$oid":"$1"}`)
	s = reISODate.ReplaceAllString(s, `{"$$date":"$1"}`)
	s = reNumberLong.ReplaceAllString(s, `{"$$numberLong":"$1"}`)
	s = reNumberInt.ReplaceAllString(s, `$1`)
	return s
}

// quoteBareKeys 给 mongo shell 风格的无引号 key 补上引号，例如
//
//	{name:"abc", age:{$gt:10}}  ->  {"name":"abc", "age":{"$gt":10}}
//
// 字符串字面量内部的内容原样保留，不会被误改。
func quoteBareKeys(s string) string {
	var b strings.Builder
	b.Grow(len(s) + 16)
	inStr := false
	var quote byte
	for i := 0; i < len(s); i++ {
		c := s[i]
		if inStr {
			b.WriteByte(c)
			if c == '\\' && i+1 < len(s) {
				b.WriteByte(s[i+1])
				i++
				continue
			}
			if c == quote {
				inStr = false
			}
			continue
		}
		switch c {
		case '"', '\'':
			inStr = true
			quote = c
			b.WriteByte(c)
		case '{', ',':
			b.WriteByte(c)
			// 跳过空白
			j := i + 1
			for j < len(s) && (s[j] == ' ' || s[j] == '\t' || s[j] == '\n') {
				b.WriteByte(s[j])
				j++
			}
			// 识别 bare key: [A-Za-z_$][\w$]*
			if j < len(s) && isIdentStart(s[j]) {
				k := j
				for k < len(s) && isIdentPart(s[k]) {
					k++
				}
				// key 后必须紧跟（可含空白）冒号
				m := k
				for m < len(s) && (s[m] == ' ' || s[m] == '\t') {
					m++
				}
				if m < len(s) && s[m] == ':' {
					b.WriteByte('"')
					b.WriteString(s[j:k])
					b.WriteByte('"')
					i = k - 1
					continue
				}
			}
			i = j - 1
		default:
			b.WriteByte(c)
		}
	}
	return b.String()
}

func isIdentStart(c byte) bool {
	return c == '_' || c == '$' || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
}

func isIdentPart(c byte) bool {
	return isIdentStart(c) || (c >= '0' && c <= '9') || c == '.'
}

// NormalizeMongoJSON 把 mongo shell 风格输入归一为合法 Extended JSON。
func NormalizeMongoJSON(s string) string {
	return quoteBareKeys(preprocessShell(s))
}

// ExtractParen 从 s[open]（必须是 '('）开始，按括号深度找到配对的 ')'，
// 返回括号内内容与 ')' 的下标。会跳过字符串字面量内的括号。
func ExtractParen(s string, open int) (inner string, closeIdx int, err error) {
	depth := 0
	inStr := false
	var quote byte
	for i := open; i < len(s); i++ {
		c := s[i]
		if inStr {
			if c == '\\' {
				i++
				continue
			}
			if c == quote {
				inStr = false
			}
			continue
		}
		switch c {
		case '"', '\'':
			inStr = true
			quote = c
		case '(':
			depth++
		case ')':
			depth--
			if depth == 0 {
				return s[open+1 : i], i, nil
			}
		}
	}
	return "", 0, fmt.Errorf("括号不匹配")
}

// ParsedQuery 表示一条解析后的只读查询。
type ParsedQuery struct {
	Collection string
	Method     string // 小写
	Args       string // 主方法括号内的原始参数
	Chain      string // 剩余的链式修饰，如 .limit(10).sort({...})
}

// classifyUnrecognized 对无法匹配 db.<collection>.<method>() 主调用头的输入做分类，
// 为常见的管理/数据库级命令给出显式、清晰的拒绝提示，而不是笼统的「无法识别的查询格式」。
// 仍然无法归类的输入回退到 gwerr.Validation("无法识别的查询格式")。
func classifyUnrecognized(q string) error {
	// 数据库级命令：db.runCommand(...) / db.eval(...) / db.currentOp() / db.adminCommand(...) 等。
	if m := dbCmdRe.FindStringSubmatch(q); m != nil {
		return gwerr.Rejected(
			"不支持数据库级命令 db.%s(...)：仅支持集合级只读查询 db.<collection>.<method>()。"+
				"runCommand/eval/currentOp/adminCommand/getCollectionNames 等管理命令一律拒绝。",
			m[1],
		)
	}

	// 副本集 / 分片管理命令：rs.status() / rs.initiate() / sh.status() 等。
	if m := rsShRe.FindStringSubmatch(q); m != nil {
		return gwerr.Rejected(
			"不支持副本集/分片管理命令 %s.%s(...)：本工具仅提供集合级只读查询。",
			strings.ToLower(m[1]), m[2],
		)
	}

	lower := strings.ToLower(q)

	// 切换数据库：use <db>。查询自动作用于已解析的目标库，无需也不允许切库。
	if lower == "use" || strings.HasPrefix(lower, "use ") {
		return gwerr.Rejected(
			"不支持切换数据库 (use ...)：查询会自动作用于已解析的目标库。",
		)
	}

	// 其它 show 变体（show tables / show collections 已在 RunQuery 中单独处理）。
	if strings.HasPrefix(lower, "show ") {
		return gwerr.Rejected(
			"不支持的 show 命令：%s（仅支持 show tables / show collections）。",
			strings.TrimSpace(q[len("show "):]),
		)
	}

	return gwerr.Validation("无法识别的查询格式：请使用 db.<collection>.<method>(...) 形式的只读查询")
}

// ParseQuery 分段解析 db.<col>.<method>(<args>)<chain>。
// 非白名单方法返回 gwerr.Rejected；格式无法识别返回 gwerr.Validation。
func ParseQuery(query string) (*ParsedQuery, error) {
	q := strings.TrimSpace(query)
	loc := headRe.FindStringSubmatchIndex(q)
	if loc == nil {
		return nil, classifyUnrecognized(q)
	}
	collection := q[loc[2]:loc[3]]
	method := strings.ToLower(q[loc[4]:loc[5]])
	openIdx := loc[1] - 1 // headRe 以 '(' 结尾

	inner, closeIdx, err := ExtractParen(q, openIdx)
	if err != nil {
		return nil, gwerr.Validation("括号解析失败: %v", err)
	}
	chain := strings.TrimSpace(q[closeIdx+1:])

	if !allowedMethods[method] {
		return nil, gwerr.Rejected(
			"不支持的方法: %s（仅允许 find/findOne/count/countDocuments/estimatedDocumentCount/aggregate/distinct）",
			method,
		)
	}
	return &ParsedQuery{
		Collection: collection,
		Method:     method,
		Args:       strings.TrimSpace(inner),
		Chain:      chain,
	}, nil
}

// CursorMods 链式游标修饰。
type CursorMods struct {
	Limit *int64
	Skip  *int64
	Sort  bson.M
}

// ParseCursorChain 解析 .limit(n).sort({...}).skip(n)，只允许只读修饰。
// 不支持的链式方法返回 gwerr.Rejected；格式/参数错误返回 gwerr.Validation。
func ParseCursorChain(chain string) (CursorMods, error) {
	var mods CursorMods
	s := chain
	for s != "" {
		m := chainHeadRe.FindStringSubmatchIndex(s)
		if m == nil {
			return mods, gwerr.Validation("无法解析链式调用: %s", s)
		}
		name := strings.ToLower(s[m[2]:m[3]])
		openIdx := m[1] - 1
		inner, closeIdx, err := ExtractParen(s, openIdx)
		if err != nil {
			return mods, gwerr.Validation("链式调用括号解析失败: %v", err)
		}
		inner = strings.TrimSpace(inner)

		switch name {
		case "limit", "skip":
			n, err := strconv.ParseInt(inner, 10, 64)
			if err != nil {
				return mods, gwerr.Validation("%s 参数必须是整数: %s", name, inner)
			}
			if name == "limit" {
				mods.Limit = &n
			} else {
				mods.Skip = &n
			}
		case "sort":
			doc, err := ParseDoc(inner)
			if err != nil {
				return mods, gwerr.Validation("sort 解析失败: %v", err)
			}
			if err := AssertNoServerSideJS(doc); err != nil {
				return mods, err
			}
			// sort 值只允许 1 / -1
			for k, v := range doc {
				switch n := v.(type) {
				case int32:
					if n != 1 && n != -1 {
						return mods, gwerr.Validation("sort 字段 %s 的值只能是 1 或 -1", k)
					}
				case int64:
					if n != 1 && n != -1 {
						return mods, gwerr.Validation("sort 字段 %s 的值只能是 1 或 -1", k)
					}
				case float64:
					if n != 1 && n != -1 {
						return mods, gwerr.Validation("sort 字段 %s 的值只能是 1 或 -1", k)
					}
				default:
					return mods, gwerr.Validation("sort 字段 %s 的值只能是 1 或 -1", k)
				}
			}
			mods.Sort = doc
		default:
			if auxChainMethods[name] {
				return mods, gwerr.Rejected(
					"暂不支持链式方法 .%s()：该方法不影响只读安全性，但当前未实现。"+
						"请移除后重试（仅支持 .limit/.skip/.sort）。",
					name,
				)
			}
			return mods, gwerr.Rejected("不支持的链式方法: %s（仅允许 limit/skip/sort）", name)
		}
		s = strings.TrimSpace(s[closeIdx+1:])
	}
	return mods, nil
}

// ParseDoc 解析 MongoDB Extended JSON（支持 $oid/$date 等类型），
// 并预处理 shell 风格的 ObjectId()/ISODate()/NumberLong() 包装。
func ParseDoc(s string) (bson.M, error) {
	s = strings.TrimSpace(s)
	if s == "" || s == "{}" {
		return bson.M{}, nil
	}
	s = NormalizeMongoJSON(s)
	var m bson.M
	if err := bson.UnmarshalExtJSON([]byte(s), false, &m); err != nil {
		return nil, err
	}
	return m, nil
}

// SplitTopLevel 按顶层逗号分割字符串，跳过括号/引号内的逗号。
func SplitTopLevel(s string) []string {
	var parts []string
	depth := 0
	start := 0
	inStr := false
	var quote byte
	for i := 0; i < len(s); i++ {
		c := s[i]
		if inStr {
			if c == '\\' {
				i++
				continue
			}
			if c == quote {
				inStr = false
			}
			continue
		}
		switch c {
		case '"', '\'':
			inStr = true
			quote = c
		case '{', '[', '(':
			depth++
		case '}', ']', ')':
			depth--
		case ',':
			if depth == 0 {
				parts = append(parts, strings.TrimSpace(s[start:i]))
				start = i + 1
			}
		}
	}
	if tail := strings.TrimSpace(s[start:]); tail != "" {
		parts = append(parts, tail)
	}
	return parts
}

// SafeGet 安全地从字符串切片中按索引取值；越界时返回空字符串。
func SafeGet(s []string, i int) string {
	if i < len(s) {
		return s[i]
	}
	return ""
}
