package mongoq

// Feature: pprof-redis-proxy, Property 8: mongo 只读方法白名单

import (
	"strings"
	"testing"

	"pgregory.net/rapid"
)

// readonlyWhitelist 是 ParseQuery 允许的只读方法集合（小写）。
var readonlyWhitelist = map[string]bool{
	"find":                   true,
	"findone":                true,
	"count":                  true,
	"countdocuments":         true,
	"estimateddocumentcount": true,
	"aggregate":              true,
	"distinct":               true,
}

// TestProperty8_MongoReadonlyWhitelist 验证：ParseQuery 当且仅当方法名（小写规整后）
// 属于只读白名单时接受查询，其余一律返回错误。
//
// Validates: Requirements 5.4, 5.6, 9.2
func TestProperty8_MongoReadonlyWhitelist(t *testing.T) {
	// 合法的集合名字符集（letter, digit, _, -, .）
	collectionGen := rapid.StringMatching(`[a-zA-Z][a-zA-Z0-9_\-]{0,19}`)

	// 方法名生成器：覆盖白名单方法与任意字母组合（含大小写随机变体）
	methodGen := rapid.OneOf(
		// 白名单方法的随机大小写变体
		rapid.Custom(func(t *rapid.T) string {
			methods := []string{
				"find", "findOne", "count", "countDocuments",
				"estimatedDocumentCount", "aggregate", "distinct",
			}
			base := methods[rapid.IntRange(0, len(methods)-1).Draw(t, "base_idx")]
			// 随机化每个字符的大小写
			result := make([]byte, len(base))
			for i := 0; i < len(base); i++ {
				if rapid.Bool().Draw(t, "upper") {
					result[i] = byte(strings.ToUpper(string(base[i]))[0])
				} else {
					result[i] = byte(strings.ToLower(string(base[i]))[0])
				}
			}
			return string(result)
		}),
		// 任意字母方法名（可能在白名单内也可能不在）
		rapid.StringMatching(`[a-zA-Z]{1,30}`),
	)

	rapid.Check(t, func(t *rapid.T) {
		collection := collectionGen.Draw(t, "collection")
		method := methodGen.Draw(t, "method")

		// 构造格式合法的查询字符串
		query := "db." + collection + "." + method + "({})"

		result, err := ParseQuery(query)
		methodLower := strings.ToLower(method)

		if readonlyWhitelist[methodLower] {
			// 白名单方法：必须接受
			if err != nil {
				t.Fatalf("白名单方法 %q（规整后 %q）应被接受，但返回错误: %v", method, methodLower, err)
			}
			if result == nil {
				t.Fatalf("白名单方法 %q：结果不应为 nil", method)
			}
			// 返回的方法名应为小写
			if result.Method != methodLower {
				t.Fatalf("返回的方法名应为小写 %q，实际得到 %q", methodLower, result.Method)
			}
			// 集合名应与输入一致
			if result.Collection != collection {
				t.Fatalf("集合名应为 %q，实际得到 %q", collection, result.Collection)
			}
		} else {
			// 非白名单方法：必须拒绝
			if err == nil {
				t.Fatalf("非白名单方法 %q（规整后 %q）应被拒绝，但接受成功，结果: %+v", method, methodLower, result)
			}
		}
	})
}
