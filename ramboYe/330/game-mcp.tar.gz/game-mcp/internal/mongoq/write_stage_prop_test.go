package mongoq

// Feature: pprof-redis-proxy, Property 10: aggregate 写阶段被拒绝

import (
	"errors"
	"testing"

	"game-mcp/internal/gwerr"

	"go.mongodb.org/mongo-driver/bson"
	"pgregory.net/rapid"
)

// safeStageKeys is the pool of non-write stage operators used to generate
// benign pipeline stages. $facet/$lookup/$unionWith are excluded here because
// they are generated separately with controlled sub-pipeline content.
var safeStageKeys = []string{
	"$match", "$project", "$group", "$sort", "$limit",
	"$skip", "$unwind", "$addFields", "$count",
	"$replaceRoot", "$bucket", "$sortByCount",
}

// writeStageKeys are the operators that must cause AssertNoWriteStage to error.
var writeStageKeys = []string{"$out", "$merge"}

// systemStageKeys are the operators that expose runtime state and must be rejected.
var systemStageKeys = []string{"$currentOp", "$listSessions", "$listLocalSessions"}

// genSafeStage returns a rapid generator for a single pipeline stage that
// contains no blocked operator and no nested sub-pipeline.
func genSafeStage(t *rapid.T) bson.M {
	key := rapid.SampledFrom(safeStageKeys).Draw(t, "safe_key")
	return bson.M{key: bson.M{}}
}

// genWriteStage returns a pipeline stage containing one of the write operators.
func genWriteStage(t *rapid.T) bson.M {
	key := rapid.SampledFrom(writeStageKeys).Draw(t, "write_key")
	return bson.M{key: "collection"}
}

// genSystemStage returns a pipeline stage containing one of the system operators.
func genSystemStage(t *rapid.T) bson.M {
	key := rapid.SampledFrom(systemStageKeys).Draw(t, "system_key")
	return bson.M{key: bson.M{}}
}

// genBlockedStage returns either a write stage or a system stage — any stage
// that AssertNoWriteStage must reject regardless of position.
func genBlockedStage(t *rapid.T) bson.M {
	if rapid.Bool().Draw(t, "is_write") {
		return genWriteStage(t)
	}
	return genSystemStage(t)
}

// assertKindRejected is a test helper that verifies err is a KindRejected GatewayError.
func assertKindRejected(t *rapid.T, err error, ctx string) {
	t.Helper()
	if err == nil {
		t.Fatalf("%s: expected KindRejected, got nil", ctx)
	}
	var gwErr *gwerr.GatewayError
	if !errors.As(err, &gwErr) {
		t.Fatalf("%s: expected *gwerr.GatewayError, got %T: %v", ctx, err, err)
	}
	if gwErr.Kind != gwerr.KindRejected {
		t.Fatalf("%s: expected KindRejected, got Kind=%v (msg: %s)", ctx, gwErr.Kind, gwErr.Error())
	}
}

// TestAssertNoWriteStage_Property10 is the property-based test for Property 10.
//
// Properties verified:
//  1. A pipeline with no blocked stages (only safe stages) is always accepted.
//  2. A pipeline that contains at least one $out or $merge is always rejected.
//  3. A pipeline that contains a $currentOp/$listSessions/$listLocalSessions is
//     always rejected.
//  4. A $out/$merge nested inside a $facet sub-pipeline is always rejected
//     (Gap 1 fix).
//  5. A $out/$merge inside a $lookup.pipeline is always rejected (Gap 3 fix).
//  6. A $currentOp inside a $facet sub-pipeline is always rejected.
//
// Validates: Requirements 5.8
func TestAssertNoWriteStage_Property10(t *testing.T) {
	// ── 10a: safe pipeline (no blocked stages) → always accepted ─────────
	t.Run("safe_pipeline_accepted", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			n := rapid.IntRange(0, 8).Draw(t, "stage_count")
			pipeline := make([]bson.M, n)
			for i := range pipeline {
				pipeline[i] = genSafeStage(t)
			}
			if err := AssertNoWriteStage(pipeline); err != nil {
				t.Fatalf("safe pipeline unexpectedly rejected: %v", err)
			}
		})
	})

	// ── 10b: blocked stage at arbitrary position → KindRejected ──────────
	t.Run("blocked_stage_at_any_position_rejected", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			prefixLen := rapid.IntRange(0, 4).Draw(t, "prefix_len")
			suffixLen := rapid.IntRange(0, 4).Draw(t, "suffix_len")

			pipeline := make([]bson.M, 0, prefixLen+1+suffixLen)
			for i := 0; i < prefixLen; i++ {
				pipeline = append(pipeline, genSafeStage(t))
			}
			pipeline = append(pipeline, genBlockedStage(t))
			for i := 0; i < suffixLen; i++ {
				pipeline = append(pipeline, genSafeStage(t))
			}

			assertKindRejected(t, AssertNoWriteStage(pipeline),
				"blocked stage in flat pipeline")
		})
	})

	// ── 10c: write stage nested inside $facet → KindRejected (Gap 1) ─────
	t.Run("write_stage_inside_facet_rejected", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			// Build a $facet stage whose "evil" branch hides a write stage.
			writeStage := genWriteStage(t)
			prefixLen := rapid.IntRange(0, 3).Draw(t, "prefix_len")
			subPipeline := make(bson.A, 0, prefixLen+1)
			for i := 0; i < prefixLen; i++ {
				subPipeline = append(subPipeline, genSafeStage(t))
			}
			subPipeline = append(subPipeline, writeStage)

			facetStage := bson.M{
				"$facet": bson.M{
					"legitimateBranch": bson.A{genSafeStage(t)},
					"evilBranch":       subPipeline,
				},
			}

			outerPrefixLen := rapid.IntRange(0, 2).Draw(t, "outer_prefix")
			pipeline := make([]bson.M, 0, outerPrefixLen+1)
			for i := 0; i < outerPrefixLen; i++ {
				pipeline = append(pipeline, genSafeStage(t))
			}
			pipeline = append(pipeline, facetStage)

			assertKindRejected(t, AssertNoWriteStage(pipeline),
				"write stage nested in $facet")
		})
	})

	// ── 10d: system stage nested inside $facet → KindRejected ────────────
	t.Run("system_stage_inside_facet_rejected", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			systemStage := genSystemStage(t)
			facetStage := bson.M{
				"$facet": bson.M{
					"a": bson.A{genSafeStage(t)},
					"b": bson.A{systemStage},
				},
			}
			assertKindRejected(t, AssertNoWriteStage([]bson.M{facetStage}),
				"system stage nested in $facet")
		})
	})

	// ── 10e: write stage inside $lookup.pipeline → KindRejected (Gap 3) ──
	t.Run("write_stage_inside_lookup_pipeline_rejected", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			writeStage := genWriteStage(t)
			prefixLen := rapid.IntRange(0, 3).Draw(t, "prefix_len")
			subPipeline := make(bson.A, 0, prefixLen+1)
			for i := 0; i < prefixLen; i++ {
				subPipeline = append(subPipeline, genSafeStage(t))
			}
			subPipeline = append(subPipeline, writeStage)

			lookupStage := bson.M{
				"$lookup": bson.M{
					"from":     "other_col",
					"pipeline": subPipeline,
					"as":       "result",
				},
			}
			assertKindRejected(t, AssertNoWriteStage([]bson.M{lookupStage}),
				"write stage inside $lookup.pipeline")
		})
	})

	// ── 10f: write stage inside $unionWith.pipeline → KindRejected ───────
	t.Run("write_stage_inside_unionWith_pipeline_rejected", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			writeStage := genWriteStage(t)
			subPipeline := bson.A{genSafeStage(t), writeStage}

			unionStage := bson.M{
				"$unionWith": bson.M{
					"coll":     "other_col",
					"pipeline": subPipeline,
				},
			}
			assertKindRejected(t, AssertNoWriteStage([]bson.M{unionStage}),
				"write stage inside $unionWith.pipeline")
		})
	})

	// ── 10g: $lookup without pipeline field → accepted (no false positive) ─
	t.Run("lookup_without_pipeline_accepted", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			// Standard $lookup with localField/foreignField — no sub-pipeline.
			lookupStage := bson.M{
				"$lookup": bson.M{
					"from":         "other_col",
					"localField":   "id",
					"foreignField": "ref_id",
					"as":           "refs",
				},
			}
			n := rapid.IntRange(0, 3).Draw(t, "extra_stages")
			pipeline := make([]bson.M, 0, n+1)
			for i := 0; i < n; i++ {
				pipeline = append(pipeline, genSafeStage(t))
			}
			pipeline = append(pipeline, lookupStage)
			if err := AssertNoWriteStage(pipeline); err != nil {
				t.Fatalf("$lookup without pipeline field unexpectedly rejected: %v", err)
			}
		})
	})
}
