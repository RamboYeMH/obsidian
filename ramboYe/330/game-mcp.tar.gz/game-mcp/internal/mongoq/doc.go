// Package mongoq provides the read-only MongoDB query library refactored
// from mgq, replacing die()/os.Exit() with error returns.
package mongoq
