package pprofx

import "game-mcp/internal/gwerr"

// ValidProfiles is the set of all accepted pprof profile names (9 total).
// Used by ValidateInput and tests.
var ValidProfiles = map[string]struct{}{
	"allocs":       {},
	"block":        {},
	"cmdline":      {},
	"goroutine":    {},
	"heap":         {},
	"mutex":        {},
	"profile":      {},
	"threadcreate": {},
	"trace":        {},
}

// TimedProfiles is the subset of profiles that accept a seconds duration
// parameter (profile=CPU profiling, trace=execution tracing).
var TimedProfiles = map[string]struct{}{
	"profile": {},
	"trace":   {},
}

// ValidateInput validates the (profile, seconds) pair for a pprof collection
// request. It enforces the following rules in order:
//
//  1. profile must be one of the 9 known names; otherwise returns a validation
//     error and no request is ever issued.
//  2. If seconds is non-nil and its value is outside the range 1..3600,
//     returns a validation error.
//  3. If seconds is non-nil and profile is NOT in {profile, trace}, returns a
//     validation error — seconds is silently ignored for no profile; the caller
//     must not pass it.
//
// Returns nil when all checks pass.
func ValidateInput(profile string, seconds *int) error {
	// Rule 1: profile name must be in the known set.
	if _, ok := ValidProfiles[profile]; !ok {
		return gwerr.Validation("profile 名称不受支持: %s", profile)
	}

	// Rules 2 & 3 only apply when seconds is provided.
	if seconds != nil {
		// Rule 2: seconds must be an integer in 1..3600.
		if *seconds < 1 || *seconds > 3600 {
			return gwerr.Validation("seconds 时长参数必须为 1..3600 之间的整数，实际为: %d", *seconds)
		}

		// Rule 3: only profile/trace accept seconds.
		if _, ok := TimedProfiles[profile]; !ok {
			return gwerr.Validation("该 profile 不接受 seconds 时长参数: %s", profile)
		}
	}

	return nil
}
