package pprofx

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"time"

	"game-mcp/internal/gwerr"
)

// defaultTimeout is the HTTP client timeout used when no seconds parameter is
// provided (non-timed profiles such as heap, goroutine, allocs, etc.).
const defaultTimeout = 60 * time.Second

// timeoutMargin is the extra duration added on top of the requested seconds
// to give the HTTP client enough headroom to receive the full response before
// the transport-level timeout fires.
const timeoutMargin = 30 * time.Second

// Collect fetches a pprof profile from http://<hostIP>:<port>/debug/pprof/<profile>.
//
// URL construction rules (Requirements 7.10, 7.4):
//   - Base URL: http://<hostIP>:<port>/debug/pprof/<profile>
//   - The query parameter ?seconds=<n> is appended ONLY when profile is
//     "profile" or "trace" AND seconds is non-nil.
//
// HTTP client timeout (Requirement 7.15):
//   - When seconds != nil: timeout = (*seconds * time.Second) + timeoutMargin
//   - When seconds == nil: timeout = defaultTimeout (60s)
//
// Only HTTP GET is issued (Requirements 9.4, 9.5).
//
// Error handling (Requirement 7.17):
//   - Connection failure or timeout → gwerr.ConnectionWithCause with details.
//   - Non-2xx HTTP status → gwerr.Upstream with status code and URL.
//
// The ctx is respected via http.NewRequestWithContext.
//
// Requirements: 7.10, 7.15, 7.17, 9.4, 9.5
func Collect(ctx context.Context, hostIP string, port int, profile string, seconds *int) ([]byte, error) {
	// 1. Build the base URL.
	rawURL := fmt.Sprintf("http://%s:%d/debug/pprof/%s", hostIP, port, profile)

	// 2. Append ?seconds= only for timed profiles when seconds is provided.
	if seconds != nil {
		if _, isTimed := TimedProfiles[profile]; isTimed {
			rawURL = fmt.Sprintf("%s?seconds=%d", rawURL, *seconds)
		}
	}

	// 3. Determine HTTP client timeout.
	var timeout time.Duration
	if seconds != nil {
		timeout = time.Duration(*seconds)*time.Second + timeoutMargin
	} else {
		timeout = defaultTimeout
	}

	client := &http.Client{Timeout: timeout}

	// 4. Build GET request with context so the caller's cancellation is respected.
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, rawURL, nil)
	if err != nil {
		// This should only happen for a malformed URL; treat as a connection error.
		return nil, gwerr.ConnectionWithCause(err,
			"无法构建 pprof 请求 URL %s: %v", rawURL, err)
	}

	// 5. Issue the HTTP GET.
	resp, err := client.Do(req)
	if err != nil {
		return nil, gwerr.ConnectionWithCause(err,
			"连接 pprof 端点失败 %s: %v", rawURL, err)
	}
	defer resp.Body.Close()

	// 6. Check for non-2xx status.
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, gwerr.Upstream("pprof 请求返回非成功状态 %d: %s", resp.StatusCode, rawURL)
	}

	// 7. Read and return the response body.
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, gwerr.ConnectionWithCause(err,
			"读取 pprof 响应体失败 %s: %v", rawURL, err)
	}

	return body, nil
}
