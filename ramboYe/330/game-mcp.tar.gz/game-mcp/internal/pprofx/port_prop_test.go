// Feature: pprof-redis-proxy, Property 13: pprof 端口推导
package pprofx_test

import (
	"testing"

	"pgregory.net/rapid"

	"game-mcp/internal/pprofx"
)

// TestDerivePortProperty13 is a property-based test for Property 13: pprof 端口推导.
//
// Validates: Requirements 7.18, 7.19, 7.20, 7.21
//
// Properties verified:
//  1. For a service-type present in the bases map, DerivePort returns base+serverid
//     when the result is within [1, 65535].
//  2. For a service-type NOT present in the bases map, DerivePort returns an
//     "未知 service-type" error.
//  3. When base+serverid falls outside [1, 65535], DerivePort returns a
//     "端口超出范围" error.
func TestDerivePortProperty13(t *testing.T) {
	rapid.Check(t, func(rt *rapid.T) {
		// --- generator: build a bases map with 1..5 entries ---
		numServices := rapid.IntRange(1, 5).Draw(rt, "numServices")

		// Generate service names: lowercase ASCII letters, length 1..8.
		serviceGen := rapid.StringMatching(`[a-z]{1,8}`)
		bases := make(map[string]int, numServices)
		serviceNames := make([]string, 0, numServices)
		for i := 0; i < numServices; i++ {
			name := serviceGen.Draw(rt, "serviceName")
			if _, dup := bases[name]; dup {
				// Skip duplicates to keep the map size predictable.
				continue
			}
			// Base port in 1..65535 so the map itself is always valid.
			base := rapid.IntRange(1, 65535).Draw(rt, "base")
			bases[name] = base
			serviceNames = append(serviceNames, name)
		}
		if len(serviceNames) == 0 {
			// Degenerate case: all names collided — skip this draw.
			rt.Skip("all generated service names collided, skipping")
		}

		// --- scenario selection ---
		scenarioChoice := rapid.IntRange(0, 2).Draw(rt, "scenario")
		// 0 = known service, in-range result
		// 1 = known service, out-of-range result
		// 2 = unknown service

		switch scenarioChoice {
		case 0:
			// Property: known service + in-range serverid → port = base + serverid
			idx := rapid.IntRange(0, len(serviceNames)-1).Draw(rt, "serviceIdx")
			service := serviceNames[idx]
			base := bases[service]

			// Constrain serverid so that base+serverid is within [1, 65535].
			maxServerid := 65535 - base
			if maxServerid < 0 {
				// base is already at 65535; any positive serverid would overflow.
				// Use serverid=0 but that produces base+0=base which is >=1 and <=65535.
				maxServerid = 0
			}
			serverid := rapid.IntRange(0, maxServerid).Draw(rt, "serveridInRange")

			port, err := pprofx.DerivePort(bases, service, serverid)
			if err != nil {
				rt.Fatalf("expected success for known service %q with serverid %d (base=%d), got error: %v",
					service, serverid, base, err)
			}
			expected := base + serverid
			if port != expected {
				rt.Fatalf("wrong port for service %q: got %d, want %d (base=%d, serverid=%d)",
					service, port, expected, base, serverid)
			}

		case 1:
			// Property: known service + out-of-range result → "端口超出范围" error
			idx := rapid.IntRange(0, len(serviceNames)-1).Draw(rt, "serviceIdx")
			service := serviceNames[idx]
			base := bases[service]

			// Pick a serverid that pushes the result outside [1, 65535].
			// Either a large positive (overflow above 65535) or a large negative
			// (underflow below 1).
			outChoice := rapid.Bool().Draw(rt, "overUnder")
			var serverid int
			if outChoice {
				// overflow: base + serverid > 65535
				serverid = rapid.IntRange(65535-base+1, 65536).Draw(rt, "serveridOver")
			} else {
				// underflow: base + serverid < 1  →  serverid < 1 - base
				limit := -base // base + limit = 0, which is < 1
				serverid = rapid.IntRange(limit-10, limit).Draw(rt, "serveridUnder")
			}

			_, err := pprofx.DerivePort(bases, service, serverid)
			if err == nil {
				port := base + serverid
				rt.Fatalf("expected 端口超出范围 error for service %q serverid %d (base=%d, port=%d) but got nil",
					service, serverid, base, port)
			}

		case 2:
			// Property: unknown service-type → error (未知 service-type)
			// Generate a service name guaranteed not to be in the bases map.
			unknown := serviceGen.
				Filter(func(s string) bool {
					_, exists := bases[s]
					return !exists
				}).
				Draw(rt, "unknownService")

			serverid := rapid.IntRange(0, 1000).Draw(rt, "serverid")

			_, err := pprofx.DerivePort(bases, unknown, serverid)
			if err == nil {
				rt.Fatalf("expected 未知 service-type error for service %q but got nil", unknown)
			}
		}
	})
}
