package pprofx

// Feature: pprof-redis-proxy, Property 16: base64 采集结果往返

import (
	"encoding/base64"
	"testing"

	"pgregory.net/rapid"
)

// TestBase64RoundTrip verifies Property 16: for any random byte slice,
// EncodeBase64 followed by base64 decoding returns the original bytes.
//
// Validates: Requirements 7.14
func TestBase64RoundTrip(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		// Generate a random byte slice (0..512 bytes)
		data := rapid.SliceOfN(rapid.Byte(), 0, 512).Draw(t, "data")

		encoded := EncodeBase64(data)

		decoded, err := base64.StdEncoding.DecodeString(encoded)
		if err != nil {
			t.Fatalf("base64 decode failed for encoded output: %v", err)
		}

		if len(data) == 0 && len(decoded) == 0 {
			// Both empty — round-trip holds
			return
		}

		if len(decoded) != len(data) {
			t.Fatalf("round-trip length mismatch: got %d, want %d", len(decoded), len(data))
		}

		for i := range data {
			if decoded[i] != data[i] {
				t.Fatalf("round-trip byte mismatch at index %d: got %d, want %d", i, decoded[i], data[i])
			}
		}
	})
}
