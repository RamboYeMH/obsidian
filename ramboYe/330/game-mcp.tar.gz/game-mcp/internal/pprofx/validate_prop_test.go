// Feature: pprof-redis-proxy, Property 12: pprof 输入校验判定
package pprofx_test

import (
	"testing"

	"pgregory.net/rapid"

	"game-mcp/internal/pprofx"
)

// validProfileNames lists the 9 allowed pprof profile names.
var validProfileNames = []string{
	"allocs", "block", "cmdline", "goroutine", "heap",
	"mutex", "profile", "threadcreate", "trace",
}

// timedProfileNames lists profiles that accept a seconds parameter.
var timedProfileNames = map[string]bool{
	"profile": true,
	"trace":   true,
}

// TestValidateInputProperty12 is a property-based test for Property 12:
// pprof 输入校验判定.
//
// Validates: Requirements 7.2, 7.3, 7.4, 7.5, 9.5
//
// Properties verified:
//  1. Any unknown profile name is always rejected.
//  2. A valid profile with nil seconds is always accepted.
//  3. For "profile" and "trace", seconds in [1,3600] is accepted; outside that
//     range is rejected.
//  4. For all other valid profiles, any non-nil seconds value is rejected
//     regardless of its magnitude — no request should be issued.
func TestValidateInputProperty12(t *testing.T) {
	rapid.Check(t, func(rt *rapid.T) {
		// --- generator: pick profile (valid or invalid) ---
		useValidProfile := rapid.Bool().Draw(rt, "useValidProfile")

		var profile string
		if useValidProfile {
			idx := rapid.IntRange(0, len(validProfileNames)-1).Draw(rt, "profileIdx")
			profile = validProfileNames[idx]
		} else {
			// Generate an arbitrary string that is NOT in the valid set.
			profile = rapid.StringMatching(`[a-zA-Z0-9_-]{1,20}`).
				Filter(func(s string) bool {
					_, ok := pprofx.ValidProfiles[s]
					return !ok
				}).
				Draw(rt, "invalidProfile")
		}

		// --- generator: seconds (nil / valid range / out-of-range) ---
		secondsChoice := rapid.IntRange(0, 2).Draw(rt, "secondsChoice")
		// 0 = nil, 1 = in [1,3600], 2 = out-of-range
		var seconds *int
		switch secondsChoice {
		case 1:
			v := rapid.IntRange(1, 3600).Draw(rt, "seconds")
			seconds = &v
		case 2:
			// out-of-range: either 0, negative, or > 3600
			v := rapid.OneOf(
				rapid.IntRange(-10000, 0),
				rapid.IntRange(3601, 10000),
			).Draw(rt, "secondsOOB")
			seconds = &v
		}

		err := pprofx.ValidateInput(profile, seconds)

		if !useValidProfile {
			// Property: unknown profile must always be rejected.
			if err == nil {
				rt.Fatalf("expected rejection for unknown profile %q but got nil error", profile)
			}
			return
		}

		// profile is valid from here on.

		if seconds == nil {
			// Property: valid profile with no seconds must always be accepted.
			if err != nil {
				rt.Fatalf("expected nil error for valid profile %q with nil seconds, got: %v", profile, err)
			}
			return
		}

		// seconds is non-nil.
		if secondsChoice == 2 {
			// Property: out-of-range seconds must always be rejected.
			if err == nil {
				rt.Fatalf("expected rejection for out-of-range seconds with profile %q, got nil error", profile)
			}
			return
		}

		// seconds is in [1,3600].
		if timedProfileNames[profile] {
			// Property: timed profiles (profile/trace) with valid seconds must be accepted.
			if err != nil {
				rt.Fatalf("expected nil error for timed profile %q with valid seconds, got: %v", profile, err)
			}
		} else {
			// Property: non-timed profiles must reject any seconds value — no request is issued.
			if err == nil {
				rt.Fatalf("expected rejection for non-timed profile %q with seconds, got nil error", profile)
			}
		}
	})
}
