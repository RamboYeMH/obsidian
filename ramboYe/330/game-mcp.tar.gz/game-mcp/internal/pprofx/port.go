package pprofx

import "game-mcp/internal/gwerr"

// DerivePort computes the pprof port for a given service and server ID.
//
// It looks up the base port for service in the bases map (typically sourced
// from config.PprofPortBases after merging built-in defaults), adds serverid,
// and validates the result falls within the valid TCP port range [1, 65535].
//
// Errors:
//   - 「未知 service-type: <service>」 (KindValidation) if service has no entry in bases.
//   - 「端口超出范围: <port>」 (KindValidation) if base+serverid is outside [1, 65535].
func DerivePort(bases map[string]int, service string, serverid int) (int, error) {
	base, ok := bases[service]
	if !ok {
		return 0, gwerr.Validation("未知 service-type: %s", service)
	}

	port := base + serverid
	if port < 1 || port > 65535 {
		return 0, gwerr.Validation("端口超出范围: %d", port)
	}

	return port, nil
}
