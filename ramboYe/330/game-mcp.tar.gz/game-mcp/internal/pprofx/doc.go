// Package pprofx handles pprof profile collection via HTTP GET,
// port derivation, and cmdline redaction.
package pprofx
