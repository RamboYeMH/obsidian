package pprofx

// Feature: pprof-redis-proxy, Property 15: cmdline 脱敏绝不泄露密钥
//
// Validates: Requirements 7.11, 7.12, 7.13, 9.9, 11.4

import (
	"bytes"
	"fmt"
	"testing"

	"pgregory.net/rapid"
)

// safeKeyGen generates a non-empty alphanumeric string (4-16 chars) that can
// serve as a secret key/password embedded in cmdline arguments.  It avoids
// characters that are special in URL syntax or shell quoting (@, :, /, ?, &,
// =, space) so the injected key can be placed in any of the three injection
// points (connection string, flag value, URL query param) without accidentally
// matching a delimiter and confusing the position of the secret.
var safeKeyGen = rapid.StringMatching(`[a-zA-Z0-9]{4,16}`)

// hostGen generates a simple hostname/IP-like string with no special URL chars.
var hostGen = rapid.StringMatching(`[a-zA-Z0-9]{2,10}`)

// userGen generates a username-safe string (word chars only, no colon/at/slash).
var userGen = rapid.StringMatching(`[a-zA-Z][a-zA-Z0-9]{1,8}`)

// buildConnStringCmdline embeds key in the password position of a
// "user:pass@host" connection string inside a mock process invocation.
// e.g.: /usr/bin/server --db user:SECRETKEY@db-host:5432/mydb
func buildConnStringCmdline(user, key, host string) string {
	return fmt.Sprintf("/usr/bin/server --db %s:%s@%s:5432/appdb --loglevel info", user, key, host)
}

// buildFlagEqCmdline embeds key as the value of a "--password=VALUE" flag.
func buildFlagEqCmdline(key string) string {
	return fmt.Sprintf("/usr/bin/server --config /etc/app.yaml --password=%s --port 8080", key)
}

// buildFlagSpaceCmdline embeds key as the value of a "--password VALUE" flag
// (space-separated form).
func buildFlagSpaceCmdline(key string) string {
	return fmt.Sprintf("/usr/bin/server --config /etc/app.yaml --password %s --port 8080", key)
}

// buildFlagTokenCmdline embeds key as the value of a "--token=VALUE" flag.
func buildFlagTokenCmdline(key string) string {
	return fmt.Sprintf("/usr/bin/server --token=%s --endpoint https://api.example.com", key)
}

// buildFlagSecretCmdline embeds key as the value of a "--secret=VALUE" flag.
func buildFlagSecretCmdline(key string) string {
	return fmt.Sprintf("/usr/bin/server --secret=%s --region us-east-1", key)
}

// buildFlagKeyCmdline embeds key as the value of a "--key VALUE" flag
// (space-separated).
func buildFlagKeyCmdline(key string) string {
	return fmt.Sprintf("/usr/bin/server --key %s --algorithm AES256", key)
}

// buildURLParamPasswordCmdline embeds key as the value of a "password=" query
// parameter in a connection URL appearing in the cmdline.
func buildURLParamPasswordCmdline(key string) string {
	return fmt.Sprintf("/usr/bin/server --dsn https://db.local/path?user=admin&password=%s&timeout=30", key)
}

// buildURLParamTokenCmdline embeds key as "token=" in a URL query parameter.
func buildURLParamTokenCmdline(key string) string {
	return fmt.Sprintf("/usr/bin/client https://api.example.com/v1?token=%s&format=json", key)
}

// buildURLParamSecretCmdline embeds key as "secret=" in a URL query parameter.
func buildURLParamSecretCmdline(key string) string {
	return fmt.Sprintf("/usr/bin/client https://api.example.com/v1?secret=%s&format=json", key)
}

// buildURLParamKeyCmdline embeds key as "key=" in a URL query parameter.
func buildURLParamKeyCmdline(key string) string {
	return fmt.Sprintf("/usr/bin/client https://api.example.com/v1?key=%s&format=json", key)
}

// assertKeyNotLeaked calls RedactCmdline on input and asserts the secret key
// does not appear in the output.  If redaction returns an error, that is
// acceptable (requirements 7.13 / 11.4: return error rather than original
// text); in that case it verifies the returned bytes are nil.
func assertKeyNotLeaked(t *rapid.T, input, key string) {
	t.Helper()
	out, err := RedactCmdline([]byte(input))
	if err != nil {
		// Error + nil output is acceptable — no partial leakage.
		if out != nil {
			t.Fatalf("RedactCmdline returned error AND non-nil bytes: out=%q err=%v", out, err)
		}
		return
	}
	// Redaction succeeded — the output must not contain the key.
	if bytes.Contains(out, []byte(key)) {
		t.Fatalf("RedactCmdline leaked key %q in output %q (input: %q)", key, out, input)
	}
}

// TestRedactCmdline_Property15_ConnStringKeyNotLeaked verifies that a secret
// key embedded in the password position of a connection string is masked.
//
// Validates: Requirements 7.11, 7.12, 7.13, 9.9, 11.4
func TestRedactCmdline_Property15_ConnStringKeyNotLeaked(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		user := userGen.Draw(t, "user")
		key := safeKeyGen.Draw(t, "key")
		host := hostGen.Draw(t, "host")

		// Ensure user != key so we are specifically checking for key leakage,
		// not the username (which should be preserved).
		if user == key {
			t.Skip()
		}

		input := buildConnStringCmdline(user, key, host)
		assertKeyNotLeaked(t, input, key)
	})
}

// TestRedactCmdline_Property15_FlagEqKeyNotLeaked verifies that a secret key
// embedded as "--password=KEY" is masked.
//
// Validates: Requirements 7.12, 7.13, 9.9, 11.4
func TestRedactCmdline_Property15_FlagEqKeyNotLeaked(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		key := safeKeyGen.Draw(t, "key")
		input := buildFlagEqCmdline(key)
		assertKeyNotLeaked(t, input, key)
	})
}

// TestRedactCmdline_Property15_FlagSpaceKeyNotLeaked verifies that a secret
// key embedded as "--password KEY" (space form) is masked.
//
// Validates: Requirements 7.12, 7.13, 9.9, 11.4
func TestRedactCmdline_Property15_FlagSpaceKeyNotLeaked(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		key := safeKeyGen.Draw(t, "key")
		input := buildFlagSpaceCmdline(key)
		assertKeyNotLeaked(t, input, key)
	})
}

// TestRedactCmdline_Property15_FlagTokenNotLeaked verifies that "--token=KEY"
// is masked.
//
// Validates: Requirements 7.12, 7.13, 9.9, 11.4
func TestRedactCmdline_Property15_FlagTokenNotLeaked(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		key := safeKeyGen.Draw(t, "key")
		input := buildFlagTokenCmdline(key)
		assertKeyNotLeaked(t, input, key)
	})
}

// TestRedactCmdline_Property15_FlagSecretNotLeaked verifies that "--secret=KEY"
// is masked.
//
// Validates: Requirements 7.12, 7.13, 9.9, 11.4
func TestRedactCmdline_Property15_FlagSecretNotLeaked(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		key := safeKeyGen.Draw(t, "key")
		input := buildFlagSecretCmdline(key)
		assertKeyNotLeaked(t, input, key)
	})
}

// TestRedactCmdline_Property15_FlagKeySpaceNotLeaked verifies that "--key KEY"
// (space form) is masked.
//
// Validates: Requirements 7.12, 7.13, 9.9, 11.4
func TestRedactCmdline_Property15_FlagKeySpaceNotLeaked(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		key := safeKeyGen.Draw(t, "key")
		input := buildFlagKeyCmdline(key)
		assertKeyNotLeaked(t, input, key)
	})
}

// TestRedactCmdline_Property15_URLParamPasswordNotLeaked verifies that
// "password=KEY" in a URL query string is masked.
//
// Validates: Requirements 7.12, 7.13, 9.9, 11.4
func TestRedactCmdline_Property15_URLParamPasswordNotLeaked(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		key := safeKeyGen.Draw(t, "key")
		input := buildURLParamPasswordCmdline(key)
		assertKeyNotLeaked(t, input, key)
	})
}

// TestRedactCmdline_Property15_URLParamTokenNotLeaked verifies that
// "token=KEY" in a URL query string is masked.
//
// Validates: Requirements 7.12, 7.13, 9.9, 11.4
func TestRedactCmdline_Property15_URLParamTokenNotLeaked(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		key := safeKeyGen.Draw(t, "key")
		input := buildURLParamTokenCmdline(key)
		assertKeyNotLeaked(t, input, key)
	})
}

// TestRedactCmdline_Property15_URLParamSecretNotLeaked verifies that
// "secret=KEY" in a URL query string is masked.
//
// Validates: Requirements 7.12, 7.13, 9.9, 11.4
func TestRedactCmdline_Property15_URLParamSecretNotLeaked(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		key := safeKeyGen.Draw(t, "key")
		input := buildURLParamSecretCmdline(key)
		assertKeyNotLeaked(t, input, key)
	})
}

// TestRedactCmdline_Property15_URLParamKeyNotLeaked verifies that
// "key=KEY" in a URL query string is masked.
//
// Validates: Requirements 7.12, 7.13, 9.9, 11.4
func TestRedactCmdline_Property15_URLParamKeyNotLeaked(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		key := safeKeyGen.Draw(t, "key")
		input := buildURLParamKeyCmdline(key)
		assertKeyNotLeaked(t, input, key)
	})
}

// TestRedactCmdline_Property15_MultipleSecretsNotLeaked verifies that when
// all three injection points (connection string + flag + URL param) appear in
// the same cmdline, none of the three secrets leak.
//
// Validates: Requirements 7.11, 7.12, 7.13, 9.9, 11.4
func TestRedactCmdline_Property15_MultipleSecretsNotLeaked(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		user := userGen.Draw(t, "user")
		connKey := safeKeyGen.Draw(t, "connKey")
		flagKey := safeKeyGen.Draw(t, "flagKey")
		urlKey := safeKeyGen.Draw(t, "urlKey")
		host := hostGen.Draw(t, "host")

		// Construct a cmdline with all three injection points on a single line.
		input := fmt.Sprintf(
			"/usr/bin/server --db %s:%s@%s:5432/appdb --password=%s https://api.example.com/v1?token=%s",
			user, connKey, host, flagKey, urlKey,
		)

		out, err := RedactCmdline([]byte(input))
		if err != nil {
			// Error + nil output is acceptable (no leakage).
			if out != nil {
				t.Fatalf("RedactCmdline returned error AND non-nil bytes: out=%q err=%v", out, err)
			}
			return
		}

		for _, key := range []string{connKey, flagKey, urlKey} {
			if bytes.Contains(out, []byte(key)) {
				t.Fatalf("RedactCmdline leaked key %q in output %q (input: %q)", key, out, input)
			}
		}
	})
}

// TestRedactCmdline_Property15_ErrorReturnsNilBytes verifies the contract that
// when RedactCmdline returns an error it never simultaneously returns non-nil
// (potentially unredacted) bytes — the requirement is "error or masked, never
// original".
//
// Validates: Requirements 7.13, 11.4
func TestRedactCmdline_Property15_ErrorReturnsNilBytes(t *testing.T) {
	rapid.Check(t, func(t *rapid.T) {
		key := safeKeyGen.Draw(t, "key")
		input := buildFlagEqCmdline(key)

		out, err := RedactCmdline([]byte(input))
		if err != nil && out != nil {
			t.Fatalf("contract violated: RedactCmdline returned both error and non-nil bytes: out=%q err=%v", out, err)
		}
	})
}
