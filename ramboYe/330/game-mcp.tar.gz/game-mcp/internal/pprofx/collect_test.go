package pprofx

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"game-mcp/internal/gwerr"
)

// ptr is a helper to obtain a pointer to an int literal.
func ptr(n int) *int { return &n }

// TestCollect_2xxSuccess verifies that a 2xx response returns the body bytes.
// Requirements: 7.10, 7.17
func TestCollect_2xxSuccess(t *testing.T) {
	want := []byte("pprof data payload")
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write(want)
	}))
	defer srv.Close()

	host, port := splitHostPort(t, srv.URL)

	got, err := Collect(context.Background(), host, port, "heap", nil)
	if err != nil {
		t.Fatalf("expected no error, got: %v", err)
	}
	if string(got) != string(want) {
		t.Fatalf("body mismatch: got %q, want %q", got, want)
	}
}

// TestCollect_2xxVariousStatuses verifies several 2xx status codes all succeed.
// Requirements: 7.10
func TestCollect_2xxVariousStatuses(t *testing.T) {
	for _, code := range []int{200, 201, 204} {
		code := code
		t.Run(fmt.Sprintf("status_%d", code), func(t *testing.T) {
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.WriteHeader(code)
				if code != 204 {
					_, _ = w.Write([]byte("ok"))
				}
			}))
			defer srv.Close()

			host, port := splitHostPort(t, srv.URL)
			_, err := Collect(context.Background(), host, port, "goroutine", nil)
			if err != nil {
				t.Fatalf("status %d: expected no error, got: %v", code, err)
			}
		})
	}
}

// TestCollect_Non2xxReturnsUpstreamError verifies non-2xx responses produce a
// KindUpstream error containing the status code and URL.
// Requirements: 7.17
func TestCollect_Non2xxReturnsUpstreamError(t *testing.T) {
	for _, code := range []int{400, 404, 500, 503} {
		code := code
		t.Run(fmt.Sprintf("status_%d", code), func(t *testing.T) {
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				http.Error(w, "backend error", code)
			}))
			defer srv.Close()

			host, port := splitHostPort(t, srv.URL)
			_, err := Collect(context.Background(), host, port, "heap", nil)
			if err == nil {
				t.Fatalf("status %d: expected error, got nil", code)
			}

			var gw *gwerr.GatewayError
			if !errors.As(err, &gw) {
				t.Fatalf("status %d: expected *gwerr.GatewayError, got %T: %v", code, err, err)
			}
			if gw.Kind != gwerr.KindUpstream {
				t.Fatalf("status %d: expected KindUpstream, got %v", code, gw.Kind)
			}
			// Error message must contain the status code.
			if !strings.Contains(gw.Error(), fmt.Sprintf("%d", code)) {
				t.Fatalf("status %d: error message %q does not contain status code", code, gw.Error())
			}
		})
	}
}

// TestCollect_ConnectionFailureReturnsConnectionError verifies that a refused
// connection produces a KindConnection error.
// Requirements: 7.17
func TestCollect_ConnectionFailureReturnsConnectionError(t *testing.T) {
	// Use a port that is not listening (bind then immediately close).
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	port := ln.Addr().(*net.TCPAddr).Port
	ln.Close() // immediately free the port so connection will be refused

	_, cerr := Collect(context.Background(), "127.0.0.1", port, "heap", nil)
	if cerr == nil {
		t.Fatal("expected error for refused connection, got nil")
	}

	var gw *gwerr.GatewayError
	if !errors.As(cerr, &gw) {
		t.Fatalf("expected *gwerr.GatewayError, got %T: %v", cerr, cerr)
	}
	if gw.Kind != gwerr.KindConnection {
		t.Fatalf("expected KindConnection, got %v", gw.Kind)
	}
}

// TestCollect_TimeoutReturnsConnectionError verifies that a server that hangs
// beyond the client timeout produces a KindConnection error.
// Requirements: 7.17
func TestCollect_TimeoutReturnsConnectionError(t *testing.T) {
	// Server that blocks until the client times out.
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Sleep longer than the margin so Collect's HTTP client times out first.
		time.Sleep(10 * time.Second)
	}))
	defer srv.Close()

	// Use a very small seconds value (1) so timeout = 1s + 30s = 31s would
	// normally be too long for a unit test.  Instead, cancel via context.
	ctx, cancel := context.WithTimeout(context.Background(), 200*time.Millisecond)
	defer cancel()

	host, port := splitHostPort(t, srv.URL)
	_, err := Collect(ctx, host, port, "goroutine", nil)
	if err == nil {
		t.Fatal("expected timeout error, got nil")
	}

	var gw *gwerr.GatewayError
	if !errors.As(err, &gw) {
		t.Fatalf("expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	if gw.Kind != gwerr.KindConnection {
		t.Fatalf("expected KindConnection, got %v", gw.Kind)
	}
}

// TestCollect_URLConstructionNoSeconds verifies the URL is built as
// http://<host>:<port>/debug/pprof/<profile> with no query string when seconds
// is nil, or when the profile is not a timed profile.
// Requirements: 7.10
func TestCollect_URLConstructionNoSeconds(t *testing.T) {
	cases := []struct {
		profile string
		seconds *int
		wantURL string
	}{
		// Non-timed profile: seconds must not be appended even if provided.
		{"heap", nil, "/debug/pprof/heap"},
		{"goroutine", nil, "/debug/pprof/goroutine"},
		{"allocs", nil, "/debug/pprof/allocs"},
		// Timed profile without seconds: no query string.
		{"profile", nil, "/debug/pprof/profile"},
		// Non-timed profile with seconds provided: seconds must NOT be appended.
		{"heap", ptr(5), "/debug/pprof/heap"},
	}

	for _, tc := range cases {
		tc := tc
		name := tc.profile
		if tc.seconds != nil {
			name += fmt.Sprintf("_seconds%d", *tc.seconds)
		} else {
			name += "_noseconds"
		}
		t.Run(name, func(t *testing.T) {
			var gotPath string
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				gotPath = r.URL.RequestURI() // path + query
				w.WriteHeader(http.StatusOK)
			}))
			defer srv.Close()

			host, port := splitHostPort(t, srv.URL)
			_, _ = Collect(context.Background(), host, port, tc.profile, tc.seconds)

			if gotPath != tc.wantURL {
				t.Fatalf("URL: got %q, want %q", gotPath, tc.wantURL)
			}
		})
	}
}

// TestCollect_URLConstructionWithSeconds verifies ?seconds=N is appended for
// timed profiles (profile, trace) when seconds is provided.
// Requirements: 7.10
func TestCollect_URLConstructionWithSeconds(t *testing.T) {
	cases := []struct {
		profile string
		seconds int
	}{
		{"profile", 10},
		{"trace", 5},
	}

	for _, tc := range cases {
		tc := tc
		t.Run(fmt.Sprintf("%s_seconds%d", tc.profile, tc.seconds), func(t *testing.T) {
			var gotURI string
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				gotURI = r.URL.RequestURI()
				w.WriteHeader(http.StatusOK)
			}))
			defer srv.Close()

			host, port := splitHostPort(t, srv.URL)
			_, _ = Collect(context.Background(), host, port, tc.profile, ptr(tc.seconds))

			wantURI := fmt.Sprintf("/debug/pprof/%s?seconds=%d", tc.profile, tc.seconds)
			if gotURI != wantURI {
				t.Fatalf("URI: got %q, want %q", gotURI, wantURI)
			}
		})
	}
}

// TestCollect_OnlyGET verifies that Collect always issues an HTTP GET request.
// Requirements: 9.4, 9.5
func TestCollect_OnlyGET(t *testing.T) {
	profiles := []string{"heap", "goroutine", "allocs", "profile", "trace"}

	for _, profile := range profiles {
		profile := profile
		t.Run(profile, func(t *testing.T) {
			var gotMethod string
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				gotMethod = r.Method
				w.WriteHeader(http.StatusOK)
			}))
			defer srv.Close()

			host, port := splitHostPort(t, srv.URL)
			_, _ = Collect(context.Background(), host, port, profile, nil)

			if gotMethod != http.MethodGet {
				t.Fatalf("profile %q: expected GET, got %q", profile, gotMethod)
			}
		})
	}
}

// TestCollect_ContextCancellationReturnsConnectionError verifies that
// cancelling the context before the request completes returns a KindConnection
// error.
func TestCollect_ContextCancellationReturnsConnectionError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		time.Sleep(5 * time.Second)
	}))
	defer srv.Close()

	ctx, cancel := context.WithCancel(context.Background())
	cancel() // cancel immediately

	host, port := splitHostPort(t, srv.URL)
	_, err := Collect(ctx, host, port, "heap", nil)
	if err == nil {
		t.Fatal("expected error for cancelled context, got nil")
	}

	var gw *gwerr.GatewayError
	if !errors.As(err, &gw) {
		t.Fatalf("expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	if gw.Kind != gwerr.KindConnection {
		t.Fatalf("expected KindConnection, got %v", gw.Kind)
	}
}

// splitHostPort parses an httptest server URL and returns the host string and
// port as an int, failing the test on parse errors.
func splitHostPort(t *testing.T, rawURL string) (string, int) {
	t.Helper()
	// rawURL is like "http://127.0.0.1:PORT"
	trimmed := strings.TrimPrefix(rawURL, "http://")
	host, portStr, err := net.SplitHostPort(trimmed)
	if err != nil {
		t.Fatalf("splitHostPort(%q): %v", rawURL, err)
	}
	var port int
	if _, err := fmt.Sscanf(portStr, "%d", &port); err != nil {
		t.Fatalf("parse port %q: %v", portStr, err)
	}
	return host, port
}
