package pprofx

import (
	"encoding/base64"
	"fmt"

	"game-mcp/internal/gwerr"
	"game-mcp/internal/secret"
)

// RedactCmdline applies cmdline redaction using the secret package primitives.
// On any redaction failure the error is wrapped with gwerr.Redaction and
// returned — the original raw bytes are NEVER returned to the caller.
//
// Requirements: 7.11, 7.12, 7.13
func RedactCmdline(raw []byte) ([]byte, error) {
	out, err := secret.RedactCmdline(raw)
	if err != nil {
		// Wrap with KindRedaction so callers know this is a redaction failure
		// and must not fall back to returning the unredacted content.
		return nil, gwerr.Redaction("cmdline 脱敏失败: %v", err)
	}
	return out, nil
}

// EncodeBase64 encodes data using standard base64 encoding (RFC 4648).
//
// Requirements: 7.14
func EncodeBase64(data []byte) string {
	return base64.StdEncoding.EncodeToString(data)
}

// PrepareProfileResult prepares the final profile result for returning to the
// caller:
//   - For "cmdline": redacts first (returning an error if redaction fails,
//     never the original bytes), then base64-encodes the redacted output.
//   - For all other profiles: base64-encodes the raw data directly.
//
// The returned string is always a base64-encoded blob (Requirements 7.14).
//
// Requirements: 7.11, 7.12, 7.13, 7.14
func PrepareProfileResult(data []byte, profile string) (string, error) {
	if profile == "cmdline" {
		redacted, err := RedactCmdline(data)
		if err != nil {
			// err is already a gwerr.Redaction error from RedactCmdline.
			return "", fmt.Errorf("PrepareProfileResult: %w", err)
		}
		return EncodeBase64(redacted), nil
	}
	return EncodeBase64(data), nil
}
