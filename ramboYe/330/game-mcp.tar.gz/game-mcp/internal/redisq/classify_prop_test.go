// Feature: pprof-redis-proxy, Property 11: Redis 命令分类大小写无关且默认拒绝

// Validates: Requirements 6.6, 6.7, 6.8, 6.9, 6.10, 9.3

package redisq

import (
	"strings"
	"testing"
	"unicode"

	"pgregory.net/rapid"
)

// allReadonly returns the keys of the readonlyCommands map as a slice.
func allReadonly() []string {
	cmds := make([]string, 0, len(readonlyCommands))
	for k := range readonlyCommands {
		cmds = append(cmds, k)
	}
	return cmds
}

// allDangerous returns the keys of the dangerousCommands map as a slice.
func allDangerous() []string {
	cmds := make([]string, 0, len(dangerousCommands))
	for k := range dangerousCommands {
		cmds = append(cmds, k)
	}
	return cmds
}

// allWrite returns the keys of the writeCommands map as a slice.
func allWrite() []string {
	cmds := make([]string, 0, len(writeCommands))
	for k := range writeCommands {
		cmds = append(cmds, k)
	}
	return cmds
}

// randomCaseVariant returns a randomly-cased version of s.
func randomCaseVariant(t *rapid.T, s string) string {
	runes := []rune(s)
	var b strings.Builder
	for i, r := range runes {
		if rapid.Bool().Draw(t, strings.ToLower(string(unicode.ToUpper(r)))+"_upper") {
			_ = i
			b.WriteRune(unicode.ToUpper(r))
		} else {
			b.WriteRune(unicode.ToLower(r))
		}
	}
	return b.String()
}

// TestProp11_ReadonlyCaseMismatch verifies that readonly commands are allowed
// regardless of the casing used (≥100 iterations via rapid default).
func TestProp11_ReadonlyCaseMismatch(t *testing.T) {
	readonlyList := allReadonly()
	rapid.Check(t, func(t *rapid.T) {
		cmd := rapid.SampledFrom(readonlyList).Draw(t, "cmd")
		variant := randomCaseVariant(t, cmd)

		tokens, err := ClassifyCommand(variant)
		if err != nil {
			t.Fatalf("readonly command %q (variant %q) should be allowed, got error: %v", cmd, variant, err)
		}
		if len(tokens) == 0 {
			t.Fatalf("readonly command %q (variant %q): expected tokens, got none", cmd, variant)
		}
		// First token uppercased must match the canonical name.
		if got := strings.ToUpper(tokens[0]); got != cmd {
			t.Fatalf("readonly command %q: first token upper %q != canonical %q", cmd, got, cmd)
		}
	})
}

// TestProp11_DangerousCaseMismatch verifies that dangerous commands are rejected
// with the correct error message regardless of casing (≥100 iterations).
func TestProp11_DangerousCaseMismatch(t *testing.T) {
	dangerousList := allDangerous()
	rapid.Check(t, func(t *rapid.T) {
		cmd := rapid.SampledFrom(dangerousList).Draw(t, "cmd")
		variant := randomCaseVariant(t, cmd)

		_, err := ClassifyCommand(variant)
		if err == nil {
			t.Fatalf("dangerous command %q (variant %q) must be rejected, got nil error", cmd, variant)
		}
		want := "命令被拒绝: " + cmd
		if err.Error() != want {
			t.Fatalf("dangerous command %q (variant %q): got error %q, want %q", cmd, variant, err.Error(), want)
		}
	})
}

// TestProp11_WriteCaseMismatch verifies that write commands are rejected
// with "仅允许只读命令" regardless of casing (≥100 iterations).
func TestProp11_WriteCaseMismatch(t *testing.T) {
	writeList := allWrite()
	rapid.Check(t, func(t *rapid.T) {
		cmd := rapid.SampledFrom(writeList).Draw(t, "cmd")
		variant := randomCaseVariant(t, cmd)

		_, err := ClassifyCommand(variant)
		if err == nil {
			t.Fatalf("write command %q (variant %q) must be rejected, got nil error", cmd, variant)
		}
		want := "仅允许只读命令: " + cmd
		if err.Error() != want {
			t.Fatalf("write command %q (variant %q): got error %q, want %q", cmd, variant, err.Error(), want)
		}
	})
}

// TestProp11_UnknownCommandsDefaultReject verifies that unknown commands (not in
// any of the three sets) are rejected with "不支持的命令" (≥100 iterations).
func TestProp11_UnknownCommandsDefaultReject(t *testing.T) {
	const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	rapid.Check(t, func(t *rapid.T) {
		// Generate a random uppercase command name.
		length := rapid.IntRange(1, 20).Draw(t, "length")
		var b strings.Builder
		for i := 0; i < length; i++ {
			idx := rapid.IntRange(0, len(letters)-1).Draw(t, "ch")
			b.WriteByte(letters[idx])
		}
		cmd := b.String()

		// Skip if it happens to collide with a known command.
		if readonlyCommands[cmd] || dangerousCommands[cmd] || writeCommands[cmd] {
			t.Skip()
		}

		// Apply a random casing variant.
		variant := randomCaseVariant(t, cmd)

		_, err := ClassifyCommand(variant)
		if err == nil {
			t.Fatalf("unknown command %q (variant %q) must be rejected, got nil error", cmd, variant)
		}
		want := "不支持的命令: " + cmd
		if err.Error() != want {
			t.Fatalf("unknown command %q (variant %q): got error %q, want %q", cmd, variant, err.Error(), want)
		}
	})
}

// TestProp11_ClassificationInvariantAcrossCasing verifies that two independently
// generated casing variants of the same command always produce identical results
// (either both allowed or both rejected with the same message).
func TestProp11_ClassificationInvariantAcrossCasing(t *testing.T) {
	all := append(append(allReadonly(), allDangerous()...), allWrite()...)
	rapid.Check(t, func(t *rapid.T) {
		cmd := rapid.SampledFrom(all).Draw(t, "cmd")

		v1 := randomCaseVariant(t, cmd)
		v2 := randomCaseVariant(t, cmd)

		_, err1 := ClassifyCommand(v1)
		_, err2 := ClassifyCommand(v2)

		if (err1 == nil) != (err2 == nil) {
			t.Fatalf("command %q: variant %q → %v, variant %q → %v (outcome differs)", cmd, v1, err1, v2, err2)
		}
		if err1 != nil && err1.Error() != err2.Error() {
			t.Fatalf("command %q: variant %q → %q, variant %q → %q (message differs)", cmd, v1, err1.Error(), v2, err2.Error())
		}
	})
}

// ── 容器型命令子命令白名单（默认拒绝）不变量 ─────────────────────────────────

// allowedSubcommands returns the (cmd, sub) pairs that are explicitly whitelisted.
func allowedSubcommands() (cmds []string, subs map[string][]string) {
	subs = make(map[string][]string)
	for cmd, set := range subcommandReadonly {
		cmds = append(cmds, cmd)
		for sub := range set {
			subs[cmd] = append(subs[cmd], sub)
		}
	}
	return cmds, subs
}

// TestProp11_SubcommandWhitelistAllowed verifies that every whitelisted
// (container command, subcommand) pair is allowed regardless of casing.
func TestProp11_SubcommandWhitelistAllowed(t *testing.T) {
	cmds, subs := allowedSubcommands()
	rapid.Check(t, func(t *rapid.T) {
		cmd := rapid.SampledFrom(cmds).Draw(t, "cmd")
		sub := rapid.SampledFrom(subs[cmd]).Draw(t, "sub")

		input := randomCaseVariant(t, cmd) + " " + randomCaseVariant(t, sub)
		tokens, err := ClassifyCommand(input)
		if err != nil {
			t.Fatalf("whitelisted subcommand %q should be allowed, got error: %v", input, err)
		}
		if len(tokens) < 2 {
			t.Fatalf("whitelisted subcommand %q: expected ≥2 tokens, got %v", input, tokens)
		}
	})
}

// TestProp11_SubcommandDefaultReject verifies the core security invariant:
// any subcommand NOT in the whitelist is rejected (default-deny), regardless of
// casing. This covers future/unknown subcommands such as CLIENT KILL/SETNAME/PAUSE.
func TestProp11_SubcommandDefaultReject(t *testing.T) {
	const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ-"
	cmds, subs := allowedSubcommands()
	rapid.Check(t, func(t *rapid.T) {
		cmd := rapid.SampledFrom(cmds).Draw(t, "cmd")

		// Generate a random subcommand name not in the whitelist.
		length := rapid.IntRange(1, 15).Draw(t, "length")
		var b strings.Builder
		for i := 0; i < length; i++ {
			idx := rapid.IntRange(0, len(letters)-1).Draw(t, "ch")
			b.WriteByte(letters[idx])
		}
		sub := b.String()

		// Skip if it collides with an allowed subcommand.
		for _, allowed := range subs[cmd] {
			if allowed == sub {
				t.Skip()
			}
		}

		input := randomCaseVariant(t, cmd) + " " + randomCaseVariant(t, sub)
		_, err := ClassifyCommand(input)
		if err == nil {
			t.Fatalf("non-whitelisted subcommand %q must be rejected, got nil error", input)
		}
		want := "命令被拒绝: " + cmd + " " + strings.ToUpper(sub)
		if err.Error() != want {
			t.Fatalf("non-whitelisted subcommand %q: got error %q, want %q", input, err.Error(), want)
		}
	})
}

// TestProp11_ContainerCommandWithoutSubReject verifies that a container command
// issued without any subcommand is rejected as unsupported.
func TestProp11_ContainerCommandWithoutSubReject(t *testing.T) {
	cmds, _ := allowedSubcommands()
	rapid.Check(t, func(t *rapid.T) {
		cmd := rapid.SampledFrom(cmds).Draw(t, "cmd")
		variant := randomCaseVariant(t, cmd)

		_, err := ClassifyCommand(variant)
		if err == nil {
			t.Fatalf("container command %q without subcommand must be rejected, got nil error", variant)
		}
		want := "不支持的命令: " + cmd
		if err.Error() != want {
			t.Fatalf("container command %q: got error %q, want %q", variant, err.Error(), want)
		}
	})
}
