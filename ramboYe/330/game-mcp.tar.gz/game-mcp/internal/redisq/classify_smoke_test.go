package redisq

import (
	"testing"
)

func TestClassifyCommand_smoke(t *testing.T) {
	cases := []struct {
		cmd     string
		wantErr bool
		errMsg  string
	}{
		{"GET mykey", false, ""},
		{"get mykey", false, ""},
		{"HGETALL myhash", false, ""},
		{"scan 0 MATCH prefix:* COUNT 100", false, ""},
		{"SET foo bar", true, "仅允许只读命令: SET"},
		{"set foo bar", true, "仅允许只读命令: SET"},
		{"CONFIG REWRITE", true, "命令被拒绝: CONFIG"},
		{"EVAL \"script\" 0", true, "命令被拒绝: EVAL"},
		{"UNKNOWNCMD", true, "不支持的命令: UNKNOWNCMD"},
		{"", true, "不支持的命令: (空)"},
		// CLIENT 子命令白名单：只读子命令放行，写/管理子命令拒绝
		{"CLIENT LIST", false, ""},
		{"CLIENT GETNAME", false, ""},
		{"CLIENT INFO", false, ""},
		{"CLIENT ID", false, ""},
		{"client list", false, ""},
		{"CLIENT KILL TYPE normal", true, "命令被拒绝: CLIENT KILL"},
		{"CLIENT SETNAME test", true, "命令被拒绝: CLIENT SETNAME"},
		{"CLIENT PAUSE 10000", true, "命令被拒绝: CLIENT PAUSE"},
		{"CLIENT UNPAUSE", true, "命令被拒绝: CLIENT UNPAUSE"},
		{"CLIENT NO-EVICT ON", true, "命令被拒绝: CLIENT NO-EVICT"},
		{"client kill type normal", true, "命令被拒绝: CLIENT KILL"},
		{"CLIENT", true, "不支持的命令: CLIENT"},
	}
	for _, c := range cases {
		tokens, err := ClassifyCommand(c.cmd)
		if c.wantErr {
			if err == nil {
				t.Errorf("ClassifyCommand(%q): expected error %q, got tokens %v", c.cmd, c.errMsg, tokens)
				continue
			}
			if err.Error() != c.errMsg {
				t.Errorf("ClassifyCommand(%q): got error %q, want %q", c.cmd, err.Error(), c.errMsg)
			}
		} else {
			if err != nil {
				t.Errorf("ClassifyCommand(%q): unexpected error: %v", c.cmd, err)
				continue
			}
			if len(tokens) == 0 {
				t.Errorf("ClassifyCommand(%q): expected tokens, got none", c.cmd)
			}
		}
	}
}

func TestTokenizeCommand(t *testing.T) {
	cases := []struct {
		input  string
		expect []string
	}{
		{"GET key", []string{"GET", "key"}},
		{`SET key "hello world"`, []string{"SET", "key", "hello world"}},
		{`HSET h f 'val ue'`, []string{"HSET", "h", "f", "val ue"}},
		{"  SCAN   0  ", []string{"SCAN", "0"}},
		{"", nil},
	}
	for _, c := range cases {
		got := TokenizeCommand(c.input)
		if len(got) != len(c.expect) {
			t.Errorf("TokenizeCommand(%q): got %v, want %v", c.input, got, c.expect)
			continue
		}
		for i, tok := range got {
			if tok != c.expect[i] {
				t.Errorf("TokenizeCommand(%q) token[%d]: got %q, want %q", c.input, i, tok, c.expect[i])
			}
		}
	}
}
