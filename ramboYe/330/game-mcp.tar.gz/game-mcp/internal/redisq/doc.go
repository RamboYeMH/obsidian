// Package redisq implements the read-only Redis command whitelist,
// tokenizer, and executor.
package redisq

import _ "github.com/redis/go-redis/v9"
