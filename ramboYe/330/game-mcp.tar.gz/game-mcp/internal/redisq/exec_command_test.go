package redisq

import (
	"context"
	"errors"
	"testing"

	"github.com/alicebob/miniredis/v2"
	"github.com/redis/go-redis/v9"

	"game-mcp/internal/gwerr"
)

// newTestClient starts a miniredis server and returns a connected redis.Client
// as a UniversalClient. The caller is responsible for closing both the client
// and the miniredis server (via t.Cleanup).
func newTestClient(t *testing.T, mr *miniredis.Miniredis) redis.UniversalClient {
	t.Helper()
	cli := redis.NewClient(&redis.Options{
		Addr: mr.Addr(),
	})
	t.Cleanup(func() { _ = cli.Close() })
	return cli
}

// ─── Readonly commands pass through ────────────────────────────────────────

func TestExecCommand_GET_hit(t *testing.T) {
	mr := miniredis.RunT(t)
	mr.Set("greeting", "hello")

	cli := newTestClient(t, mr)
	got, err := ExecCommand(context.Background(), cli, "GET greeting")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if got != "hello" {
		t.Errorf("GET greeting: got %v, want %q", got, "hello")
	}
}

func TestExecCommand_GET_miss_returns_nil(t *testing.T) {
	mr := miniredis.RunT(t)

	cli := newTestClient(t, mr)
	got, err := ExecCommand(context.Background(), cli, "GET no_such_key")
	if err != nil {
		t.Fatalf("unexpected error for missing key: %v", err)
	}
	if got != nil {
		t.Errorf("GET missing key: expected nil result, got %v", got)
	}
}

func TestExecCommand_HGETALL(t *testing.T) {
	mr := miniredis.RunT(t)
	mr.HSet("myhash", "field1", "value1")
	mr.HSet("myhash", "field2", "value2")

	cli := newTestClient(t, mr)
	got, err := ExecCommand(context.Background(), cli, "HGETALL myhash")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	// go-redis returns HGETALL as map[string]string when using Do
	result, ok := got.(map[interface{}]interface{})
	if !ok {
		// go-redis v9 may return map[string]string via Do
		if _, ok2 := got.(map[string]string); !ok2 {
			t.Logf("HGETALL returned type %T value %v (acceptable, non-nil)", got, got)
		}
	} else {
		if len(result) == 0 {
			t.Error("HGETALL: expected non-empty map")
		}
	}
	if got == nil {
		t.Error("HGETALL: expected non-nil result for existing hash")
	}
}

func TestExecCommand_TTL(t *testing.T) {
	mr := miniredis.RunT(t)
	mr.Set("expkey", "val")
	mr.SetTTL("expkey", 120*1000000000) // 120 seconds in nanoseconds

	cli := newTestClient(t, mr)
	got, err := ExecCommand(context.Background(), cli, "TTL expkey")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	// TTL returns an integer (seconds remaining)
	ttl, ok := got.(int64)
	if !ok {
		t.Fatalf("TTL result: expected int64, got %T (%v)", got, got)
	}
	if ttl <= 0 {
		t.Errorf("TTL expkey: expected positive TTL, got %d", ttl)
	}
}

func TestExecCommand_EXISTS(t *testing.T) {
	mr := miniredis.RunT(t)
	mr.Set("present", "yes")

	cli := newTestClient(t, mr)

	// Key exists → should return 1
	got, err := ExecCommand(context.Background(), cli, "EXISTS present")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	count, ok := got.(int64)
	if !ok {
		t.Fatalf("EXISTS result: expected int64, got %T (%v)", got, got)
	}
	if count != 1 {
		t.Errorf("EXISTS present: want 1, got %d", count)
	}

	// Key absent → should return 0
	got2, err2 := ExecCommand(context.Background(), cli, "EXISTS absent_key")
	if err2 != nil {
		t.Fatalf("unexpected error for absent key: %v", err2)
	}
	count2, ok2 := got2.(int64)
	if !ok2 {
		t.Fatalf("EXISTS absent result: expected int64, got %T (%v)", got2, got2)
	}
	if count2 != 0 {
		t.Errorf("EXISTS absent_key: want 0, got %d", count2)
	}
}

func TestExecCommand_case_insensitive_GET(t *testing.T) {
	mr := miniredis.RunT(t)
	mr.Set("k", "v")

	cli := newTestClient(t, mr)
	got, err := ExecCommand(context.Background(), cli, "get k")
	if err != nil {
		t.Fatalf("lowercase get: unexpected error: %v", err)
	}
	if got != "v" {
		t.Errorf("lowercase get k: want %q, got %v", "v", got)
	}
}

// ─── Write commands are rejected before execution ──────────────────────────

func TestExecCommand_write_SET_rejected(t *testing.T) {
	mr := miniredis.RunT(t)
	cli := newTestClient(t, mr)

	_, err := ExecCommand(context.Background(), cli, "SET foo bar")
	if err == nil {
		t.Fatal("SET: expected rejection error, got nil")
	}
	var gwe *gwerr.GatewayError
	if !errors.As(err, &gwe) {
		t.Fatalf("SET: expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	if gwe.Kind != gwerr.KindRejected {
		t.Errorf("SET: expected KindRejected, got %v", gwe.Kind)
	}
	// Verify key was NOT set (command never reached Redis)
	if _, exists := mr.DB(0).Get("foo"); exists == nil {
		t.Error("SET should have been rejected before execution, but key was set in Redis")
	}
}

func TestExecCommand_write_DEL_rejected(t *testing.T) {
	mr := miniredis.RunT(t)
	cli := newTestClient(t, mr)

	_, err := ExecCommand(context.Background(), cli, "DEL somekey")
	if err == nil {
		t.Fatal("DEL: expected rejection error, got nil")
	}
	var gwe *gwerr.GatewayError
	if !errors.As(err, &gwe) {
		t.Fatalf("DEL: expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	if gwe.Kind != gwerr.KindRejected {
		t.Errorf("DEL: expected KindRejected, got %v", gwe.Kind)
	}
}

func TestExecCommand_write_EXPIRE_rejected(t *testing.T) {
	mr := miniredis.RunT(t)
	cli := newTestClient(t, mr)

	_, err := ExecCommand(context.Background(), cli, "EXPIRE somekey 60")
	if err == nil {
		t.Fatal("EXPIRE: expected rejection error, got nil")
	}
	var gwe *gwerr.GatewayError
	if !errors.As(err, &gwe) {
		t.Fatalf("EXPIRE: expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	if gwe.Kind != gwerr.KindRejected {
		t.Errorf("EXPIRE: expected KindRejected, got %v", gwe.Kind)
	}
}

func TestExecCommand_write_HSET_rejected(t *testing.T) {
	mr := miniredis.RunT(t)
	cli := newTestClient(t, mr)

	_, err := ExecCommand(context.Background(), cli, "HSET myhash field value")
	if err == nil {
		t.Fatal("HSET: expected rejection error, got nil")
	}
	var gwe *gwerr.GatewayError
	if !errors.As(err, &gwe) {
		t.Fatalf("HSET: expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	if gwe.Kind != gwerr.KindRejected {
		t.Errorf("HSET: expected KindRejected, got %v", gwe.Kind)
	}
}

// ─── Dangerous commands are rejected before execution ──────────────────────

func TestExecCommand_dangerous_FLUSHALL_rejected(t *testing.T) {
	mr := miniredis.RunT(t)
	mr.Set("sentinel", "present")
	cli := newTestClient(t, mr)

	_, err := ExecCommand(context.Background(), cli, "FLUSHALL")
	if err == nil {
		t.Fatal("FLUSHALL: expected rejection error, got nil")
	}
	var gwe *gwerr.GatewayError
	if !errors.As(err, &gwe) {
		t.Fatalf("FLUSHALL: expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	if gwe.Kind != gwerr.KindRejected {
		t.Errorf("FLUSHALL: expected KindRejected, got %v", gwe.Kind)
	}
	// Verify the data is still intact — command never reached Redis
	v, _ := mr.Get("sentinel")
	if v != "present" {
		t.Error("FLUSHALL was rejected but data was lost — command must have executed")
	}
}

func TestExecCommand_dangerous_CONFIG_rejected(t *testing.T) {
	mr := miniredis.RunT(t)
	cli := newTestClient(t, mr)

	_, err := ExecCommand(context.Background(), cli, "CONFIG SET maxmemory 100mb")
	if err == nil {
		t.Fatal("CONFIG: expected rejection error, got nil")
	}
	var gwe *gwerr.GatewayError
	if !errors.As(err, &gwe) {
		t.Fatalf("CONFIG: expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	if gwe.Kind != gwerr.KindRejected {
		t.Errorf("CONFIG: expected KindRejected, got %v", gwe.Kind)
	}
}

func TestExecCommand_dangerous_EVAL_rejected(t *testing.T) {
	mr := miniredis.RunT(t)
	cli := newTestClient(t, mr)

	_, err := ExecCommand(context.Background(), cli, `EVAL "return 1" 0`)
	if err == nil {
		t.Fatal("EVAL: expected rejection error, got nil")
	}
	var gwe *gwerr.GatewayError
	if !errors.As(err, &gwe) {
		t.Fatalf("EVAL: expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	if gwe.Kind != gwerr.KindRejected {
		t.Errorf("EVAL: expected KindRejected, got %v", gwe.Kind)
	}
}

func TestExecCommand_dangerous_SHUTDOWN_rejected(t *testing.T) {
	mr := miniredis.RunT(t)
	cli := newTestClient(t, mr)

	_, err := ExecCommand(context.Background(), cli, "SHUTDOWN NOSAVE")
	if err == nil {
		t.Fatal("SHUTDOWN: expected rejection error, got nil")
	}
	var gwe *gwerr.GatewayError
	if !errors.As(err, &gwe) {
		t.Fatalf("SHUTDOWN: expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	if gwe.Kind != gwerr.KindRejected {
		t.Errorf("SHUTDOWN: expected KindRejected, got %v", gwe.Kind)
	}
}

// ─── Unknown commands are rejected ─────────────────────────────────────────

func TestExecCommand_unknown_command_rejected(t *testing.T) {
	mr := miniredis.RunT(t)
	cli := newTestClient(t, mr)

	_, err := ExecCommand(context.Background(), cli, "MYCUSTOMCMD arg1 arg2")
	if err == nil {
		t.Fatal("MYCUSTOMCMD: expected rejection error, got nil")
	}
	var gwe *gwerr.GatewayError
	if !errors.As(err, &gwe) {
		t.Fatalf("MYCUSTOMCMD: expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	if gwe.Kind != gwerr.KindValidation {
		t.Errorf("MYCUSTOMCMD: expected KindValidation, got %v", gwe.Kind)
	}
}

func TestExecCommand_empty_command_rejected(t *testing.T) {
	mr := miniredis.RunT(t)
	cli := newTestClient(t, mr)

	_, err := ExecCommand(context.Background(), cli, "")
	if err == nil {
		t.Fatal("empty command: expected rejection error, got nil")
	}
	var gwe *gwerr.GatewayError
	if !errors.As(err, &gwe) {
		t.Fatalf("empty command: expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	if gwe.Kind != gwerr.KindValidation {
		t.Errorf("empty command: expected KindValidation, got %v", gwe.Kind)
	}
}

// ─── Connection failure → KindUpstream ─────────────────────────────────────

func TestExecCommand_connection_failure_returns_upstream_error(t *testing.T) {
	// Point at a port nothing is listening on.
	cli := redis.NewClient(&redis.Options{
		Addr: "127.0.0.1:19999", // nothing listening here
	})
	t.Cleanup(func() { _ = cli.Close() })

	_, err := ExecCommand(context.Background(), cli, "GET somekey")
	if err == nil {
		t.Fatal("connection failure: expected error, got nil")
	}
	var gwe *gwerr.GatewayError
	if !errors.As(err, &gwe) {
		t.Fatalf("connection failure: expected *gwerr.GatewayError, got %T: %v", err, err)
	}
	if gwe.Kind != gwerr.KindUpstream {
		t.Errorf("connection failure: expected KindUpstream, got %v", gwe.Kind)
	}
}
