package redisq

import (
	"context"
	"sync"

	"github.com/redis/go-redis/v9"

	"game-mcp/internal/gwerr"
)

// ExecCommand 分类并执行一条 Redis 命令。
//
// 执行逻辑：
//   - 调用 ClassifyCommand 对命令分词并分类。
//   - 若命令属于危险/写/未知类别（ClassifyCommand 返回 error），直接返回该 error。
//   - 若命令属于只读白名单，通过 cli.Do 执行，并以 []any 传递 token 列表。
//   - 执行失败时包装为 KindUpstream 错误（需求 6.11）。
//
// SCAN/HSCAN/SSCAN/ZSCAN 等携带 MATCH/COUNT 子参数的命令同样走此路径，
// ClassifyCommand 已按白名单允许它们。
func ExecCommand(ctx context.Context, cli redis.UniversalClient, command string) (any, error) {
	tokens, err := ClassifyCommand(command)
	if err != nil {
		// err 已是 gwerr.Rejected 或 gwerr.Validation，直接透传
		return nil, err
	}

	// 将 []string → []any 供 Do 的可变参数使用
	args := convertTokens(tokens)

	result, execErr := cli.Do(ctx, args...).Result()
	if execErr != nil {
		// redis.Nil 表示 key 不存在，视为正常结果（返回 nil 值而非错误）
		if execErr == redis.Nil {
			return nil, nil
		}
		return nil, gwerr.UpstreamWithCause(execErr,
			"Redis 命令执行失败: %s", tokens[0])
	}

	return result, nil
}

// convertTokens 将 []string 转换为 []any，以满足 redis.UniversalClient.Do 的可变参数要求。
func convertTokens(tokens []string) []any {
	args := make([]any, len(tokens))
	for i, t := range tokens {
		args[i] = t
	}
	return args
}

// NewRedisClient 使用给定的地址与凭据创建一个 redis.UniversalClient，并通过 PING 验证连通性。
//
// 连接失败时返回 KindConnection 错误（需求 6.11）。
func NewRedisClient(addr, user, pass string) (redis.UniversalClient, error) {
	cli := redis.NewClient(&redis.Options{
		Addr:     addr,
		Username: user,
		Password: pass,
	})

	ctx := context.Background()
	if err := cli.Ping(ctx).Err(); err != nil {
		_ = cli.Close()
		return nil, gwerr.ConnectionWithCause(err, "无法连接 Redis: %s", addr)
	}

	return cli, nil
}

// clientPoolKey 是连接池中客户端的索引键，由地址与凭据指纹组成。
type clientPoolKey struct {
	addr string
	user string
	pass string
}

// ClientPool 按 (addr, user, pass) 池化 redis.UniversalClient。
// 同一地址+凭据组合只建立一个客户端，线程安全。
type ClientPool struct {
	m sync.Map // clientPoolKey → redis.UniversalClient
}

// Get 从池中获取（或按需创建）指定参数对应的 redis.UniversalClient。
// 若指定参数的客户端尚未建立，则调用 NewRedisClient 创建并缓存；后续调用直接复用。
func (p *ClientPool) Get(addr, user, pass string) (redis.UniversalClient, error) {
	key := clientPoolKey{addr: addr, user: user, pass: pass}

	// 快速路径：已存在时直接返回
	if v, ok := p.m.Load(key); ok {
		return v.(redis.UniversalClient), nil
	}

	// 慢路径：创建新客户端
	cli, err := NewRedisClient(addr, user, pass)
	if err != nil {
		return nil, err
	}

	// LoadOrStore 确保在并发场景下只有一个客户端被存储；若竞争中另一 goroutine 先存储，
	// 则关闭本次创建的客户端，复用已存储的那个。
	actual, loaded := p.m.LoadOrStore(key, cli)
	if loaded {
		_ = cli.Close()
		return actual.(redis.UniversalClient), nil
	}

	return cli, nil
}


