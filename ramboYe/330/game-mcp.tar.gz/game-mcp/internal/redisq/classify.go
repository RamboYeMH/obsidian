package redisq

import (
	"strings"

	"game-mcp/internal/gwerr"
)

// ── 命令集合（全大写键，用 strings.ToUpper 做大小写无关比较） ────────────────

// dangerousCommands 是危险命令集合。这类命令可能影响整个 Redis 实例的状态或安全，
// 必须以最高优先级拒绝，返回「命令被拒绝」（需求 6.9）。
var dangerousCommands = map[string]bool{
	"CONFIG":       true,
	"EVAL":         true,
	"FLUSHALL":     true,
	"FLUSHDB":      true,
	"SHUTDOWN":     true,
	"SCRIPT":       true,
	"DEBUG":        true,
	"SLAVEOF":      true,
	"REPLICAOF":    true,
	"BGSAVE":       true,
	"BGREWRITEAOF": true,
	"PSYNC":        true,
	"SYNC":         true,
	"PFSELFTEST":   true,
	"OBJECT":       true,
	"LATENCY":      true,
	"MEMORY":       true,
	"MODULE":       true,
	"XSETID":       true,
}

// writeCommands 是非危险写命令集合。这类命令修改 Redis 数据但不危及实例，
// 返回「仅允许只读命令」（需求 6.8）。
var writeCommands = map[string]bool{
	"SET":          true,
	"SETNX":        true,
	"SETEX":        true,
	"PSETEX":       true,
	"GETSET":       true,
	"MSET":         true,
	"MSETNX":       true,
	"APPEND":       true,
	"INCR":         true,
	"INCRBY":       true,
	"INCRBYFLOAT":  true,
	"DECR":         true,
	"DECRBY":       true,
	"DEL":          true,
	"UNLINK":       true,
	"EXPIRE":       true,
	"EXPIREAT":     true,
	"PEXPIRE":      true,
	"PEXPIREAT":    true,
	"PERSIST":      true,
	"RENAME":       true,
	"RENAMENX":     true,
	"COPY":         true,
	"MOVE":         true,
	"SORT":         true,
	"SETRANGE":     true,
	"GETDEL":       true,
	"GETEX":        true,
	"LPUSH":        true,
	"LPUSHX":       true,
	"RPUSH":        true,
	"RPUSHX":       true,
	"LINSERT":      true,
	"LSET":         true,
	"LREM":         true,
	"LTRIM":        true,
	"LPOP":         true,
	"RPOP":         true,
	"RPOPLPUSH":    true,
	"LMOVE":        true,
	"SADD":         true,
	"SREM":         true,
	"SMOVE":        true,
	"SPOP":         true,
	"SUNIONSTORE":  true,
	"SINTERSTORE":  true,
	"SDIFFSTORE":   true,
	"ZADD":         true,
	"ZREM":         true,
	"ZINCRBY":      true,
	"ZPOPMIN":      true,
	"ZPOPMAX":      true,
	"ZUNIONSTORE":  true,
	"ZINTERSTORE":  true,
	"ZDIFFSTORE":   true,
	"HSET":         true,
	"HMSET":        true,
	"HSETNX":       true,
	"HDEL":         true,
	"HINCRBY":      true,
	"HINCRBYFLOAT": true,
	"SETBIT":       true,
	"PFADD":        true,
	"PFMERGE":      true,
	"GEOADD":       true,
	"XADD":         true,
	"XTRIM":        true,
	"XDEL":         true,
	"XCLAIM":       true,
	"XAUTOCLAIM":   true,
	"XGROUP":       true,
	"XACK":         true,
	"LMPOP":        true,
	"ZMPOP":        true,
}

// readonlyCommands 是只读命令白名单。只有这些命令才会被允许执行（需求 6.6, 6.7）。
var readonlyCommands = map[string]bool{
	"GET":               true,
	"MGET":              true,
	"HGET":              true,
	"HGETALL":           true,
	"HMGET":             true,
	"HKEYS":             true,
	"HVALS":             true,
	"HLEN":              true,
	"LRANGE":            true,
	"LLEN":              true,
	"LINDEX":            true,
	"SMEMBERS":          true,
	"SISMEMBER":         true,
	"SCARD":             true,
	"ZRANGE":            true,
	"ZRANGEBYSCORE":     true,
	"ZSCORE":            true,
	"ZCARD":             true,
	"ZCOUNT":            true,
	"TYPE":              true,
	"TTL":               true,
	"PTTL":              true,
	"EXISTS":            true,
	"STRLEN":            true,
	"SCAN":              true,
	"HSCAN":             true,
	"SSCAN":             true,
	"ZSCAN":             true,
	"GETRANGE":          true,
	"DBSIZE":            true,
	"INFO":              true,
	"KEYS":              true,
	"RANDOMKEY":         true,
	"DUMP":              true,
	"LPOS":              true,
	"SRANDMEMBER":       true,
	"ZRANGEBYLEX":       true,
	"ZREVRANGE":         true,
	"ZREVRANGEBYSCORE":  true,
	"ZREVRANGEBYLEX":    true,
	"ZRANK":             true,
	"ZREVRANK":          true,
	"GEORADIUS":         true,
	"GEODIST":           true,
	"GEOPOS":            true,
	"GEOHASH":           true,
	"GEORADIUSBYMEMBER": true,
	"GEOSEARCH":         true,
	"XLEN":              true,
	"XRANGE":            true,
	"XREVRANGE":         true,
	"XREAD":             true,
	"XPENDING":          true,
	"XINFO":             true,
	"SUBSTR":            true,
	"GETBIT":            true,
	"BITCOUNT":          true,
	"BITPOS":            true,
	"BITFIELD_RO":       true,
	"PFCOUNT":           true,
	"LOLWUT":            true,
	"WAIT":              true,
	"COMMAND":           true,
}

// subcommandReadonly 是「容器型命令」的子命令白名单。
//
// 这类命令（如 CLIENT）本身不在 readonlyCommands 中，必须连同子命令一起匹配，
// 只有列出的只读/无副作用子命令才会被放行；其余子命令（含 CLIENT KILL /
// SETNAME / PAUSE / UNPAUSE 等有写或管理副作用的）因不在白名单而被默认拒绝。
//
// 采用白名单（默认拒绝）策略：将来 Redis 新增的子命令会自动被拒，无需维护黑名单。
var subcommandReadonly = map[string]map[string]bool{
	"CLIENT": {
		"LIST":    true,
		"GETNAME": true,
		"INFO":    true,
		"ID":      true,
	},
}

// TokenizeCommand 将 Redis 命令字符串分词，尊重单引号和双引号内的空白。
// 返回所有 token（包括命令名本身），引号会被剥除。
// 例如："SET key \"hello world\"" → ["SET", "key", "hello world"]
func TokenizeCommand(command string) []string {
	var tokens []string
	s := strings.TrimSpace(command)
	i := 0
	for i < len(s) {
		// 跳过分隔空白
		for i < len(s) && (s[i] == ' ' || s[i] == '\t') {
			i++
		}
		if i >= len(s) {
			break
		}

		c := s[i]
		if c == '"' || c == '\'' {
			// 带引号的 token：收集到配对的闭合引号
			quote := c
			i++ // 跳过开引号
			var buf strings.Builder
			for i < len(s) {
				if s[i] == '\\' && i+1 < len(s) {
					// 转义字符
					i++
					buf.WriteByte(s[i])
					i++
					continue
				}
				if s[i] == quote {
					i++ // 跳过闭引号
					break
				}
				buf.WriteByte(s[i])
				i++
			}
			tokens = append(tokens, buf.String())
		} else {
			// 不带引号的 token：收集到下一个空白或字符串结尾
			start := i
			for i < len(s) && s[i] != ' ' && s[i] != '\t' && s[i] != '"' && s[i] != '\'' {
				i++
			}
			tokens = append(tokens, s[start:i])
		}
	}
	return tokens
}

// ClassifyCommand 对 Redis 命令字符串分词、分类，按以下优先级返回：
//  1. 危险命令集合 → gwerr.Rejected("命令被拒绝: %s", name)（需求 6.9）
//  2. 写命令集合   → gwerr.Rejected("仅允许只读命令: %s", name)（需求 6.8）
//  3. 容器型命令   → 按子命令白名单匹配（如 CLIENT LIST），命中放行，否则默认拒绝
//  4. 只读白名单   → (tokens, nil)，允许执行（需求 6.6, 6.7）
//  5. 其他         → gwerr.Validation("不支持的命令: %s", name)（需求 6.10）
//
// 比较大小写无关（需求 9.3）。命令为空时视为不支持的命令。
func ClassifyCommand(command string) (tokens []string, err error) {
	tokens = TokenizeCommand(command)
	if len(tokens) == 0 {
		return nil, gwerr.Validation("不支持的命令: (空)")
	}

	name := strings.ToUpper(tokens[0])

	switch {
	case dangerousCommands[name]:
		return nil, gwerr.Rejected("命令被拒绝: %s", name)
	case writeCommands[name]:
		return nil, gwerr.Rejected("仅允许只读命令: %s", name)
	case subcommandReadonly[name] != nil:
		// 容器型命令：必须带子命令，且子命令在白名单内才放行。
		if len(tokens) < 2 {
			return nil, gwerr.Validation("不支持的命令: %s", name)
		}
		sub := strings.ToUpper(tokens[1])
		if subcommandReadonly[name][sub] {
			return tokens, nil
		}
		return nil, gwerr.Rejected("命令被拒绝: %s %s", name, sub)
	case readonlyCommands[name]:
		return tokens, nil
	default:
		return nil, gwerr.Validation("不支持的命令: %s", name)
	}
}
