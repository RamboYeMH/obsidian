# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project overview

`game-mcp` is a read-only MCP (Model Context Protocol) gateway for game operations. It exposes 5 MCP tools over Streamable HTTP that proxy queries to internal MongoDB, Redis, and pprof endpoints — without leaking any credentials or internal host addresses to callers.

## Build & run

```bash
make build          # compile to bin/gateway
make run            # build + run with ./config.yaml
make all            # lint + test + build
make build-linux    # cross-compile Linux amd64

go build -o bin/gateway ./cmd/gateway
```

Config setup:
```bash
cp config.example.yaml config.yaml
./bin/gateway -config ./config.yaml
```

## Testing

```bash
make test           # all tests
make test-race      # with race detector
make test-cover     # coverage → coverage.html

go test ./...
go test -run TestXxx ./internal/mongoq/   # single package
go test -run TestXxx ./cmd/gateway/       # integration tests

# Integration tests against real backends (env vars required)
ETCD_ENDPOINTS=192.168.50.11:2379 go test ./internal/resolver/...
MONGO_URI=mongodb://user:pass@host:port/db go test ./internal/resolver/...
```

Property tests use `pgregory.net/rapid` (≥100 iterations per property). Most packages have both unit tests and `_prop_test.go` property tests.

## Code quality

```bash
make lint   # gofmt + go vet
make fmt    # format only
make vet    # vet only
```

## Architecture

```
cmd/gateway/       Entry point — assembles config → resolver → MCP server → HTTP
internal/
  auth/            Bearer token whitelist middleware
  accesslog/       Per-request structured access log (rotated by day)
  config/          Config structs, YAML loading, validation, Redis credential priority
  gwerr/           Unified GatewayError type with 7 kinds → MCP tool error mapping
  mcptools/        5 tool handlers: mongo_query, redis_query, pprof_collect,
                   list_instances, list_workspaces
  mongoq/          MongoDB query parser (mongo-shell DSL → bson), security guard, runner
  pprofx/          pprof collection, port derivation, input validation, cmdline redaction
  redisq/          Redis read-only command classifier and executor
  resolver/        Service Resolver — etcd-first dual-backend routing
  secret/          DBURL password masking, cmdline credential redaction
```

### Service Resolver (central to all tools)

`resolver.Resolve(workspace, instance)` → `ResolvedTarget` (credentials-free).

Resolution path:
1. Parse `instance` as `<service><serverid>` (e.g. `game1`, `cross1008`)
2. If `(project, workspace)` found in `cfg.Etcd` → etcd path (no fallback)
3. Otherwise → mongo autoops fallback (`processes` collection, `workspace == processes.project`)

`ResolvedTarget` carries `MongoHostPort`, `MongoDBName`, `MongoReplicaSet`, `PprofHostIP`, `RedisAddr` — never credentials. Tool handlers inject credentials from config when connecting.

### Error handling

All errors are wrapped in `gwerr.GatewayError` with one of 7 kinds: `KindValidation`, `KindNotFound`, `KindAmbiguous`, `KindConnection`, `KindRejected`, `KindUpstream`, `KindRedaction`. Convert to MCP tool errors via `(*GatewayError).ToMCPToolError()`. Individual tool call failures never crash the server (process exits only at startup).

### Security invariants

- **MongoDB**: method whitelist (find/findOne/count/countDocuments/estimatedDocumentCount/aggregate/distinct); `$where`/`$function`/`$accumulator` rejected; write stages (`$out`/`$merge`) and diagnostic stages rejected recursively including inside `$facet`/`$lookup`/`$unionWith` sub-pipelines.
- **Redis**: command whitelist (default-deny); EVAL, FLUSHALL, SHUTDOWN always rejected.
- **Credentials**: DBURL embedded credentials are always discarded; only `mongo.readonly` account is used to connect. No credentials may appear in tool results or error messages — property tests in `no_credentials_prop_test.go` enforce this.
- **pprof cmdline**: automatically redacted before returning (`secret` package).

### etcd key format

`namespace=true` (default):  `{env}/{project}/gs/{service}/{serverid}`
`namespace=false` (legacy):  `{project}/gs/{service}/{serverid}`

### DB name group

When `db_name_group=true` (etcd) or `--dbnameGroup 1` in service param (mongo fallback), target DB name gets `{workspace}_` prefix applied via `resolver.ApplyDBNameGroup`.

### Redis credential priority

`redis.envs.<env>.services.<service>` > `redis.envs.<env>` > `redis.global`

etcd model: Redis address comes from config. Mongo fallback model: from `processes.vars.redis`.

### pprof port derivation

`port = pprof_port_bases[service] + serverid_num`. Built-in defaults: `game=27000`, `cross=28000`, `gate=24000`. Config `pprof_port_bases` overrides or extends these.

## Key conventions

- `workspace` is always the env identifier (e.g. `h5dev2`, `h5prod`) — it equals the etcd env key or `processes.project` in the mongo fallback model. Callers use `list_workspaces` to discover valid values.
- The `etcdProject` field of `ResolvedTarget` is unexported — internal routing only, never surfaced to callers.
- etcd clients are pooled per `(project, env)` in a `sync.Map`; the autoops mongo client is a process-level singleton (lazy, mutex-guarded).
- `connectionTimeout = 10s` is applied uniformly to all etcd and mongo dial/query operations.
