# game-mcp — 游戏运维查询网关（MCP Gateway）

统一的游戏运维查询网关，通过 [MCP Streamable HTTP](https://spec.modelcontextprotocol.io/) 协议向远程 LLM 客户端暴露 5 个只读工具，代理执行内网的 MongoDB 查询、Redis 查询与 pprof 性能采集，实例发现与环境枚举。

**核心目标**：用户只需提供 Bearer Token 与逻辑选择器（`workspace`、`instance`），网关在内部自动完成 etcd/mongo 路由，对调用方完全隐藏主机 IP、端口、数据库连接串与凭据。

---

## 目录

- [架构概览](#架构概览)
- [MCP 工具](#mcp-工具)
- [快速开始](#快速开始)
- [配置文件参考](#配置文件参考)
- [实例名格式](#实例名格式)
- [服务解析双后端](#服务解析双后端)
- [安全模型](#安全模型)
- [项目结构](#项目结构)
- [构建与测试](#构建与测试)

---

## 架构概览

```
远程 LLM 客户端
      │  HTTP POST/GET  Bearer Token
      ▼
┌─────────────────────────────────┐
│      Streamable HTTP 传输层      │
│   Auth 中间件（Bearer 白名单）   │
│   Tool Dispatch（tools/list,    │
│     tools/call）                │
│                                 │
│  mongo_query  redis_query       │
│  pprof_collect  list_instances  │
│  list_workspaces                │
│                                 │
│     Service Resolver            │
│   （etcd 优先双后端路由）        │
└──────────┬──────────────────────┘
           │  内网 LAN
    ┌──────┴──────┐
    ▼             ▼
  etcd       mongo autoops
  集群        (processes/hosts)
    │
    ├──▶ 目标 MongoDB（只读账号）
    ├──▶ Redis（只读命令）
    └──▶ pprof HTTP /debug/pprof/*
```

网关部署在内网，所有后端连接均不出内网。

---

## MCP 工具

### `list_workspaces`

列出所有可用的部署环境（workspace），无需任何参数。返回的 `workspace` 值可直接用于其他工具的 `workspace` 参数。

- etcd 模型：来源于配置文件中所有已配置的 env 键
- mongo 模型：来源于管理库 processes 集合的去重 project 字段

**建议先调用此工具**，获取有效的 workspace 列表，再调用其他工具。

---

### `list_instances`

列出指定 `workspace` 下的所有可用实例，每条结果包含实例名和标签，不含任何凭据或地址信息。

| 参数 | 说明 |
|------|------|
| `workspace` | 部署环境标识，如 `h5dev-zaza`、`h5gold`、`h5prod` |

---

### `mongo_query`

对目标实例执行只读 MongoDB 查询，返回 JSON。

| 参数 | 说明 |
|------|------|
| `workspace` | 部署环境标识，如 `h5dev-zaza`、`h5gold`、`h5prod` |
| `instance` | 实例名，格式 `<service><id>`，如 `game1`、`cross1008` |
| `query` | mongo shell 风格只读查询 |

**允许的方法**：`find` / `findOne` / `count` / `countDocuments` / `estimatedDocumentCount` / `aggregate` / `distinct`，以及 `show tables`（别名 `show collections`）

**允许的游标链**：`.sort` / `.skip` / `.limit`

**示例**：
```
db.players.find({level: {$gt: 10}}, {name: 1}).sort({level: -1}).limit(20)
db.players.findOne({uid: "abc123"})
db.players.count({vip: 1})
db.orders.aggregate([{$match: {status: "paid"}}, {$group: {_id: "$uid", total: {$sum: "$amount"}}}])
db.players.distinct("level", {vip: 1})
show tables
```

---

### `redis_query`

对目标实例对应的 Redis 执行只读命令，返回命令结果。

| 参数 | 说明 |
|------|------|
| `workspace` | 部署环境标识，如 `h5dev-zaza`、`h5gold`、`h5prod` |
| `instance` | 实例名，格式 `<service><id>`，如 `game1`、`cross1008` |
| `command` | 只读 Redis 命令，如 `GET key`、`HGETALL myhash` |

**只读白名单**（大小写不敏感）：`GET` / `MGET` / `HGET` / `HGETALL` / `HMGET` / `HKEYS` / `HVALS` / `HLEN` / `LRANGE` / `LLEN` / `LINDEX` / `SMEMBERS` / `SISMEMBER` / `SCARD` / `ZRANGE` / `ZRANGEBYSCORE` / `ZSCORE` / `ZCARD` / `TYPE` / `TTL` / `PTTL` / `EXISTS` / `STRLEN` / `SCAN` / `HSCAN` / `SSCAN` / `ZSCAN` / `GETRANGE` / `DBSIZE` / `INFO`

写命令（SET/DEL 等）和危险命令（EVAL/FLUSHALL 等）一律拒绝。

---

### `pprof_collect`

向目标实例的 pprof 端点发起 HTTP GET，将 profile 字节以 base64 blob 返回。

| 参数 | 说明 |
|------|------|
| `workspace` | 部署环境标识，如 `h5dev-zaza`、`h5gold`、`h5prod` |
| `instance` | 实例名，格式 `<service><id>`，如 `game1`、`cross1008` |
| `profile` | profile 名称，见下表 |
| `seconds` | 可选，采集时长（秒），仅 `profile` 与 `trace` 接受，范围 1–3600 |

**支持的 profile**：

| 名称 | 类型 | 接受 seconds |
|------|------|:---:|
| `allocs` | 内存分配快照 | ✗ |
| `block` | 阻塞分析 | ✗ |
| `cmdline` | 进程命令行（自动脱敏） | ✗ |
| `goroutine` | goroutine 栈 | ✗ |
| `heap` | 堆内存快照 | ✗ |
| `mutex` | 互斥锁竞争 | ✗ |
| `profile` | CPU profile（时间采集） | ✓ |
| `threadcreate` | 线程创建 | ✗ |
| `trace` | 执行跟踪（时间采集） | ✓ |

> ⚠️ `profile` 和 `trace` 会阻塞等待整个采集时长才返回，请为这类调用配置足够长的客户端超时（至少 `seconds + 30s`）。

`cmdline` 响应在返回前会自动脱敏，覆盖：连接串内嵌凭据（`user:pass@host`）、敏感 flag 值（`--password`/`--token`/`--secret`/`--key` 等）、敏感 URL 查询参数值。

**pprof 端口推导**：`port = base[service-type] + serverid`，内置基准 `game=27000`、`cross=28000`、`gate=24000`，可在配置文件中覆盖。

---

## 快速开始

### 构建

```bash
go build -o gateway ./cmd/gateway
```

### 准备配置文件

```bash
cp config.example.yaml config.yaml
# 按实际环境修改 config.yaml（token、数据库账号、etcd endpoints 等）
```

### 启动

```bash
./gateway -config ./config.yaml
```

启动失败（配置缺失/非法）会打印错误到 stderr 并以退出码 1 退出；单次工具调用失败不影响服务存活。

### 在 LLM 客户端中配置

以 MCP Streamable HTTP 方式接入，URL 为 `http://<host>:<port>/mcp`（默认端点 `/mcp`），HTTP 头添加：

```
Authorization: Bearer <your-token>
```

---

## 配置文件参考

完整带注释的配置模板见 [`config.example.yaml`](config.example.yaml)，复制后按环境填写即可：

```bash
cp config.example.yaml config.yaml
```

**必填项**：`server.listen`、`mongo.readonly.user`、`mongo.readonly.pass`、`tokens`（非空列表）

**凭据优先级**（Redis，高 → 低）：`redis.envs.<workspace>.services.<svc>` > `redis.envs.<workspace>` > `redis.global`

---

## 实例名格式

实例名格式为 `<service><id>`，其中：

- `<service>`：一个或多个 ASCII 字母，标识服务类型（保留大小写）
- `<id>`：一个或多个十进制数字，标识实例编号

示例：`game1`、`game421`、`cross1008`、`gate5`、`actv1`

用 `list_workspaces` 发现可用环境，再用 `list_instances` 列出该环境下的所有实例，无需手动猜测。

---

## 服务解析双后端

网关内部的 Service Resolver 按 `(workspace, instance)` 路由，采用 **etcd 优先** 策略：

```
cfg.Etcd[project][workspace] 存在？
    ├── 是 → 仅用 etcd（绝不回退 mongo）
    │         key 模板（namespace=true）: {workspace}/{project}/gs/{service}/{serverid}
    │         key 模板（namespace=false）: {project}/gs/{service}/{serverid}
    │         取 DBURL 的 host:port + 库名；Addr 的 IP 部分作为 pprof 主机
    └── 否 → mongo autoops 回退
              processes.find({project: workspace, serverName, "vars.id": serverid})
              0 条 → 实例不存在；>1 条 → 实例不唯一
              取 vars.dburl 的 host:port；host_id → hosts.lanip 作为 pprof 主机
```

无论走哪条路径，**所有 mongo 连接始终注入配置文件的只读账号**，etcd DBURL / vars.dburl 中的内嵌凭据绝不使用。

---

## 安全模型

| 层面 | 约束 |
|------|------|
| 鉴权 | 每个请求必须携带有效 Bearer Token；无 Token 或 Token 不匹配 → 401，不触达任何后端 |
| MongoDB | 只读账号 + 方法白名单（find/findOne/count/countDocuments/estimatedDocumentCount/aggregate/distinct）；server-side JS（`$where`/`$function`/`$accumulator`）和写阶段（`$out`/`$merge`）无条件拒绝 |
| Redis | 只读命令白名单（默认拒绝）；写命令和危险命令（EVAL/FLUSHALL/SHUTDOWN 等）拒绝 |
| pprof | 仅 HTTP GET，仅 `/debug/pprof/` 路径；`cmdline` 响应自动脱敏 |
| etcd | 仅只读 get/prefix，不对外暴露通用 etcd 工具 |
| 凭据隔离 | 任何工具结果和错误消息中不出现明文内部凭据；DBURL 密码统一掩码为 `****` |

---

## 项目结构

```
cmd/
  gateway/           # 服务入口（main.go + 集成测试）
internal/
  auth/              # Bearer Token 提取与白名单中间件
  config/            # 配置结构体、YAML 加载、启动校验、Redis 凭据优先级
  gwerr/             # 统一网关错误类型 → MCP 工具错误映射
  mcptools/          # 5 个工具的 schema 定义与 handler
  mongoq/            # MongoDB 只读查询库（parse/guard/run）
  pprofx/            # pprof 采集、输入校验、端口推导、cmdline 脱敏
  redisq/            # Redis 只读命令分类与执行
  resolver/          # Service Resolver（etcd 优先双后端路由）
  secret/            # DBURL 密码掩码与 cmdline 脱敏原语
```

---

## 构建与测试

```bash
make build        # 编译到 bin/gateway
make build-linux  # 静态编译 Linux amd64（CGO_ENABLED=0，不依赖 glibc）
make deb          # 打包 .deb（依赖 dpkg-deb，Ubuntu/Debian 自带）
make test         # 运行所有测试
make test-race    # 开启竞态检测
make test-cover   # 生成覆盖率报告 coverage.html
make lint         # fmt + vet
make all          # lint + test + build 完整流程
make clean        # 删除 bin/ 与覆盖率文件
make help         # 查看所有目标
```

也可以直接用 go 命令：

```bash
go build -o bin/gateway ./cmd/gateway
go test ./...

# 集成测试（需配置环境变量）
ETCD_ENDPOINTS=192.168.50.11:2379 go test ./internal/resolver/...
MONGO_URI=mongodb://user:pass@host:port/db go test ./internal/resolver/...
```

属性测试使用 [`pgregory.net/rapid`](https://github.com/pgregory/rapid)，每个属性 ≥100 次迭代，覆盖：实例名解析、etcd key 模板、DBURL 路由解析、库名前缀、凭据掩码/脱敏、Redis 命令分类、pprof 端口推导、鉴权逻辑等核心不变量。
